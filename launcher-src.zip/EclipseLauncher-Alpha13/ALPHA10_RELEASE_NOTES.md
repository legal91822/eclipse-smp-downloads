# Eclipse Launcher 1.0 — Alpha 10: Functional Compact Layout

Esta build transforma o último layout aprovado em interface real do React/Tauri.

## O que mudou

- Logo original do Eclipse preservada em `public/eclipse-logo.png`, sem redimensionamento destrutivo.
- Home refeita para evitar aparência esticada em telas largas.
- Conteúdo limitado a uma largura máxima e centralizado em monitores maiores.
- Hero mais baixo e proporcional, usando `background-size: cover` para manter a arte natural.
- Barra funcional de prontidão para Java, Forge, Perfil Eclipse e Canal.
- Botão principal continua ligado ao fluxo real `play/provision`.
- Primeira instalação e atualização aparecem como uma faixa compacta com tamanho real calculado pelo updater.
- Cards da home agora usam dados reais de jogadores, ping, TPS e modpack da API/manifesto.
- Notícias usam a API/cache já existente; itens com URL abrem a publicação.
- Card do modpack chama o reparo/sincronização real.
- Links rápidos só aparecem quando configurados; abrir pasta do jogo continua disponível.
- Responsividade revisada para 1366x768, 125/150% de scaling e janelas menores.
- Hover e motion mantidos discretos, sem efeitos decorativos exagerados.

## Distribuição

A Alpha 10 continua usando o pipeline da Alpha 9/8 para bootstrap, manifestos por canal e updates diferenciais. Antes de enviar aos players, preencha `FILL_THIS_BEFORE_RELEASE.env` e rode `tools/release_preflight.py`.
