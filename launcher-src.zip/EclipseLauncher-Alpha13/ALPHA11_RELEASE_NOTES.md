# Alpha 11 — Player Ready Prep

## Mudanças principais
- remove a arte repetida do rodapé da sidebar; logo original preservada;
- Home mais compacta, sem cards esticados e com um único artwork principal;
- novo **Seed Pack local** (`EclipseSMP-Seed.zip`) para primeira instalação mesmo sem CDN;
- Seed detectado automaticamente ao lado do launcher, em Downloads, Desktop ou pasta de dados;
- instalação do Seed valida tamanho + SHA-256 antes de ativar cada arquivo;
- configuração pública pode vir de `eclipse-release.json` sem recompilar;
- build pode ser enviada com Launcher Oficial + Offline mesmo sem Microsoft Direct;
- corrigido readiness de launch: Official, Direct e Offline agora exigem apenas os pré-requisitos do modo escolhido;
- exemplo e preparação atualizados para Minecraft 1.20.1 / Forge 47.4.22;
- script Windows `PREPARAR_PACK_PARA_PLAYERS.bat` gera o Seed Pack a partir de uma pasta completa de modpack;
- manifesto real dos quatro arquivos de mods já enviados foi gerado em `manifests/stable.seed.1.actual-mods.json` (308 JARs extraídos sem colisões de nome).

## Caminho rápido para hoje
Enquanto CDN/domínio ainda não estiverem prontos, distribua:
1. instalador/EXE compilado do launcher;
2. `EclipseSMP-Seed.zip`;
3. opcional `eclipse-release.json` para links públicos.

Depois, ao publicar CDN/Bootstrap, o mesmo launcher passa a atualizar diferencialmente sem reinstalar o pack inteiro.
