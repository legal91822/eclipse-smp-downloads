# Eclipse Launcher 1.0 Alpha 12 — Player Release Architecture

## Objetivo
A Alpha 12 fecha o fluxo de distribuição imediata: o administrador consegue gerar **um único ZIP** contendo o launcher portátil e um Seed Pack completo. O player extrai, abre o launcher e usa **INSTALAR E JOGAR**.

## Mudanças reais
- Home simplificada: apenas uma arte principal; thumbnails repetidas foram removidas.
- Sidebar sem imagem repetida no rodapé.
- Layout mais estreito e consistente em 1366x768 e janelas menores.
- First-run via Seed Pack agora é entendido pelo backend antes de a CDN existir.
- `provision_all` e `launch_game` fazem fallback automático para Seed Pack se ainda não houver manifesto instalado.
- Seed installer reutiliza arquivos já corretos em vez de extrair tudo novamente.
- Gerador `tools/make_player_release.py` cria `EclipseSMP-PLAYER.zip`.
- Pacote de player contém `EclipseLauncher.exe`, `EclipseSMP-Seed.zip`, `eclipse-release.json`, atalho BAT e instruções.
- O Seed é validado arquivo por arquivo com SHA-256 antes de entrar na instância.
- Depois que `bootstrap_url` for preenchida, o mesmo launcher troca automaticamente para updates diferenciais online.
- Workflow Windows agora exporta também o EXE portátil bruto, necessário para o pacote de player.
- Forge padrão dos utilitários de release: `47.4.22` para Minecraft 1.20.1.

## Para enviar aos players
1. Compile o EXE portátil pelo workflow Windows.
2. Use a pasta COMPLETA do modpack (não somente `mods`).
3. Rode `tools/RELEASE_PLAYERS_TODAY.ps1`.
4. Envie apenas `release/EclipseSMP-PLAYER.zip`.

## Ainda necessário antes de chamar de release final online
- URL pública para Bootstrap/CDN.
- Endereço real do SMP no manifesto.
- Code signing para reduzir SmartScreen.
- Smoke test em Windows limpo.
