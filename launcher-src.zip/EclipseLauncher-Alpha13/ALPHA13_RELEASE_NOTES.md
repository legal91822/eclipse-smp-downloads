# Eclipse Launcher 1.0 — Alpha 13

## Objetivo desta build

Alpha 13 abandona qualquer dependência de AutoModpack e fecha a arquitetura de distribuição própria do Eclipse Launcher.

O fluxo de produção é:

1. player instala/abre o Eclipse Launcher;
2. launcher obtém a configuração do canal (Stable/Beta/Staff);
3. primeira instalação usa um `EclipseSMP-Seed.zip` oficial quando configurado;
4. o Seed é aceito somente após SHA-256 correto;
5. launcher instala a instância isolada;
6. Java 17 e Forge 1.20.1 são preparados automaticamente;
7. atualizações seguintes usam manifestos diferenciais e baixam somente objetos alterados;
8. antes de abrir o jogo, integridade/readiness são validados novamente.

## UI

- sidebar compacta, sem artwork repetido;
- apenas uma arte principal do eclipse;
- largura útil controlada para não esticar em monitores grandes;
- botão Jogar como ação primária;
- readiness reduzido a uma linha discreta;
- status do servidor em uma única faixa;
- notícias e modpack abaixo, sem cards redundantes;
- efeitos e movimento reduzidos por padrão;
- logo do usuário preservada.

## Distribuição própria

Novos campos de release:

- `seed_url`
- `seed_sha256`

O Seed remoto exige HTTPS e SHA-256 de 64 caracteres hexadecimais. O arquivo é baixado para `.part`, verificado e só depois promovido para `EclipseSMP-Seed.zip`.

`tools/prepare_distribution.py` recebe uma instância cliente funcional completa e gera em uma única passada:

- Seed de primeira instalação;
- objetos content-addressed para atualizações diferenciais;
- manifesto versionado;
- manifesto Stable/Beta/Staff;
- bootstrap `api/channels.json`;
- configuração de release;
- variáveis para a build do launcher;
- relatório da distribuição.

## Minecraft

A base cliente usada pela Alpha 13 é:

- Minecraft 1.20.1
- Forge 47.4.23
- Java 17

A versão Forge deve continuar vindo do manifesto de cada release, não de valor fixo espalhado pelo código.

## Ainda necessário antes de distribuir como produção

- fornecer uma cópia da instância cliente completa que atualmente funciona no SMP;
- publicar a pasta gerada por `prepare_distribution.py` em HTTPS/CDN;
- preencher Bootstrap/Seed e links reais;
- compilar e testar a build Windows em máquina limpa;
- para release pública sem alerta do Windows, configurar code signing;
- para auto-update do launcher, configurar chave Ed25519 e endpoint de update.
