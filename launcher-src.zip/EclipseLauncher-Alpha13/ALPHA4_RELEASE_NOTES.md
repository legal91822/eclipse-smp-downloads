# Eclipse Launcher 1.0 Alpha 4 — Moonlit Interaction

## Home / UX
- Home reorganizada seguindo a direção minimalista escolhida.
- Paleta lunar azul baseada na referência de eclipse enviada.
- Sidebar e topbar reespaçadas.
- `JOGAR` e opções de launch agrupados.
- Cards de status clicáveis e com destino relevante.
- Evento e Modpack alinhados em uma grade consistente.

## Interações
- Hover/press/focus em botões e navegação.
- Page transitions curtas.
- Parallax leve do hero.
- Drift lento de nuvens e glow lunar.
- Toggle global de animações.
- `prefers-reduced-motion` respeitado.

## Som
- Sons UI procedurais (hover/tap/success) via Web Audio API.
- Música ambiente experimental opcional; desligada por padrão.
- Toggles persistidos em `localStorage`.

## Bugs / segurança
- Minecraft corrigido para 1.20.1 na Home.
- TPS corrigido para 19.97.
- Manifesto local validado antes de verify/repair.
- Path traversal e prefixos Windows rejeitados.
- Modos de arquivo e canais validados.
- URLs remotas exigem HTTPS em release.
- Offline exige nickname válido.
- Erros de settings/state aparecem em toast.

## Estado da build
O frontend teve a sintaxe TSX validada localmente. A build Tauri completa ainda depende de baixar os pacotes npm e Rust/Cargo, indisponíveis neste ambiente; o GitHub Actions incluído continua sendo a rota de build Windows.
