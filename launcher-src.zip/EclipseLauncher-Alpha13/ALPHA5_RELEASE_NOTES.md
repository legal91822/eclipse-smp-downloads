# Eclipse Launcher 1.0 Alpha 5 — Reliability & Features

## Destaques

- Status remoto do SMP.
- Sync de manifesto, verificar, reparar e limpar cache direto pela UI.
- Reparo paralelo configurável e SHA-256 em streaming.
- Auto-verify e auto-repair opcionais.
- Pós-launch: minimizar ou fechar.
- Diagnóstico exportável/copiar + atalhos de teclado.
- Volumes separados e intensidade de motion.
- Perfil Offline passa a suportar launch por `.eclipse/launch.json` quando runtime/Forge reais existirem.

## Bugs revisados

1. UUID offline desatualizado após trocar nickname — corrigido.
2. RAM podia persistir valor anterior — fluxo de salvar foi refeito.
3. Boot travava em auto-verify — verificação agora é background.
4. Reparador consumia RAM proporcional ao tamanho dos JARs — hash agora é streaming.
5. Troca de arquivo podia perder o original se rename falhasse — rollback temporário adicionado.
6. Config/manifest ganham escrita protegida com `.tmp` + `.bak`.
7. Paths duplicados/inseguros no manifesto são rejeitados.
8. Frontend e comandos Tauri foram comparados automaticamente; nenhuma chamada ficou sem backend.

## Validação feita neste ambiente

- TS/TSX analisado pelo compilador TypeScript com stubs locais das dependências externas: sem erros de sintaxe/tipagem estrutural do código próprio.
- JSON (`package.json`, `tauri.conf.json`) validado.
- Mapeamento `invoke()` frontend -> `#[tauri::command]` backend verificado: 0 comandos ausentes.
- Rust/Cargo não existe neste ambiente, portanto a compilação Rust final continua delegada ao Windows/GitHub Actions.
