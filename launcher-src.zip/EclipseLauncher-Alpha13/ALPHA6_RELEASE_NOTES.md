# Eclipse Launcher 1.0 — Alpha 6 / Minecraft Bootstrap

Alpha 6 troca a fundação de “launcher que prepara arquivos” por uma integração real com a instalação do Minecraft no Windows.

## Minecraft real

- Runtime Java gerenciado automaticamente.
- O Java é obtido pela API do Eclipse Temurin/Adoptium e o SHA-256 publicado pelo provedor é conferido antes da instalação.
- A versão Java vem de `manifest.launch.java_major` (padrão de fallback: 17).
- Forge é baixado direto do Maven oficial do MinecraftForge usando **Minecraft + Forge exatos do manifesto**.
- O `.sha256` do instalador Forge é verificado antes de executar.
- O instalador é executado em modo client via `--installClient`.
- O launcher procura a versão Forge realmente criada em `.minecraft/versions` em vez de assumir o ID.
- Criação/reparo do perfil `Eclipse SMP` no Minecraft Launcher, apontando `gameDir` para a instância isolada do Eclipse.
- O perfil usa o Java gerenciado e a RAM configurada pelo usuário.
- Alterar a RAM e salvar reescreve o perfil oficial quando ele já existe.
- Detecta também a instalação da Microsoft Store pelo pacote `Microsoft.4297127D64EC6`.

## Bootstrap

Novo fluxo **Preparar Minecraft**:

1. Confere o manifesto.
2. Instala o Java gerenciado se necessário.
3. Baixa e instala a versão exata do Forge.
4. Descobre o `lastVersionId` criado pelo Forge.
5. Cria/atualiza o perfil Eclipse SMP.
6. Marca o bootstrap localmente e revalida na próxima abertura.

A readiness do Forge agora invalida automaticamente quando Minecraft/Forge do manifesto mudarem.

## Conteúdo remoto

Novos endpoints opcionais no manifesto:

- `endpoints.status`
- `endpoints.news`
- `endpoints.events`
- `endpoints.launcher_update`
- `endpoints.file_base`

A Home usa o próximo evento remoto para o cronômetro. A tela Notícias passa a consumir a API remota quando configurada.

## Auto-update do launcher

- Checagem de versão SemVer.
- Download do instalador NSIS por HTTPS.
- Verificação SHA-256 antes de executar.
- Instalação silenciosa no Windows.
- Opção “Atualizar launcher automaticamente”.
- Banner de update caso a instalação automática esteja desativada ou falhe.

Antes da versão estável, o updater deve migrar para artefatos assinados pelo Tauri Updater/certificado de código; SHA-256 servido no mesmo endpoint protege contra corrupção, mas não substitui uma assinatura independente.

## APIs de exemplo

`api_examples/` contém JSONs prontos para status, notícias, eventos e update. Podem ser hospedados em CDN/objeto estático HTTPS.

## Requisito importante

Para criação automática do perfil, o Minecraft Launcher oficial precisa ter sido aberto pelo menos uma vez, para criar `launcher_profiles.json` ou `launcher_profiles_microsoft_store.json`.

O manifesto deve usar Forge **exato**, por exemplo `47.4.23`. Valores genéricos como `47.x` são bloqueados pelo bootstrap para evitar instalar uma versão diferente da usada pelo servidor/modpack.
