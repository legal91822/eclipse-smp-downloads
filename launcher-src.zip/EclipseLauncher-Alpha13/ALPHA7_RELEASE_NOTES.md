# Eclipse Launcher 1.0 — Alpha 7 Production Pass

A Alpha 7 deixa de ser uma rodada de “feature aleatória” e consolida o launcher para produção. A logo e a direção visual aprovada foram preservadas.

## Minecraft / autenticação
- Bootstrap de Java gerenciado + Forge 1.20.1 pela versão **exata** do manifesto.
- Preparação automática de libraries, assets, natives e `launch.json` para Direct/Offline.
- Perfil `Eclipse SMP` no Minecraft Launcher oficial, apontando para a instância isolada.
- Microsoft Direct com Authorization Code + PKCE e refresh token protegido por Windows DPAPI.
- Offline direto com UUID estável e argumentos gerados a partir dos metadata do Minecraft/Forge.

## Atualização e confiabilidade
- Manifest schema v2 com Stable/Beta/Staff, espelhos e mods opcionais.
- Download diferencial por hash/tamanho; somente arquivos necessários são substituídos.
- `.eclipse-part` retomável, pause/resume/cancel, retry e fallback de mirrors/CDNs.
- Download atômico: arquivo atual só é substituído depois de hash e tamanho válidos.
- Estimativa de disco corrigida para considerar bytes realmente necessários em vez do tamanho inteiro do pack.
- Backup automático, histórico, retenção e rollback.
- Detecção de arquivo extra, mod duplicado, managed ausente/corrompido e conflitos de opcionais.
- Logs rotacionados.

## Segurança do launcher
- Metadata de auto-update exige HTTPS, SHA-256 **e Ed25519**.
- Release por tag exige chave de update + certificado Authenticode e valida a assinatura com `signtool`.
- Pacote de suporte sanitiza caminhos/tokens conhecidos.
- URL externa validada antes de abrir.

## API / operação
- API de referência auto-hospedável com painel `/admin` para status/manutenção, notícias, eventos e canais.
- Status pode ser alimentado automaticamente por RCON (online, jogadores e `forge tps`).
- Cache local de status/notícias/eventos para degradação offline.
- Modo manutenção, versão mínima do launcher e versão obrigatória do pack bloqueiam launch incorreto.

## UX
- Home simplificada: logo → navegação → arte → JOGAR → readiness → servidor → notícias/modpack.
- Canto inferior esquerdo agora usa o mesmo mundo noturno (montanhas/floresta/lua), sem personagem aleatório, mantendo “MAIS QUE UM SERVIDOR. UMA NOVA FASE.”
- Settings separados em Jogo / Launcher / Áudio / Atualizações / Avançado.
- Música ambiente original local e opcional + sons discretos de hover/clique/download/play/sucesso/erro.
- Microinterações e modos Reduzido/Normal/Cinemático, além de `prefers-reduced-motion`.
- Atalhos: `Ctrl+Enter` jogar, `Ctrl+Shift+V` verificar, `Ctrl+,` configurações, `Alt+1..5` navegar.
- Janela mínima reduzida e layout responsivo para 1366×768/scaling alto.

## O que NÃO é honesto marcar como “validado” ainda
O código e o pipeline foram preparados para os cenários de produção, mas este ambiente não tem Rust/Cargo nem uma máquina Windows limpa com Minecraft/Microsoft. Portanto ainda precisam ser executados externamente: primeira instalação real, Forge real, login Microsoft real, conexão no SMP, SmartScreen/certificado final e fault-injection de internet/disco. A matriz está em `docs/ALPHA7_VALIDATION.md`.
