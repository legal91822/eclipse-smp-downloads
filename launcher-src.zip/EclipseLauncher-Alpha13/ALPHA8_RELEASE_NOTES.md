# Eclipse Launcher 1.0 — Alpha 8: Automatic Distribution

Alpha 8 turns the pack updater into the default player flow.

## Player flow

1. Player installs `EclipseLauncherSetup.exe` once.
2. Launcher discovers Stable/Beta/Staff from the Eclipse bootstrap endpoint.
3. On first run it downloads only the current pack objects, installs managed Java, installs the exact Forge version and creates the Eclipse profile.
4. On later runs it refreshes the selected channel manifest and estimates the delta.
5. With automatic pack updates enabled (default), only changed/missing files are downloaded. Removed managed files are cleaned, user-preserved files stay untouched.
6. `JOGAR` becomes `INSTALAR E JOGAR`, `ATUALIZAR E JOGAR` or `PREPARAR E JOGAR` when needed.
7. Before a launch, the backend re-checks the channel again so the UI cannot accidentally bypass a required pack update.

## New backend pieces

- `distribution.rs`: bootstrap/channel discovery with local cache and compiled fallbacks.
- `provision.rs`: startup check, first-install provisioning and pre-launch readiness gate.
- Update estimator reports files, bytes, resumed bytes and stale managed files.
- Automatic repair no longer creates useless backups when there is nothing to change.
- First install does not create a giant pointless backup of an empty instance.

## New publishing pipeline

`tools/publish_pack.py` creates a content-addressed CDN layout:

- `objects/<sha-prefix>/<sha256>` immutable objects
- `releases/<version>/manifest.json`
- `channels/<channel>/manifest.json`
- `api/channels.json`

The channel manifest is written last, so clients never see a release before its objects exist in staging.

`tools/publish_r2_example.ps1` shows the required upload order for R2/S3-compatible hosting via rclone: objects/releases/API first, channel manifests last.

## Launcher self-update integration

GitHub Actions now embeds the bootstrap/channel URLs at build time and can publish signed `launcher-update.json` to the Eclipse Control API after the signed release artifacts are actually uploaded.

## Still required before public release

This code needs the real Eclipse infrastructure values:

- real bootstrap API HTTPS URL
- real CDN/R2 public base
- the real current modpack folder
- exact Forge version used by the server
- server address
- optional Microsoft OAuth client ID
- update signing keys and Windows code-signing certificate

And it still requires a clean Windows end-to-end test before calling it production-stable.
