# Eclipse Launcher 1.0 — Alpha 9: Release Prep

Alpha 9 moves the project from "feature prototype" toward a launcher you can actually prepare for players.

## Real project changes

- Restored the exact Eclipse logo supplied by the project as `/public/eclipse-logo.png`.
- Simplified Home and removed several decorative effects/continuous motion.
- Default animation profile is now reduced; music remains off by default.
- Removed fake `launcher.eclipsesmp.net` defaults. Public builds must be configured explicitly.
- Added build-time public configuration for Site, Discord, Rules, Wiki and Support.
- Added a Release Readiness backend check and in-app release checklist.
- A first-install build without a configured HTTPS bootstrap is blocked instead of pretending it can install.
- Public links only appear if they were really configured in the build.
- Distribution URLs are no longer presented as normal player-facing settings.
- Added `.env.release.example` and `tools/release_preflight.py`.
- GitHub tag releases now run the release preflight before compiling the public installers.
- Publisher default minimum launcher version updated to Alpha 9.

## Still requires owner input before player release

- real HTTPS bootstrap/control API domain;
- real CDN/public base;
- exact current Forge build + real modpack;
- Ed25519 updater keys;
- Windows code-signing certificate;
- optional Microsoft OAuth client id for Eclipse Direct;
- final Site/Discord/Rules/Wiki URLs.
