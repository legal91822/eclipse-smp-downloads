@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo [ERRO] Node.js nao encontrado. & exit /b 1)
where npm >nul 2>nul || (echo [ERRO] npm nao encontrado. & exit /b 1)
where rustc >nul 2>nul || (echo [ERRO] Rust nao encontrado. Instale rustup stable-msvc. & exit /b 1)
where cargo >nul 2>nul || (echo [ERRO] Cargo nao encontrado. & exit /b 1)
echo [1/2] Instalando dependencias...
call npm install || exit /b 1
echo [2/2] Compilando instaladores Windows...
call npm run tauri:build || exit /b 1
echo.
echo Build concluida. Veja src-tauri\target\release\bundle\
endlocal
