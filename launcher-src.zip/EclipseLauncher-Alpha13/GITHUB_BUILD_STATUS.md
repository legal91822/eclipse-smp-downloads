# Eclipse Launcher — build de teste no GitHub

- Servidor confirmado: eclipserealm.mcserver.us:9150 (fallback 169.155.126.46:9150).
- Minecraft 1.20.1 / Forge 47.4.10. Sem AutoModpack.
- Este ZIP contem apenas o codigo-fonte, nao um executavel e nao o modpack.
- A compilacao Rust/Windows e o primeiro boot em cliente real ainda nao foram verificados.
- O download automatico da instancia so funcionara depois de publicar um Seed revisado em HTTPS e definir o SHA-256 em eclipse-release.json (ou variaveis da build).
- Nao publique os RARs originais da instancia, tokens, arquivos de conta, saves ou logs.
