# Eclipse Launcher Alpha 12 — distribuição para players

## Caminho mais rápido (sem CDN)

Gere **um único ZIP** contendo o launcher portátil e `EclipseSMP-Seed.zip`:

```powershell
.\tools\RELEASE_PLAYERS_TODAY.ps1 `
  -ModpackFolder "C:\EclipseSMP\modpack" `
  -LauncherExe "C:\EclipseBuild\eclipse-launcher.exe" `
  -PackVersion "1.0.0" `
  -Forge "47.4.23" `
  -ServerAddress "SEU_IP:PORTA"
```

Saída:

```text
release\EclipseSMP-PLAYER.zip
```

O player extrai, abre `EclipseLauncher.exe` e clica **INSTALAR E JOGAR**.

O launcher encontra o Seed Pack no mesmo diretório, valida todos os arquivos por SHA-256, instala numa instância isolada, prepara Java 17/Forge 1.20.1 e cria o perfil Eclipse.

## Caminho final (online)

Quando o CDN estiver configurado, deixe o launcher pequeno e publique o pack via `tools/publish_pack.py`. O mesmo launcher passa a consultar `bootstrap_url` e só baixa arquivos alterados.

## Importante

Não gere o pacote final a partir de apenas `mods/`. Use a pasta completa que seus jogadores realmente usam: `mods`, `config`, `defaultconfigs`, `kubejs`, `resourcepacks` e quaisquer outros arquivos obrigatórios.
