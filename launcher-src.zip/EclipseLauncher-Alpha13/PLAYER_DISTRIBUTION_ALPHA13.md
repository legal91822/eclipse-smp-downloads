# Distribuição para players — Alpha 13

## Resultado final desejado

O jogador recebe somente o instalador do Eclipse Launcher. Ele não instala Forge, Java ou o modpack manualmente.

```text
EclipseLauncherSetup.exe
        ↓
Primeira abertura
        ↓
Seed oficial HTTPS + SHA-256
        ↓
Instância Eclipse SMP
        ↓
Java 17 + Forge 47.4.23
        ↓
JOGAR
```

Depois da primeira instalação, o Bootstrap aponta para o manifesto Stable/Beta/Staff e o launcher baixa apenas arquivos novos/alterados.

## Preparar a distribuição

Use a pasta de uma instância cliente que você já testou e sabe que abre o servidor. Ela deve conter o que realmente é necessário para reproduzir o pack, por exemplo:

- `mods/`
- `config/`
- `defaultconfigs/`
- `kubejs/`
- `resourcepacks/`
- `shaderpacks/` (se fizer parte do pack)
- outros diretórios de conteúdo exigidos pelo pack

Não use `logs`, `crash-reports`, `screenshots`, `saves`, backups ou dados pessoais de jogadores.

No Windows, rode:

```bat
tools\PREPARAR_DISTRIBUICAO_COMPLETA.bat
```

Ou diretamente:

```powershell
python tools\prepare_distribution.py "C:\Eclipse\InstanciaFinal" ^
  --output "C:\Eclipse\distribution" ^
  --public-base "https://cdn.SEUDOMINIO.com/eclipse" ^
  --version "1.0.0" ^
  --forge "47.4.23" ^
  --server "SEU_SERVIDOR:PORTA"
```

## O que publicar

A pasta `distribution/` é a origem do CDN. Ela contém Seed + objetos diferenciais + manifestos.

Para evitar release parcial, envie primeiro `objects/`, `releases/`, `seed/` e `api/`; publique `channels/<canal>/manifest.json` por último.

## Regra de segurança

Nunca libere o botão Jogar com arquivo ausente/corrompido ou versão obrigatória incompatível. O backend da Alpha 13 repete as checagens mesmo quando a UI é contornada.
