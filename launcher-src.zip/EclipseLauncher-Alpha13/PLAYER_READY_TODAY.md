# Mandar o Eclipse Launcher para os players

## Opção A — funciona sem CDN

Depois de compilar `eclipse-launcher.exe`, rode:

```powershell
.\tools\RELEASE_PLAYERS_TODAY.ps1 `
  -ModpackFolder "C:\EclipseSMP\PACK_COMPLETO" `
  -LauncherExe "C:\Build\eclipse-launcher.exe" `
  -PackVersion "1.0.0" `
  -Forge "47.4.23" `
  -ServerAddress "IP_OU_DOMINIO:PORTA"
```

Ele gera:

```text
release\EclipseSMP-PLAYER.zip
```

Você manda **só esse ZIP**.

O player:
1. Extrai.
2. Abre `EclipseLauncher.exe`.
3. Clica `INSTALAR E JOGAR`.

O launcher detecta o Seed Pack no mesmo diretório, instala numa instância isolada, valida SHA-256, prepara Java/Forge e cria o perfil Eclipse.

### Use a pasta COMPLETA
Inclua exatamente o que os jogadores precisam: `mods`, `config`, `defaultconfigs`, `kubejs`, `resourcepacks`, scripts e demais arquivos obrigatórios. Não gere a release usando apenas os quatro RARs de mods.

## Opção B — distribuição online

Quando o CDN estiver pronto, configure `eclipse-release.json` / `ECLIPSE_BOOTSTRAP_URL`. A partir daí o Seed deixa de ser obrigatório e updates ficam diferenciais: o player baixa somente arquivos novos/alterados.
