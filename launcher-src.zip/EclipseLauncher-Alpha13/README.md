# Eclipse Launcher 1.0 — Alpha 13

**Direção atual:** launcher próprio do Eclipse SMP, sem AutoModpack, com primeira instalação por Seed verificado e updates diferenciais.

- Minecraft: 1.20.1
- Forge cliente: 47.4.23
- Java: 17 gerenciado
- UI: compacta/minimalista, uma única arte principal
- Distribuição: `tools/prepare_distribution.py`

Veja `PLAYER_DISTRIBUTION_ALPHA13.md` e `ALPHA13_RELEASE_NOTES.md`.

---

# Eclipse Launcher 1.0 Alpha 12

Launcher Tauri 2 + Rust + React para Eclipse SMP, Minecraft 1.20.1 / Forge 47.4.23.

## O que esta build prioriza
- experiência minimalista;
- primeira instalação em um clique;
- pacote portátil para players sem CDN;
- update diferencial quando CDN estiver disponível;
- Java/Forge gerenciados;
- perfil oficial, Direct e Offline;
- verificação SHA-256, reparo, backup e rollback.

Leia `PLAYER_READY_TODAY.md` e `PLAYER_DISTRIBUTION_ALPHA12.md`.
