$ErrorActionPreference = "Stop"
Write-Host "=== Eclipse Launcher - ambiente de desenvolvimento ===" -ForegroundColor Magenta

function Have($cmd) { return $null -ne (Get-Command $cmd -ErrorAction SilentlyContinue) }

if (-not (Have "winget")) {
  Write-Host "winget nao encontrado. Instale Node.js LTS, Rustup e Visual Studio Build Tools manualmente." -ForegroundColor Yellow
  exit 1
}

if (-not (Have "node")) {
  Write-Host "Instalando Node.js LTS..."
  winget install --id OpenJS.NodeJS.LTS -e --accept-package-agreements --accept-source-agreements
}

if (-not (Have "rustup")) {
  Write-Host "Instalando Rustup..."
  winget install --id Rustlang.Rustup -e --accept-package-agreements --accept-source-agreements
}

Write-Host "ATENCAO: Tauri no Windows tambem precisa do Microsoft C++ Build Tools (Desktop development with C++)." -ForegroundColor Yellow
Write-Host "Se ainda nao tiver, instale Visual Studio Build Tools e marque esse workload." -ForegroundColor Yellow
Write-Host "Depois feche e abra o PowerShell e rode:" -ForegroundColor Cyan
Write-Host "  rustup default stable-msvc"
Write-Host "  npm install"
Write-Host "  npm run tauri:dev"
