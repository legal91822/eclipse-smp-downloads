# Matriz de validação Alpha 7

## Automatizado no repositório/CI
- TypeScript/Vite build.
- `cargo test` + compilação Tauri no runner Windows.
- Validade dos JSONs e gerador de manifesto (`tools/test_alpha7.py`).
- Assinatura Authenticode do instalador em release por tag + `signtool verify`.
- Assinatura Ed25519 do metadata do updater.

## Máquina Windows limpa — obrigatório antes de chamar 1.0 estável
1. Instalar somente o Eclipse Launcher (sem Java/Forge prévio).
2. Sincronizar manifesto real do SMP.
3. Rodar **Preparar Minecraft** e confirmar Java gerenciado + Forge exato + `launch.json`.
4. Rodar `tools/windows_smoke_test.ps1`.
5. Testar rota Oficial com Minecraft Launcher e conta real.
6. Testar Eclipse Direct com app registration Microsoft real e conta que possua Java Edition.
7. Testar Offline apenas no ambiente/servidor que aceite essa modalidade.

## Falhas a simular
- Cortar internet no meio de um JAR grande, abrir de novo e confirmar retomada do `.eclipse-part`.
- Colocar URL CDN primária inválida e confirmar fallback para `file_bases`/mirrors.
- Alterar 1 byte de um mod gerenciado e confirmar que Verificar marca corrompido e Reparar restaura.
- Adicionar JAR extra/duplicado em `mods/` e confirmar a tela de conflitos.
- Publicar pack novo, confirmar backup automático, atualizar e executar rollback.
- Reduzir espaço em disco e confirmar erro antes de iniciar downloads sem apagar a instalação atual.
- Forçar `maintenance=true` na API e confirmar JOGAR bloqueado (exceto Staff).
- Forçar `required_pack_version` diferente e confirmar bloqueio por versão.
- Publicar update com SHA/signature inválidos e confirmar rejeição total.
- Gerar crash-report e validar análise + ZIP de suporte sanitizado.

**A Alpha 7 contém os fluxos para esses cenários, mas os testes end-to-end de Windows/Microsoft/Forge real precisam ser executados em uma máquina Windows com a infraestrutura e credenciais reais do Eclipse.**
