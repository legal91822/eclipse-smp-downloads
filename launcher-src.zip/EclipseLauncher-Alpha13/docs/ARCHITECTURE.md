# Arquitetura — Eclipse Launcher 1.0

## Frontend
React + TypeScript + Vite. A UI nunca lê/escreve arquivos do sistema diretamente: chama comandos Tauri via `invoke`.

## Core Rust
- `settings.rs`: configuração persistente e validação.
- `offline.rs`: UUID local compatível com `OfflinePlayer:<nome>` do Minecraft Java.
- `manifest.rs`: leitura/sincronização/validação do manifesto.
- `integrity.rs`: SHA-256 e detecção de arquivos ausentes/corrompidos.
- `repair.rs`: download para `.part`, hash antes da troca e rename atômico.
- `launch.rs`: rotas Official / Direct / Offline com feature gates explícitos.
- `paths.rs`: instância isolada em `~/.eclipse-launcher/instances/eclipse-smp`.

## Princípio da 1.0
Nunca liberar um botão como “funcional” antes de a cadeia necessária estar pronta. Direct fica bloqueado até OAuth Microsoft oficial. Offline fica bloqueado até runtime + Forge bootstrap terem sido instalados.

## Próxima camada
1. Bootstrap/version JSON do Minecraft 1.20.1.
2. Instalação do Forge exato usado pelo Eclipse.
3. Runtime Java gerenciado.
4. Montagem de classpath/argumentos e launch Offline/Direct.
5. Registro da instância no Minecraft Launcher oficial.
6. CDN + manifesto assinado.
7. API de status/notícias/eventos.
8. Auto-updater assinado.
