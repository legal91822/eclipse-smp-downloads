# Alpha 8 — automatic modpack distribution

## 1. Bootstrap URL baked into the launcher

Production builds should set this GitHub repository variable:

`ECLIPSE_BOOTSTRAP_URL=https://launcher.seudominio.com/api/channels.json`

Optional compiled fallbacks:

- `ECLIPSE_STABLE_MANIFEST_URL`
- `ECLIPSE_BETA_MANIFEST_URL`
- `ECLIPSE_STAFF_MANIFEST_URL`

The bootstrap endpoint returns:

```json
{
  "stable": "https://cdn.seudominio.com/eclipse/channels/stable/manifest.json",
  "beta": "https://cdn.seudominio.com/eclipse/channels/beta/manifest.json",
  "staff": "https://cdn.seudominio.com/eclipse/channels/staff/manifest.json"
}
```

The response is cached locally. If the bootstrap API is temporarily unavailable, the launcher can continue using cached or compiled channel URLs.

## 2. Publish a pack

Example:

```powershell
python tools/publish_pack.py C:\EclipsePack ^
  --cdn-dir C:\EclipseCDN-Staging ^
  --public-base https://cdn.seudominio.com/eclipse ^
  --channel stable ^
  --version 1.4.2 ^
  --minecraft 1.20.1 ^
  --forge 47.4.23 ^
  --control-base https://launcher.seudominio.com/api ^
  --server play.seudominio.com
```

The publisher hashes every managed file and stores it by content hash. An unchanged file never needs another CDN object, and clients only download hashes they do not already have at the expected path/version.

## 3. Upload staging atomically

Upload immutable content first:

- `objects/`
- `releases/`
- `api/`

Then publish `channels/` last.

The included `tools/publish_r2_example.ps1` demonstrates this with `rclone`.

## 4. What a player experiences

### First run

- launcher discovers Stable manifest
- shows total files/bytes
- `INSTALAR E JOGAR`
- downloads pack with pause/resume/retry/mirrors
- installs Java
- installs exact Forge
- creates Eclipse profile
- verifies SHA-256
- launches

### Normal run

- refresh manifest
- compare hashes
- if nothing changed: no pack download
- if 3 files changed in a 10 GB pack: only those 3 files download
- stale managed files are removed
- user files such as screenshots/logs/saves/preserved config are not blindly deleted

## 5. Pack publishing rule

Never publish a channel manifest before the referenced objects are available on the CDN. The provided staging tool enforces this locally; the cloud sync script preserves the same upload order.

## 6. Launcher updates

Launcher updates are separate from pack updates. They use signed NSIS installers, SHA-256 and Ed25519 metadata. On tagged GitHub releases, the workflow can POST the signed metadata to:

`POST /admin/launcher-update`

only after the release artifact has been uploaded.
