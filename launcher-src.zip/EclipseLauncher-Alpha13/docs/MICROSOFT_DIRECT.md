# Eclipse Direct — Microsoft OAuth

A Alpha 7 implementa Authorization Code + PKCE no navegador. O launcher **nunca pede senha Microsoft**. O refresh token é protegido com Windows DPAPI para o usuário logado.

## Configuração necessária

1. Registre um aplicativo desktop/native na Microsoft identity platform.
2. Configure um redirect URI de loopback `http://localhost` para desktop/native.
3. Coloque o Application (client) ID em `auth.client_id` no manifesto.
4. Mantenha `XboxLive.signin offline_access` no scope.
5. Teste com uma conta que realmente possua Minecraft Java antes da release pública.

O callback usa uma porta local efêmera e PKCE S256; o segredo do aplicativo não é embutido no launcher.

## O que ainda precisa ser validado externamente

A cadeia Xbox Live → XSTS → Minecraft Services está implementada, mas precisa de teste end-to-end com o app registration real e uma conta licenciada em Windows antes de ser marcada como estável.
