# Alpha 8 — colocar o modpack no ar

O player instala apenas o Eclipse Launcher. O modpack fica no CDN e é provisionado automaticamente.

## 1. Prepare a pasta limpa do pack

Exemplo:

```
pack/
  mods/
  config/
  defaultconfigs/
  kubejs/
  resourcepacks/
  shaderpacks/
```

Use exatamente os arquivos que os jogadores devem receber.

## 2. Publique uma versão Stable

Exemplo conceitual:

```powershell
python tools/publish_pack.py `
  --pack-dir "C:\Eclipse\pack" `
  --cdn-dir "C:\Eclipse\cdn-staging" `
  --channel stable `
  --version 1.0.0 `
  --minecraft 1.20.1 `
  --forge SUA_VERSAO_EXATA `
  --public-base https://cdn.SEUDOMINIO.com/eclipse
```

O publisher cria objetos imutáveis por SHA-256, manifesto da release, manifesto do canal e bootstrap de canais.

## 3. Sincronize o staging para R2/S3/CDN

A ordem é importante:
1. `objects/`
2. `releases/`
3. `api/`
4. `channels/` POR ÚLTIMO

Use `tools/publish_r2_example.ps1` como base.

## 4. Configure o launcher no build

Variável mínima:

```
ECLIPSE_BOOTSTRAP_URL=https://api.SEUDOMINIO.com/api/channels.json
```

Opcionalmente compile fallbacks:

```
ECLIPSE_STABLE_MANIFEST_URL=...
ECLIPSE_BETA_MANIFEST_URL=...
ECLIPSE_STAFF_MANIFEST_URL=...
```

## 5. Fluxo do jogador

Primeira abertura:

```
launcher -> bootstrap canais -> manifesto -> calcula delta -> baixa pack -> SHA-256 -> Java -> Forge -> perfil -> jogar
```

Próximas aberturas:

```
launcher -> manifesto atual -> compara hashes -> baixa só mudanças -> verifica -> jogar
```

Se cair a internet, os downloads `.eclipse-part` podem continuar. Arquivos válidos existentes não são baixados novamente.

## 6. Publicar atualização

Altere a pasta `pack/` e publique versão nova, por exemplo `1.0.1`. O manifesto Stable só deve ficar visível depois de todos os objetos da release existirem no CDN.

O launcher calcula o delta. Um pack de 10 GB com 130 MB alterados baixa aproximadamente só os 130 MB alterados.

## 7. Launcher separado do modpack

Atualização do aplicativo usa `launcher-update.json`, assinatura Ed25519 e, em produção, Authenticode do Windows. O modpack e o binário do launcher têm ciclos de versão independentes.
