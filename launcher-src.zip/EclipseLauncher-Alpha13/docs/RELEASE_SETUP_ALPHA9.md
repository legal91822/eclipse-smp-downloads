# Alpha 9 — preparar para enviar aos players

A Alpha 9 para de usar endpoints fictícios. Uma build pública sem distribuição configurada fica explicitamente marcada como **pré-lançamento** e o primeiro install é bloqueado.

## 1. Escolha seus endereços reais

Você precisa, no mínimo, de:

- `ECLIPSE_BOOTSTRAP_URL`: JSON `channels.json` publicado em HTTPS.
- `ECLIPSE_UPDATE_PUBLIC_KEY_B64`: chave pública Ed25519 do updater.

Recomendado também:

- site;
- Discord;
- regras;
- wiki/guias;
- suporte.

Copie `.env.release.example` e substitua `SEUDOMINIO`/`SEU_CONVITE` por valores reais.

## 2. Publicar o primeiro Stable

Use `tools/publish_pack.py` com a pasta exata do modpack dos players:

```powershell
python tools/publish_pack.py C:\EclipsePack \
  --cdn-dir C:\EclipseCDN \
  --public-base https://cdn.seudominio.com/eclipse \
  --control-base https://launcher.seudominio.com/api \
  --channel stable \
  --version 1.0.0 \
  --minecraft 1.20.1 \
  --forge SUA_VERSAO_EXATA \
  --server SEU_IP_OU_DOMINIO
```

O publisher envia logicamente `objects/` e `releases/` antes de tornar o manifesto do canal visível.

## 3. Configurar GitHub Actions

Repository **Variables**:

- `ECLIPSE_BOOTSTRAP_URL`
- `ECLIPSE_SITE_URL`
- `ECLIPSE_DISCORD_URL`
- `ECLIPSE_RULES_URL`
- `ECLIPSE_WIKI_URL`
- `ECLIPSE_SUPPORT_URL`
- `ECLIPSE_MICROSOFT_CLIENT_ID` (se Direct for habilitado)
- `ECLIPSE_UPDATE_PUBLIC_KEY_B64`

Repository **Secrets** para release assinada:

- `ECLIPSE_UPDATE_PRIVATE_KEY_PEM`
- `WINDOWS_CERTIFICATE_BASE64`
- `WINDOWS_CERTIFICATE_PASSWORD`
- `ECLIPSE_ADMIN_TOKEN` (se publicar metadata pela API)

## 4. O que mudou na UI

- A logo fornecida pelo projeto agora é usada como asset real.
- O layout da Home foi simplificado e perdeu efeitos decorativos excessivos.
- Endpoints públicos não ficam mais editáveis como configuração normal do player.
- Há um checklist de release no Diagnóstico.
- Links de Site/Discord/Regras/Wiki só aparecem se existirem na build.
- Uma build incompleta deixa claro o que falta em vez de usar dados falsos.

## 5. Antes de mandar para jogadores

Faça uma build Windows pelo Actions e teste em uma VM/PC limpo:

1. instalar launcher;
2. primeiro download;
3. Java/Forge;
4. perfil oficial;
5. abrir Minecraft;
6. publicar uma atualização pequena do pack;
7. confirmar download diferencial;
8. desligar internet no meio do download e retomar;
9. testar reparo e rollback;
10. testar update assinado do launcher.
