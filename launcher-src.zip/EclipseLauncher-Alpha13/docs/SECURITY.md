# Segurança

- O launcher não deve solicitar senha da Microsoft em formulário próprio.
- Eclipse Direct deverá usar OAuth oficial e armazenamento de token protegido pelo sistema operacional.
- Perfil Offline é identificado explicitamente como identidade local/não autenticada.
- Manifesto aceita somente caminhos relativos POSIX e rejeita `..`, caminhos absolutos e barras invertidas.
- Downloads são escritos primeiro em arquivo `.part` e só substituem o destino após tamanho + SHA-256 conferirem.
- Arquivos `preserve` e `optional` não são sobrescritos pelo reparo automático.
- O próximo marco de segurança é assinatura criptográfica do manifesto e do auto-update.
