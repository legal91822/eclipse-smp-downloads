# Assinatura e release (Alpha 7)

Uma release pública por tag **falha de propósito** se as chaves/certificado de produção não estiverem configurados. Isso evita publicar updater “seguro pela metade”.

## 1) Assinatura do updater
Gere um par Ed25519 fora do repositório. A chave privada nunca vai para Git.

- Repository Variable: `ECLIPSE_UPDATE_PUBLIC_KEY_B64` = 32 bytes da chave pública Ed25519 em Base64.
- Repository Secret: `ECLIPSE_UPDATE_PRIVATE_KEY_PEM` = chave privada Ed25519 PEM.

O launcher embute a pública no binário e valida a assinatura do `launcher-update.json` **antes** de baixar/instalar.

## 2) Code signing do Windows
Use um certificado de assinatura de código de uma CA confiável.

- `WINDOWS_CERTIFICATE_BASE64`: arquivo PFX inteiro em Base64.
- `WINDOWS_CERTIFICATE_PASSWORD`: senha do PFX.

O CI assina NSIS/MSI com SHA-256 + timestamp e executa `signtool verify` antes de criar a release.

> Assinatura válida ajuda a estabelecer identidade/reputação do executável. SmartScreen também considera reputação e não há promessa de zero avisos em um projeto novo.

## 3) Releases
- `workflow_dispatch`: gera instaladores de teste, podendo ser não assinados.
- tag `vX.Y.Z`: exige todas as credenciais, assina Windows + metadata Ed25519 e cria release draft.
