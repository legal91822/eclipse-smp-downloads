# Alpha 4 — interação e motion

## Motion

- `pageIn`: troca de página curta, sem deslocamento exagerado.
- Hero: parallax máximo de poucos pixels, desativado junto com `Animações`.
- Nuvens: duas camadas abstratas lentas.
- Lua: respiração luminosa muito discreta.
- Cards: lift de 2–3 px no hover.
- `JOGAR`: hover, press e sheen lento.
- `prefers-reduced-motion` remove motion automaticamente.

## Som

Sons de UI são sintetizados localmente com Web Audio API:

- hover: click tonal muito baixo e curto;
- tap: confirmação curta;
- success: confirmação mais alta.

A opção Música cria apenas um pad ambiente experimental e muito baixo. Uma OST real deve entrar como asset licenciado/autoral posteriormente.

## UX corrigida

- Controles globais ficam agrupados no topo.
- Perfil permanece separado dos controles.
- Status cards levam para telas relevantes.
- Botão de opções de launch fica imediatamente ao lado de `JOGAR`.
- Configurações de ambiente também aparecem na página Configurações.
