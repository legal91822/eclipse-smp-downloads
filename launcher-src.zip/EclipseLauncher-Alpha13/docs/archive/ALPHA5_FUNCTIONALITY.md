# Alpha 5 — funcionalidades e fluxo

## Fluxo de JOGAR

1. Se houver alteração de configuração não salva, a UI salva antes do launch.
2. Se `auto_repair_before_launch=true` e existir manifesto, o core repara arquivos managed.
3. O core verifica novamente SHA-256/tamanho.
4. Se ainda houver arquivo inválido, o launch é bloqueado.
5. Official abre o Minecraft Launcher oficial.
6. Offline usa o runtime gerenciado + `.eclipse/launch.json` quando ambos estiverem prontos.
7. Direct permanece bloqueado até OAuth Microsoft oficial.

## Modpack

- Sincronizar manifesto.
- Verificar integridade.
- Reparar incrementalmente.
- Downloads paralelos configuráveis.
- Abrir instância/cache.
- Limpar cache.

## Diagnóstico

- Readiness do manifesto, launcher oficial, runtime e Forge.
- Pastas reais.
- SO/arquitetura.
- Pack e versão.
- Copiar relatório para suporte.
