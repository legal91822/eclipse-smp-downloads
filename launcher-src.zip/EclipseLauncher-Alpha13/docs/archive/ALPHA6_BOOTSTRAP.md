# Alpha 6 — Pipeline Minecraft / Forge

## Arquivos locais

```text
~/.eclipse-launcher/
  runtime/                       # Temurin JRE gerenciado
  cache/runtime/                 # ZIP do Java
  cache/forge/                   # Forge installer
  cache/launcher-update/         # Atualizador do launcher
  instances/eclipse-smp/         # mods/config/kubejs/etc
    .eclipse/bootstrap.json      # versão Forge/MC instalada
```

No Windows o Forge client é instalado no `.minecraft` oficial porque o Minecraft Launcher precisa das bibliotecas e version JSON. O `gameDir` do perfil, porém, aponta para `instances/eclipse-smp`, mantendo os arquivos do SMP isolados.

## Java

A Alpha 6 consulta a API Adoptium:

```text
/v3/assets/latest/{major}/hotspot?architecture=x64&image_type=jre&os=windows&vendor=eclipse
```

O `binary.package.checksum` é verificado. A extração bloqueia caminhos ZIP fora do diretório de staging.

## Forge

O download é montado com os valores exatos do manifesto:

```text
https://maven.minecraftforge.net/net/minecraftforge/forge/{MC}-{FORGE}/forge-{MC}-{FORGE}-installer.jar
```

Também é buscado `installer.jar.sha256`. Depois:

```text
java -jar forge-...-installer.jar --installClient %APPDATA%\.minecraft
```

O version id é descoberto examinando `.minecraft/versions` após a instalação.

## Perfil oficial

O launcher preserva todos os perfis existentes e adiciona somente a chave `eclipse-smp`. Antes de gravar, usa arquivo temporário + backup.

Campos principais:

```json
{
  "name": "Eclipse SMP",
  "type": "custom",
  "gameDir": ".../.eclipse-launcher/instances/eclipse-smp",
  "lastVersionId": "1.20.1-forge-<versão>",
  "javaDir": ".../.eclipse-launcher/runtime/bin/javaw.exe",
  "javaArgs": "-Xms2048M -Xmx8192M"
}
```

## Limites desta Alpha

- Bootstrap automático de Java está focado em Windows x64/aarch64.
- `Eclipse Direct` com OAuth Microsoft continua deliberadamente bloqueado.
- O perfil Offline direto ainda depende de `launch.json`; a Alpha 6 prioriza o fluxo oficial real.
