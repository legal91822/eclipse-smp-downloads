# Eclipse API — contratos da Alpha 6

Todos os endpoints em produção devem usar HTTPS.

## Status

`GET endpoints.status` -> objeto `ServerStatus`.

## Notícias

`GET endpoints.news` -> array com até 100 itens:

```json
[{"id":"id","title":"Título","summary":"Resumo","category":"LAUNCHER","published_at":"2026-09-15T18:30:00-03:00","url":null,"image_url":null,"pinned":true}]
```

## Eventos

`GET endpoints.events` -> array. Itens com `enabled=false` são ignorados.

```json
[{"id":"event","title":"Eclipse de Inverno","summary":"Um novo ciclo se aproxima.","starts_at":"2026-09-21T20:00:00-03:00","ends_at":null,"image_url":null,"enabled":true}]
```

## Launcher Update

`GET endpoints.launcher_update`:

```json
{
  "version":"1.0.0-alpha.7",
  "notes":"Notas",
  "url":"https://cdn/.../EclipseLauncher-setup.exe",
  "sha256":"<64 hex>",
  "mandatory":false,
  "installer_type":"nsis"
}
```

Somente versões SemVer maiores que a local são retornadas ao frontend.
