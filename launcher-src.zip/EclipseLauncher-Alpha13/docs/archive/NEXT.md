# Próximo marco técnico

Para transformar esta alpha em uma 1.0 jogável precisamos do pack real do Eclipse SMP e, principalmente, da versão exata do Forge.

O próximo código deve implementar:
- resolvedor do Minecraft 1.20.1;
- runtime Java gerenciado;
- bibliotecas/assets natives;
- bootstrap Forge;
- argumentos JVM/game;
- `--username`, UUID e token apropriados por rota;
- servidor padrão do Eclipse;
- sincronização incremental do pack real;
- registro/abertura da instalação no Minecraft Launcher oficial.
