# Eclipse Control API — Alpha 8

Public resources:

- `GET /api/health`
- `GET /api/status.json`
- `GET /api/news.json`
- `GET /api/events.json`
- `GET /api/channels.json` — first-run bootstrap for Stable/Beta/Staff
- `GET /api/launcher-update.json` — signed launcher updater metadata

Admin mutations require `Authorization: Bearer <ECLIPSE_ADMIN_TOKEN>`:

- `POST /admin/status`
- `POST /admin/news`
- `POST /admin/events`
- `POST /admin/channels`
- `POST /admin/launcher-update`

Run behind HTTPS in production. Do not embed the admin token in the desktop launcher.
