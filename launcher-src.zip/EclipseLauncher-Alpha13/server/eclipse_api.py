#!/usr/bin/env python3
"""Small self-hosted Eclipse Launcher control API.
Production recommendation: run behind HTTPS reverse proxy (Caddy/Nginx/Cloudflare Tunnel),
set ECLIPSE_ADMIN_TOKEN, and restrict /admin access.
"""
from __future__ import annotations
import json, os, secrets, tempfile, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
STATIC = ROOT / "static"
DATA.mkdir(parents=True, exist_ok=True)
TOKEN = os.environ.get("ECLIPSE_ADMIN_TOKEN", "")
HOST = os.environ.get("ECLIPSE_API_HOST", "127.0.0.1")
PORT = int(os.environ.get("ECLIPSE_API_PORT", "8787"))
MAX_BODY = 2 * 1024 * 1024
LOCK = threading.RLock()

DEFAULTS = {
    "status.json": {
        "online": False, "players_online": 0, "players_max": 80, "ping_ms": None, "tps": None,
        "message": "Inicializando", "maintenance": True,
        "maintenance_message": "Servidor em preparação.",
        "min_launcher_version": "1.0.0-alpha.8", "required_pack_version": "1.0.0"
    },
    "news.json": [],
    "events.json": [],
    "channels.json": {"stable": "", "beta": "", "staff": ""},
    "launcher-update.json": {"version":"1.0.0-alpha.8","notes":"","url":"","sha256":"","signature":"","mandatory":False,"installer_type":"nsis"},
}

def atomic_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8")
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(payload); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def load_json(name: str):
    path = DATA / name
    with LOCK:
        if not path.exists(): atomic_json(path, DEFAULTS[name])
        return json.loads(path.read_text("utf-8"))

def valid_payload(name: str, obj) -> bool:
    if name == "status.json":
        return isinstance(obj, dict) and isinstance(obj.get("maintenance", False), bool)
    if name in {"news.json", "events.json"}: return isinstance(obj, list)
    if name == "channels.json": return isinstance(obj, dict)
    if name == "launcher-update.json": return isinstance(obj, dict) and isinstance(obj.get("version", ""), str)
    return False

class Handler(BaseHTTPRequestHandler):
    server_version = "EclipseControl/1.0"
    def log_message(self, fmt, *args):
        print("[api]", fmt % args)

    def headers_common(self, ctype="application/json; charset=utf-8"):
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store" if self.path.startswith("/admin") else "public, max-age=15")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")

    def send_json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code); self.headers_common(); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

    def is_admin(self):
        if not TOKEN: return False
        raw = self.headers.get("Authorization", "")
        supplied = raw[7:] if raw.startswith("Bearer ") else ""
        return bool(supplied) and secrets.compare_digest(supplied, TOKEN)

    def read_json(self):
        try: n = int(self.headers.get("Content-Length", "0"))
        except ValueError: n = 0
        if n <= 0 or n > MAX_BODY: raise ValueError("body inválido")
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def do_GET(self):
        p = urlparse(self.path).path
        public = {"/api/status.json":"status.json", "/api/news.json":"news.json", "/api/events.json":"events.json", "/api/channels.json":"channels.json", "/api/launcher-update.json":"launcher-update.json"}
        if p in public: return self.send_json(200, load_json(public[p]))
        if p == "/api/health": return self.send_json(200, {"ok": True, "version": 1})
        if p == "/admin/state":
            if not self.is_admin(): return self.send_json(401, {"error":"unauthorized"})
            return self.send_json(200, {k:load_json(k) for k in DEFAULTS})
        if p in {"/admin", "/admin/"}:
            file = STATIC / "admin.html"
            if not file.exists(): return self.send_json(404,{"error":"admin missing"})
            data=file.read_bytes(); self.send_response(200); self.headers_common("text/html; charset=utf-8"); self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data); return
        return self.send_json(404, {"error":"not found"})

    def do_POST(self):
        p = urlparse(self.path).path
        routes = {"/admin/status":"status.json", "/admin/news":"news.json", "/admin/events":"events.json", "/admin/channels":"channels.json", "/admin/launcher-update":"launcher-update.json"}
        if p not in routes: return self.send_json(404,{"error":"not found"})
        if not self.is_admin(): return self.send_json(401,{"error":"unauthorized"})
        try: obj=self.read_json()
        except Exception as e: return self.send_json(400,{"error":str(e)})
        name=routes[p]
        if not valid_payload(name,obj): return self.send_json(422,{"error":"payload inválido"})
        with LOCK: atomic_json(DATA/name,obj)
        return self.send_json(200,{"ok":True,"resource":name})

if __name__ == "__main__":
    for name, default in DEFAULTS.items():
        if not (DATA/name).exists(): atomic_json(DATA/name,default)
    try:
        from rcon_monitor import start_monitor
        start_monitor(lambda: load_json("status.json"), lambda x: atomic_json(DATA/"status.json",x), int(os.environ.get("ECLIPSE_RCON_INTERVAL","15")))
    except Exception as e:
        print("[api] RCON monitor não iniciado:", e)
    print(f"Eclipse API em http://{HOST}:{PORT}  (admin token {'configurado' if TOKEN else 'AUSENTE'})")
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
