"""Optional Minecraft RCON status monitor for Eclipse Control API (stdlib only)."""
from __future__ import annotations
import os, re, socket, struct, threading, time
from pathlib import Path

PLAYER_RE = re.compile(r"There are\s+(\d+)\s+of a max of\s+(\d+)\s+players online", re.I)
TPS_RE = re.compile(r"(?:Mean TPS|TPS)\s*:\s*([0-9.]+)", re.I)

class Rcon:
    def __init__(self, host, port, password, timeout=4):
        self.sock=socket.create_connection((host,port),timeout=timeout); self.sock.settimeout(timeout); self.req=100
        self._send(3,password); _,typ,_=self._recv()
        if typ==-1: raise RuntimeError("RCON auth failed")
    def close(self):
        try:self.sock.close()
        except OSError:pass
    def _send(self,typ,payload):
        self.req+=1; raw=payload.encode('utf-8'); body=struct.pack('<ii',self.req,typ)+raw+b'\x00\x00'; self.sock.sendall(struct.pack('<i',len(body))+body); return self.req
    def _exact(self,n):
        out=b''
        while len(out)<n:
            chunk=self.sock.recv(n-len(out))
            if not chunk: raise ConnectionError("RCON disconnected")
            out+=chunk
        return out
    def _recv(self):
        n=struct.unpack('<i',self._exact(4))[0]; body=self._exact(n); rid,typ=struct.unpack('<ii',body[:8]); return rid,typ,body[8:-2].decode('utf-8','replace')
    def cmd(self,text): self._send(2,text); return self._recv()[2]

def start_monitor(load_status, save_status, interval=15):
    host=os.environ.get('ECLIPSE_RCON_HOST','').strip(); password=os.environ.get('ECLIPSE_RCON_PASSWORD','')
    if not host or not password: return None
    port=int(os.environ.get('ECLIPSE_RCON_PORT','25575'))
    def loop():
        while True:
            begin=time.perf_counter(); status=load_status()
            try:
                r=Rcon(host,port,password); latency=max(1,round((time.perf_counter()-begin)*1000))
                listing=r.cmd('list'); tps_text=''
                try:tps_text=r.cmd('forge tps')
                except Exception:pass
                r.close()
                m=PLAYER_RE.search(listing); t=TPS_RE.search(tps_text)
                status['online']=True; status['ping_ms']=latency; status['message']='Eclipse SMP online'
                if m: status['players_online']=int(m.group(1)); status['players_max']=int(m.group(2))
                if t: status['tps']=min(20.0,max(0.0,float(t.group(1))))
            except Exception as e:
                status['online']=False; status['players_online']=0; status['ping_ms']=None; status['tps']=None; status['message']='Servidor indisponível'
            save_status(status); time.sleep(max(5,interval))
    th=threading.Thread(target=loop,name='eclipse-rcon-monitor',daemon=True); th.start(); return th
