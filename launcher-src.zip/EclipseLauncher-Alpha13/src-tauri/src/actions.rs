use std::{fs, path::Path, process::Command};
use crate::{error::{LauncherError, Result}, models::CacheReport, paths};

fn open_path(path: &Path) -> Result<()> {
    if !path.exists() { fs::create_dir_all(path)?; }
    #[cfg(target_os = "windows")]
    let mut command = { let mut c = Command::new("explorer"); c.arg(path); c };
    #[cfg(target_os = "macos")]
    let mut command = { let mut c = Command::new("open"); c.arg(path); c };
    #[cfg(all(unix, not(target_os = "macos")))]
    let mut command = { let mut c = Command::new("xdg-open"); c.arg(path); c };
    command.spawn().map_err(|e| LauncherError::Config(format!("Não foi possível abrir {}: {e}", path.display())))?;
    Ok(())
}

fn measure_tree(path: &Path, report: &mut CacheReport) -> Result<()> {
    if !path.exists() { return Ok(()); }
    for entry in fs::read_dir(path)? {
        let entry = entry?;
        let p = entry.path();
        let meta = entry.metadata()?;
        if meta.is_dir() { measure_tree(&p, report)?; }
        else if meta.is_file() {
            report.files_removed += 1;
            report.bytes_removed += meta.len();
        }
    }
    Ok(())
}

pub fn open_instance() -> Result<()> { open_path(&paths::instance_dir()?) }
pub fn open_logs() -> Result<()> { open_path(&paths::logs_dir()?) }
pub fn open_cache() -> Result<()> { open_path(&paths::cache_dir()?) }
pub fn open_backups() -> Result<()> { open_path(&paths::backups_dir()?) }
pub fn open_support() -> Result<()> { open_path(&paths::support_dir()?) }

pub fn clear_cache() -> Result<CacheReport> {
    let dir = paths::cache_dir()?;
    let mut report = CacheReport::default();
    measure_tree(&dir, &mut report)?;
    if dir.exists() { fs::remove_dir_all(&dir)?; }
    fs::create_dir_all(&dir)?;
    Ok(report)
}

pub fn open_url(url: &str) -> Result<()> {
    let parsed = url::Url::parse(url).map_err(|_| LauncherError::Config("URL inválida".into()))?;
    if !matches!(parsed.scheme(), "https" | "http") { return Err(LauncherError::Config("Somente URLs HTTP(S) podem ser abertas".into())); }
    #[cfg(target_os = "windows")]
    let mut command = { let mut c = Command::new("rundll32.exe"); c.arg("url.dll,FileProtocolHandler").arg(url); c };
    #[cfg(target_os = "macos")]
    let mut command = { let mut c = Command::new("open"); c.arg(url); c };
    #[cfg(all(unix, not(target_os = "macos")))]
    let mut command = { let mut c = Command::new("xdg-open"); c.arg(url); c };
    command.spawn().map_err(|e| LauncherError::Config(format!("Não foi possível abrir o navegador: {e}")))?;
    Ok(())
}
