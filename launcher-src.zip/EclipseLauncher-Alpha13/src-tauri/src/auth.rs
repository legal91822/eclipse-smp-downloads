use base64::{engine::general_purpose::URL_SAFE_NO_PAD,Engine as _};
use rand::{rngs::OsRng,RngCore};
use serde::Deserialize;
use sha2::{Digest,Sha256};
use std::{fs,io::Write,process::{Command,Stdio}};
use tokio::{io::{AsyncReadExt,AsyncWriteExt},net::TcpListener};
use crate::{actions,error::{LauncherError,Result},manifest,models::{MicrosoftProfile,MinecraftSession},paths};

#[derive(Debug,Deserialize)] struct OAuthToken{access_token:String,refresh_token:Option<String>}
#[derive(Debug,Deserialize)] struct XboxResponse{#[serde(rename="Token")]token:String,#[serde(rename="DisplayClaims")]display_claims:XboxClaims}
#[derive(Debug,Deserialize)] struct XboxClaims{xui:Vec<Xui>}
#[derive(Debug,Deserialize)] struct Xui{uhs:String,#[serde(default)]xid:String}
#[derive(Debug,Deserialize)] struct McLogin{access_token:String}
#[derive(Debug,Deserialize)] struct McProfile{id:String,name:String}

fn secret_path()->Result<std::path::PathBuf>{Ok(paths::secrets_dir()?.join("msa-refresh.dpapi"))}

#[cfg(target_os="windows")]
fn dpapi(script:&str,input:&str)->Result<String>{
    let mut child=Command::new("powershell.exe").args(["-NoProfile","-NonInteractive","-Command",script]).stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped()).spawn().map_err(|e|LauncherError::Config(format!("DPAPI indisponível: {e}")))?;
    if let Some(mut stdin)=child.stdin.take(){stdin.write_all(input.as_bytes())?;}
    let out=child.wait_with_output()?;if !out.status.success(){return Err(LauncherError::Config(format!("DPAPI falhou: {}",String::from_utf8_lossy(&out.stderr).trim())))}
    Ok(String::from_utf8_lossy(&out.stdout).trim().to_string())
}
#[cfg(not(target_os="windows"))]
fn dpapi(_script:&str,_input:&str)->Result<String>{Err(LauncherError::Config("Armazenamento seguro OAuth da Alpha 7 usa DPAPI no Windows".into()))}

fn save_refresh(token:&str)->Result<()> {
    paths::ensure_layout()?;
    let script="$s=[Console]::In.ReadToEnd();$b=[Text.Encoding]::UTF8.GetBytes($s);$e=[Security.Cryptography.ProtectedData]::Protect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser);[Convert]::ToBase64String($e)";
    let enc=dpapi(script,token)?;fs::write(secret_path()?,enc)?;Ok(())
}
fn load_refresh()->Result<String>{
    let p=secret_path()?;if !p.exists(){return Err(LauncherError::Config("Conta Microsoft não conectada".into()))}let enc=fs::read_to_string(p)?;
    let script="$s=[Console]::In.ReadToEnd().Trim();$b=[Convert]::FromBase64String($s);$d=[Security.Cryptography.ProtectedData]::Unprotect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser);[Text.Encoding]::UTF8.GetString($d)";
    dpapi(script,&enc)
}
fn save_profile(p:&MicrosoftProfile)->Result<()>{fs::write(paths::auth_profile_path()?,serde_json::to_vec_pretty(p)?)?;Ok(())}
pub fn state()->MicrosoftProfile{let p=paths::auth_profile_path().ok();if secret_path().ok().map(|x|x.exists()).unwrap_or(false){if let Some(p)=p{if let Ok(s)=fs::read_to_string(p){if let Ok(mut v)=serde_json::from_str::<MicrosoftProfile>(&s){v.connected=true;return v;}}}}MicrosoftProfile::default()}
pub fn logout()->Result<()> {let _=fs::remove_file(secret_path()?);let _=fs::remove_file(paths::auth_profile_path()?);Ok(())}

fn random_urlsafe(n:usize)->String{let mut b=vec![0u8;n];OsRng.fill_bytes(&mut b);URL_SAFE_NO_PAD.encode(b)}

async fn exchange_code(token_url:&str,client_id:&str,code:&str,redirect:&str,verifier:&str,scope:&str)->Result<OAuthToken>{
    let client=reqwest::Client::builder().user_agent("EclipseLauncher/1.0").timeout(std::time::Duration::from_secs(30)).build()?;
    Ok(client.post(token_url).form(&[("client_id",client_id),("code",code),("grant_type","authorization_code"),("redirect_uri",redirect),("code_verifier",verifier),("scope",scope)]).send().await?.error_for_status()?.json().await?)
}
async fn refresh_msa(refresh:&str)->Result<OAuthToken>{
    let m=manifest::load_local()?;if m.auth.client_id.trim().is_empty(){return Err(LauncherError::Config("auth.client_id não configurado no manifesto".into()))}
    let client=reqwest::Client::builder().user_agent("EclipseLauncher/1.0").timeout(std::time::Duration::from_secs(30)).build()?;
    Ok(client.post(&m.auth.token_url).form(&[("client_id",m.auth.client_id.as_str()),("refresh_token",refresh),("grant_type","refresh_token"),("scope",m.auth.scope.as_str())]).send().await?.error_for_status()?.json().await?)
}

async fn minecraft_from_msa(msa:&str,client_id:&str)->Result<MinecraftSession>{
    let client=reqwest::Client::builder().user_agent("EclipseLauncher/1.0").timeout(std::time::Duration::from_secs(30)).build()?;
    let xbox:XboxResponse=client.post("https://user.auth.xboxlive.com/user/authenticate").json(&serde_json::json!({"Properties":{"AuthMethod":"RPS","SiteName":"user.auth.xboxlive.com","RpsTicket":format!("d={msa}")},"RelyingParty":"http://auth.xboxlive.com","TokenType":"JWT"})).send().await?.error_for_status()?.json().await?;
    let xui=xbox.display_claims.xui.first().ok_or_else(||LauncherError::Config("Xbox Live não retornou user hash".into()))?;
    let uhs=xui.uhs.clone(); let xid=xui.xid.clone(); let xbox_token=xbox.token.clone();
    let xsts:XboxResponse=client.post("https://xsts.auth.xboxlive.com/xsts/authorize").json(&serde_json::json!({"Properties":{"SandboxId":"RETAIL","UserTokens":[xbox_token]},"RelyingParty":"rp://api.minecraftservices.com/","TokenType":"JWT"})).send().await?.error_for_status()?.json().await?;
    let login:McLogin=client.post("https://api.minecraftservices.com/authentication/login_with_xbox").json(&serde_json::json!({"identityToken":format!("XBL3.0 x={};{}",uhs,xsts.token)})).send().await?.error_for_status()?.json().await?;
    let profile:McProfile=client.get("https://api.minecraftservices.com/minecraft/profile").bearer_auth(&login.access_token).send().await?.error_for_status()?.json().await.map_err(|_|LauncherError::Config("A conta Microsoft autenticou, mas o perfil Minecraft Java não foi encontrado".into()))?;
    Ok(MinecraftSession{name:profile.name,uuid:profile.id,access_token:login.access_token,user_type:"msa".into(),xuid:xid,client_id:client_id.into()})
}

pub async fn login()->Result<MicrosoftProfile>{
    let m=manifest::load_local()?;if m.auth.client_id.trim().is_empty(){return Err(LauncherError::Config("Defina auth.client_id no manifesto para habilitar Eclipse Direct".into()))}
    let listener=TcpListener::bind("127.0.0.1:0").await?;let port=listener.local_addr()?.port();let redirect=format!("http://localhost:{port}/callback");
    let verifier=random_urlsafe(48);let challenge=URL_SAFE_NO_PAD.encode(Sha256::digest(verifier.as_bytes()));let state=random_urlsafe(24);
    let mut auth=url::Url::parse(&m.auth.authorize_url).map_err(|_|LauncherError::Config("auth.authorize_url inválida".into()))?;
    auth.query_pairs_mut().append_pair("client_id",&m.auth.client_id).append_pair("response_type","code").append_pair("redirect_uri",&redirect).append_pair("scope",&m.auth.scope).append_pair("code_challenge",&challenge).append_pair("code_challenge_method","S256").append_pair("state",&state);
    actions::open_url(auth.as_str())?;
    let accept=tokio::time::timeout(std::time::Duration::from_secs(180),listener.accept()).await.map_err(|_|LauncherError::Config("Login Microsoft expirou após 3 minutos".into()))??;let (mut socket,_)=accept;let mut buf=vec![0u8;8192];let n=socket.read(&mut buf).await?;let req=String::from_utf8_lossy(&buf[..n]);let first=req.lines().next().unwrap_or("");let target=first.split_whitespace().nth(1).unwrap_or("/");let callback=url::Url::parse(&format!("http://127.0.0.1{target}")).map_err(|_|LauncherError::Config("Callback OAuth inválido".into()))?;
    let mut code=None;let mut returned_state=None;let mut oauth_error=None;for (k,v) in callback.query_pairs(){match k.as_ref(){"code"=>code=Some(v.into_owned()),"state"=>returned_state=Some(v.into_owned()),"error"=>oauth_error=Some(v.into_owned()),_=>{}}}
    let body=if oauth_error.is_some(){"<h2>Login cancelado</h2><p>Você pode fechar esta janela.</p>"}else{"<h2>Eclipse Launcher conectado</h2><p>Você pode voltar ao launcher.</p>"};let response=format!("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body);let _=socket.write_all(response.as_bytes()).await;
    if let Some(e)=oauth_error{return Err(LauncherError::Config(format!("Microsoft OAuth retornou: {e}")))}if returned_state.as_deref()!=Some(state.as_str()){return Err(LauncherError::Config("OAuth state inválido; login abortado".into()))}let code=code.ok_or_else(||LauncherError::Config("Microsoft não retornou authorization code".into()))?;
    let token=exchange_code(&m.auth.token_url,&m.auth.client_id,&code,&redirect,&verifier,&m.auth.scope).await?;let refresh=token.refresh_token.ok_or_else(||LauncherError::Config("Microsoft não retornou refresh_token; confira offline_access".into()))?;let session=minecraft_from_msa(&token.access_token,&m.auth.client_id).await?;save_refresh(&refresh)?;let profile=MicrosoftProfile{connected:true,minecraft_name:session.name,minecraft_uuid:session.uuid};save_profile(&profile)?;Ok(profile)
}

pub async fn session()->Result<MinecraftSession>{
    let m=manifest::load_local()?;let refresh=load_refresh()?;let token=refresh_msa(&refresh).await?;if let Some(new)=token.refresh_token.as_deref(){save_refresh(new)?;}let session=minecraft_from_msa(&token.access_token,&m.auth.client_id).await?;let profile=MicrosoftProfile{connected:true,minecraft_name:session.name.clone(),minecraft_uuid:session.uuid.clone()};save_profile(&profile)?;Ok(session)
}
