use std::{fs, path::{Path, PathBuf}, time::{SystemTime, UNIX_EPOCH}};
use serde::{Deserialize, Serialize};
use crate::{error::{LauncherError, Result}, manifest, models::{BackupInfo, LauncherSettings}, paths};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct BackupMeta {
    id: String,
    created_at: String,
    pack_version: String,
    files: usize,
    bytes: u64,
}

fn timestamp_id() -> String {
    let secs=SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
    format!("{secs}")
}

fn copy_or_link(src:&Path,dst:&Path)->Result<u64>{
    if let Some(parent)=dst.parent(){fs::create_dir_all(parent)?;}
    if fs::hard_link(src,dst).is_err(){fs::copy(src,dst)?;}
    Ok(fs::metadata(src)?.len())
}

fn read_meta(dir:&Path)->Option<BackupMeta>{
    serde_json::from_str(&fs::read_to_string(dir.join("backup.json")).ok()?).ok()
}

pub fn create(settings:&LauncherSettings)->Result<BackupInfo>{
    paths::ensure_layout()?;
    let manifest=manifest::load_previous().unwrap_or(manifest::load_local()?);
    let id=timestamp_id();
    let dir=paths::backups_dir()?.join(&id);
    let files_dir=dir.join("files");
    fs::create_dir_all(&files_dir)?;
    let instance=paths::instance_dir()?;
    let mut count=0usize; let mut bytes=0u64;
    for file in manifest.files.iter().filter(|f| f.mode=="managed" || (f.mode=="optional" && settings.optional_enabled.iter().any(|x|x==&f.id))) {
        let src=instance.join(&file.path);
        if src.is_file(){ bytes+=copy_or_link(&src,&files_dir.join(&file.path))?; count+=1; }
    }
    fs::copy(paths::manifest_path()?,dir.join("manifest.json"))?;
    let meta=BackupMeta{id:id.clone(),created_at:id.clone(),pack_version:manifest.pack.version.clone(),files:count,bytes};
    fs::write(dir.join("backup.json"),serde_json::to_vec_pretty(&meta)?)?;
    prune(settings.backup_limit)?;
    Ok(BackupInfo{id,created_at:meta.created_at,pack_version:meta.pack_version,files:count,bytes})
}

pub fn list()->Result<Vec<BackupInfo>>{
    let dir=paths::backups_dir()?; fs::create_dir_all(&dir)?;
    let mut items=vec![];
    for entry in fs::read_dir(dir)? {
        let entry=entry?; if !entry.file_type()?.is_dir(){continue;}
        if let Some(m)=read_meta(&entry.path()){items.push(BackupInfo{id:m.id,created_at:m.created_at,pack_version:m.pack_version,files:m.files,bytes:m.bytes});}
    }
    items.sort_by(|a,b|b.id.cmp(&a.id)); Ok(items)
}

pub fn prune(limit:u8)->Result<()> {
    let items=list()?;
    for item in items.into_iter().skip(limit as usize){ let p=paths::backups_dir()?.join(item.id); let _=fs::remove_dir_all(p); }
    Ok(())
}

fn restore_tree(src:&Path,dst:&Path,count:&mut usize)->Result<()> {
    if !src.exists(){return Ok(())}
    for entry in fs::read_dir(src)?{
        let entry=entry?; let p=entry.path(); let rel=p.strip_prefix(src).map_err(|_|LauncherError::Config("Backup inválido".into()))?; let out=dst.join(rel);
        if entry.file_type()?.is_dir(){fs::create_dir_all(&out)?; restore_tree(&p,&out,count)?;} else {if let Some(parent)=out.parent(){fs::create_dir_all(parent)?;} fs::copy(&p,&out)?; *count+=1;}
    } Ok(())
}

pub fn rollback(id:&str)->Result<usize>{
    if id.is_empty() || !id.chars().all(|c|c.is_ascii_digit()){return Err(LauncherError::Config("ID de backup inválido".into()))}
    let dir=paths::backups_dir()?.join(id); if !dir.exists(){return Err(LauncherError::Config("Backup não encontrado".into()))}
    let mut count=0usize; restore_tree(&dir.join("files"),&paths::instance_dir()?,&mut count)?;
    let backed_manifest=dir.join("manifest.json"); if backed_manifest.exists(){fs::copy(backed_manifest,paths::manifest_path()?)?;}
    Ok(count)
}

pub fn delete(id:&str)->Result<()> {
    if id.is_empty() || !id.chars().all(|c|c.is_ascii_digit()){return Err(LauncherError::Config("ID de backup inválido".into()))}
    let dir=paths::backups_dir()?.join(id); if dir.exists(){fs::remove_dir_all(dir)?;} Ok(())
}
