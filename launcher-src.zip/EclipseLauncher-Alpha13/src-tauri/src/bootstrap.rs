use std::{fs, io::{Read, Write}, path::{Path, PathBuf}};
use futures_util::StreamExt;
use serde::Deserialize;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use tokio::process::Command as TokioCommand;
use crate::{
    error::{LauncherError, Result},
    launch,
    manifest,
    minecraft,
    models::{BootstrapMarker, BootstrapReport, ForgeInstallReport, LauncherSettings, RuntimeInstallReport},
    paths,
};

#[derive(Debug, Deserialize)]
struct AdoptiumPackage { link: String, checksum: String, name: String }
#[derive(Debug, Deserialize)]
struct AdoptiumBinary { package: AdoptiumPackage }
#[derive(Debug, Deserialize)]
struct AdoptiumRelease { binary: AdoptiumBinary }

fn marker_path() -> Result<PathBuf> { Ok(paths::instance_dir()?.join(".eclipse").join("bootstrap.json")) }

pub fn load_marker() -> Option<BootstrapMarker> {
    let path = marker_path().ok()?;
    let text = fs::read_to_string(path).ok()?;
    serde_json::from_str(&text).ok()
}

pub fn forge_ready() -> bool {
    let Some(marker) = load_marker() else { return false; };
    let Ok(current) = manifest::load_local() else { return false; };
    if marker.minecraft != current.pack.minecraft || marker.forge != current.pack.forge { return false; }
    let home = PathBuf::from(marker.minecraft_home);
    home.join("versions").join(marker.version_id).exists()
}

pub fn official_profile_ready() -> bool {
    let Some(marker) = load_marker() else { return false; };
    let home = PathBuf::from(marker.minecraft_home);
    for name in ["launcher_profiles.json", "launcher_profiles_microsoft_store.json"] {
        let p = home.join(name);
        if let Ok(text) = fs::read_to_string(p) {
            if let Ok(v) = serde_json::from_str::<Value>(&text) {
                if let Some(profile) = v.get("profiles").and_then(|x| x.get("eclipse-smp")) {
                    if profile.get("lastVersionId").and_then(|x| x.as_str()) == Some(marker.version_id.as_str()) { return true; }
                }
            }
        }
    }
    false
}

fn platform_arch() -> Result<(&'static str, &'static str)> {
    #[cfg(target_os = "windows")]
    let os = "windows";
    #[cfg(target_os = "linux")]
    let os = "linux";
    #[cfg(target_os = "macos")]
    let os = "mac";
    #[cfg(not(any(target_os="windows", target_os="linux", target_os="macos")))]
    return Err(LauncherError::Config("Sistema não suportado pelo bootstrap Java".into()));

    let arch = match std::env::consts::ARCH {
        "x86_64" => "x64",
        "aarch64" => "aarch64",
        other => return Err(LauncherError::Config(format!("Arquitetura Java não suportada: {other}"))),
    };
    Ok((os, arch))
}

async fn download_with_hash(client: &reqwest::Client, url: &str, expected_sha256: &str, target: &Path) -> Result<u64> {
    let response = client.get(url).send().await?.error_for_status()?;
    if let Some(parent) = target.parent() { tokio::fs::create_dir_all(parent).await?; }
    let part = target.with_extension("part");
    let _ = tokio::fs::remove_file(&part).await;
    let mut out = tokio::fs::File::create(&part).await?;
    let mut stream = response.bytes_stream();
    let mut hasher = Sha256::new();
    let mut written = 0u64;
    use tokio::io::AsyncWriteExt;
    while let Some(chunk) = stream.next().await {
        let chunk = chunk?;
        out.write_all(&chunk).await?;
        hasher.update(&chunk);
        written += chunk.len() as u64;
    }
    out.flush().await?;
    drop(out);
    let got = hex::encode(hasher.finalize());
    if !got.eq_ignore_ascii_case(expected_sha256.trim()) {
        let _ = tokio::fs::remove_file(&part).await;
        return Err(LauncherError::Integrity("SHA-256 do download não confere".into()));
    }
    let _ = tokio::fs::remove_file(target).await;
    tokio::fs::rename(&part, target).await?;
    Ok(written)
}

fn find_java_home(dir: &Path, depth: usize) -> Option<PathBuf> {
    if depth > 4 { return None; }
    let java = dir.join("bin").join(if cfg!(target_os="windows") { "java.exe" } else { "java" });
    if java.exists() { return Some(dir.to_path_buf()); }
    let entries = fs::read_dir(dir).ok()?;
    for e in entries.flatten() {
        if e.file_type().ok()?.is_dir() {
            if let Some(found) = find_java_home(&e.path(), depth + 1) { return Some(found); }
        }
    }
    None
}

fn extract_zip_safely(archive: &Path, staging: &Path) -> Result<PathBuf> {
    if staging.exists() { fs::remove_dir_all(staging)?; }
    fs::create_dir_all(staging)?;
    let file = fs::File::open(archive)?;
    let mut zip = zip::ZipArchive::new(file).map_err(|e| LauncherError::Config(format!("ZIP do Java inválido: {e}")))?;
    for i in 0..zip.len() {
        let mut item = zip.by_index(i).map_err(|e| LauncherError::Config(format!("Falha lendo ZIP do Java: {e}")))?;
        let Some(rel) = item.enclosed_name().map(|p| p.to_owned()) else { continue; };
        let out = staging.join(rel);
        if item.is_dir() { fs::create_dir_all(&out)?; continue; }
        if let Some(parent) = out.parent() { fs::create_dir_all(parent)?; }
        let mut output = fs::File::create(&out)?;
        std::io::copy(&mut item, &mut output)?;
    }
    find_java_home(staging, 0).ok_or_else(|| LauncherError::Config("Java extraído, mas bin/java não foi encontrado".into()))
}

pub async fn install_runtime(java_major: u32) -> Result<RuntimeInstallReport> {
    if launch::runtime_ready()? {
        return Ok(RuntimeInstallReport { installed: false, java_major, path: launch::runtime_console_path()?.display().to_string(), bytes_downloaded: 0 });
    }
    #[cfg(not(target_os = "windows"))]
    return Err(LauncherError::Config("Alpha 6 automatiza o runtime no Windows; Linux/macOS ficam para a próxima etapa.".into()));

    #[cfg(target_os = "windows")]
    {
        let (os, arch) = platform_arch()?;
        let api = format!("https://api.adoptium.net/v3/assets/latest/{java_major}/hotspot?architecture={arch}&image_type=jre&os={os}&vendor=eclipse");
        let client = reqwest::Client::builder().user_agent("EclipseLauncher/1.0").timeout(std::time::Duration::from_secs(300)).build()?;
        let releases = client.get(api).send().await?.error_for_status()?.json::<Vec<AdoptiumRelease>>().await?;
        let release = releases.into_iter().next().ok_or_else(|| LauncherError::Config(format!("Temurin JRE {java_major} não encontrado para {os}/{arch}")))?;
        let cache = paths::cache_dir()?.join("runtime");
        tokio::fs::create_dir_all(&cache).await?;
        let archive = cache.join(&release.binary.package.name);
        let bytes = download_with_hash(&client, &release.binary.package.link, &release.binary.package.checksum, &archive).await?;
        let staging = paths::root_dir()?.join("runtime-staging");
        let archive_for_extract = archive.clone();
        let staging_for_extract = staging.clone();
        let java_home = tokio::task::spawn_blocking(move || extract_zip_safely(&archive_for_extract, &staging_for_extract))
            .await.map_err(|e| LauncherError::Config(format!("Falha na extração do Java: {e}")))??;
        let runtime = paths::runtime_dir()?;
        if runtime.exists() { fs::remove_dir_all(&runtime)?; }
        fs::rename(&java_home, &runtime)?;
        if staging.exists() { let _ = fs::remove_dir_all(&staging); }
        Ok(RuntimeInstallReport { installed: true, java_major, path: launch::runtime_console_path()?.display().to_string(), bytes_downloaded: bytes })
    }
}

pub fn minecraft_home() -> Result<PathBuf> {
    #[cfg(target_os="windows")]
    {
        let appdata = std::env::var_os("APPDATA").ok_or_else(|| LauncherError::Config("APPDATA não encontrado".into()))?;
        return Ok(PathBuf::from(appdata).join(".minecraft"));
    }
    #[cfg(not(target_os="windows"))]
    { Ok(dirs::home_dir().ok_or_else(|| LauncherError::Config("Home não encontrada".into()))?.join(".minecraft")) }
}

fn atomic_json_write(path: &Path, value: &Value) -> Result<()> {
    let text = serde_json::to_vec_pretty(value)?;
    let tmp = path.with_extension("json.eclipse-tmp");
    let bak = path.with_extension("json.eclipse-bak");
    fs::write(&tmp, text)?;
    if path.exists() {
        if bak.exists() { let _ = fs::remove_file(&bak); }
        fs::copy(path, &bak)?;
    }
    if let Err(e) = fs::rename(&tmp, path) {
        if bak.exists() { let _ = fs::copy(&bak, path); }
        let _ = fs::remove_file(&tmp);
        return Err(e.into());
    }
    let _ = fs::remove_file(&bak);
    Ok(())
}

fn ensure_launcher_profiles_file(home: &Path) -> Result<()> {
    let traditional = home.join("launcher_profiles.json");
    let store = home.join("launcher_profiles_microsoft_store.json");
    if !traditional.exists() && !store.exists() {
        let minimal = json!({"profiles":{},"settings":{},"version":3});
        atomic_json_write(&traditional, &minimal)?;
    }
    Ok(())
}

fn update_launcher_profiles(home: &Path, settings: &LauncherSettings, version_id: &str) -> Result<usize> {
    let runtime = launch::runtime_path()?;
    let game_dir = paths::instance_dir()?;
    let mut updated = 0usize;
    let mut candidates = vec![];
    for name in ["launcher_profiles.json", "launcher_profiles_microsoft_store.json"] {
        let p = home.join(name);
        if p.exists() { candidates.push(p); }
    }
    if candidates.is_empty() {
        return Err(LauncherError::Config("O Minecraft Launcher ainda não criou os arquivos de perfil. Abra o launcher oficial uma vez e tente novamente.".into()));
    }
    for path in candidates {
        let text = fs::read_to_string(&path)?;
        let mut root: Value = serde_json::from_str(&text)?;
        if !root.is_object() { root = json!({}); }
        if root.get("profiles").and_then(|v| v.as_object()).is_none() { root["profiles"] = json!({}); }
        let profile = json!({
            "name": "Eclipse SMP",
            "type": "custom",
            "gameDir": game_dir.display().to_string(),
            "lastVersionId": version_id,
            "javaDir": runtime.display().to_string(),
            "javaArgs": format!("-Xms{}M -Xmx{}M", std::cmp::min(2048, settings.ram_mb), settings.ram_mb)
        });
        root["profiles"]["eclipse-smp"] = profile;
        root["selectedProfile"] = json!("eclipse-smp");
        atomic_json_write(&path, &root)?;
        updated += 1;
    }
    Ok(updated)
}

fn find_forge_version_id(home: &Path, minecraft: &str, forge: &str) -> Result<String> {
    let versions = home.join("versions");
    if !versions.exists() { return Err(LauncherError::Config("Pasta versions do Minecraft não existe após instalar Forge".into())); }
    let mut matches = vec![];
    for entry in fs::read_dir(versions)? {
        let entry = entry?;
        if !entry.file_type()?.is_dir() { continue; }
        let name = entry.file_name().to_string_lossy().to_string();
        if name.contains(minecraft) && name.contains(forge) {
            let json_path = entry.path().join(format!("{name}.json"));
            if json_path.exists() {
                if let Ok(value) = serde_json::from_str::<Value>(&fs::read_to_string(&json_path)?) {
                    if let Some(id) = value.get("id").and_then(|v| v.as_str()) { matches.push(id.to_string()); continue; }
                }
                matches.push(name);
            }
        }
    }
    matches.sort();
    matches.pop().ok_or_else(|| LauncherError::Config(format!("Forge {minecraft}-{forge} foi executado, mas a versão instalada não foi localizada")))
}

pub async fn install_forge_and_profile(settings: &LauncherSettings) -> Result<ForgeInstallReport> {
    if !launch::runtime_ready()? { return Err(LauncherError::Config("Instale o Java gerenciado antes do Forge".into())); }
    let m = manifest::load_local()?;
    if m.pack.forge.contains('x') || m.pack.forge.trim().is_empty() {
        return Err(LauncherError::Config("O manifesto precisa informar uma versão exata do Forge, por exemplo 47.4.10".into()));
    }
    let home = minecraft_home()?;
    fs::create_dir_all(&home)?;
    ensure_launcher_profiles_file(&home)?;
    let full = format!("{}-{}", m.pack.minecraft, m.pack.forge);
    let base = format!("https://maven.minecraftforge.net/net/minecraftforge/forge/{full}/forge-{full}-installer.jar");
    let sha_url = format!("{base}.sha256");
    let client = reqwest::Client::builder().user_agent("EclipseLauncher/1.0").timeout(std::time::Duration::from_secs(600)).build()?;
    let expected = client.get(&sha_url).send().await?.error_for_status()?.text().await?;
    let expected = expected.split_whitespace().next().ok_or_else(|| LauncherError::Integrity("SHA-256 do instalador Forge vazio".into()))?.to_string();
    if expected.len() != 64 || !expected.chars().all(|c| c.is_ascii_hexdigit()) {
        return Err(LauncherError::Integrity("SHA-256 do instalador Forge inválido".into()));
    }
    let cache = paths::cache_dir()?.join("forge");
    tokio::fs::create_dir_all(&cache).await?;
    let installer = cache.join(format!("forge-{full}-installer.jar"));
    let bytes = download_with_hash(&client, &base, &expected, &installer).await?;

    let output = TokioCommand::new(launch::runtime_console_path()?)
        .arg("-jar").arg(&installer)
        .arg("--installClient").arg(&home)
        .output().await
        .map_err(|e| LauncherError::Config(format!("Falha ao executar instalador Forge: {e}")))?;
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        let stdout = String::from_utf8_lossy(&output.stdout);
        return Err(LauncherError::Config(format!("Forge Installer falhou ({}): {} {}", output.status, stdout.trim(), stderr.trim())));
    }

    let version_id = find_forge_version_id(&home, &m.pack.minecraft, &m.pack.forge)?;
    let profile_files_updated = update_launcher_profiles(&home, settings, &version_id)?;
    let direct_files_prepared = minecraft::prepare(&home, &version_id, &m.pack.minecraft).await?;
    let marker = BootstrapMarker {
        minecraft_home: home.display().to_string(),
        version_id: version_id.clone(),
        minecraft: m.pack.minecraft.clone(),
        forge: m.pack.forge.clone(),
        java_major: m.launch.java_major.unwrap_or(17),
    };
    let marker_path = marker_path()?;
    if let Some(parent) = marker_path.parent() { fs::create_dir_all(parent)?; }
    fs::write(marker_path, serde_json::to_vec_pretty(&marker)?)?;
    Ok(ForgeInstallReport { installed: true, forge_version: m.pack.forge, version_id, profile_files_updated, installer_bytes: bytes, direct_files_prepared })
}

pub fn repair_official_profile(settings: &LauncherSettings) -> Result<ForgeInstallReport> {
    let marker = load_marker().ok_or_else(|| LauncherError::Config("Bootstrap Forge ainda não foi concluído".into()))?;
    let home = PathBuf::from(&marker.minecraft_home);
    let count = update_launcher_profiles(&home, settings, &marker.version_id)?;
    Ok(ForgeInstallReport { installed: false, forge_version: marker.forge, version_id: marker.version_id, profile_files_updated: count, installer_bytes: 0, direct_files_prepared: minecraft::direct_ready() })
}

pub async fn bootstrap_all(settings: &LauncherSettings) -> Result<BootstrapReport> {
    let m = manifest::load_local()?;
    let java_major = m.launch.java_major.unwrap_or(17);
    let runtime = install_runtime(java_major).await?;
    let forge = if forge_ready() && official_profile_ready() {
        let marker = load_marker().unwrap_or_default();
        ForgeInstallReport { installed: false, forge_version: marker.forge, version_id: marker.version_id, profile_files_updated: 0, installer_bytes: 0, direct_files_prepared: minecraft::direct_ready() }
    } else {
        install_forge_and_profile(settings).await?
    };
    Ok(BootstrapReport { runtime, forge })
}
