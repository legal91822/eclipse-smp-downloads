use std::{collections::{HashMap,HashSet}, fs, path::Path};
use crate::{error::Result, integrity, manifest, models::{ConflictReport,LauncherSettings}, paths};

fn mod_key(name:&str)->String{
    let lower=name.to_ascii_lowercase().trim_end_matches(".jar").to_string();
    let parts:Vec<&str>=lower.split('-').collect();
    let mut kept=vec![];
    for part in parts{
        if !kept.is_empty() && part.chars().next().map(|c|c.is_ascii_digit()).unwrap_or(false){break;}
        kept.push(part);
    }
    if kept.is_empty(){lower}else{kept.join("-")}
}

pub fn scan(settings:&LauncherSettings)->Result<ConflictReport>{
    let m=match manifest::load_local(){Ok(v)=>v,Err(_)=>return Ok(ConflictReport::default())};
    let verify=integrity::verify_with_settings(settings)?;
    let instance=paths::instance_dir()?;
    let mods=instance.join("mods");
    let mut known=HashSet::new();
    for f in &m.files{
        if f.path.to_ascii_lowercase().starts_with("mods/"){
            known.insert(Path::new(&f.path).file_name().unwrap_or_default().to_string_lossy().to_ascii_lowercase());
        }
    }
    let mut extra=vec![]; let mut groups:HashMap<String,Vec<String>>=HashMap::new();
    if mods.exists(){
        for e in fs::read_dir(&mods)?{
            let e=e?; if !e.file_type()?.is_file(){continue;}
            let name=e.file_name().to_string_lossy().to_string();
            if !name.to_ascii_lowercase().ends_with(".jar"){continue;}
            if !known.contains(&name.to_ascii_lowercase()){extra.push(name.clone());}
            groups.entry(mod_key(&name)).or_default().push(name);
        }
    }
    let mut duplicates=vec![];
    for (_k,mut names) in groups{if names.len()>1{names.sort();duplicates.push(names.join("  ↔  "));}}
    extra.sort(); duplicates.sort();
    Ok(ConflictReport{extra_mods:extra,duplicate_mods:duplicates,missing_managed:verify.missing,corrupted_managed:verify.corrupted})
}
