use std::fs;
use serde::{de::DeserializeOwned,Serialize};
use crate::{error::{LauncherError,Result},manifest,models::{EventItem,NewsItem},paths};
fn client()->Result<reqwest::Client>{Ok(reqwest::Client::builder().user_agent("EclipseLauncher/1.0").connect_timeout(std::time::Duration::from_secs(8)).timeout(std::time::Duration::from_secs(15)).build()?)}
fn cache<T:Serialize>(name:&str,data:&T)->Result<()>{let p=paths::cache_dir()?.join("api").join(name);if let Some(parent)=p.parent(){fs::create_dir_all(parent)?;}fs::write(p,serde_json::to_vec(data)?)?;Ok(())}
fn load_cache<T:DeserializeOwned+Default>(name:&str)->T{paths::cache_dir().ok().and_then(|p|fs::read_to_string(p.join("api").join(name)).ok()).and_then(|s|serde_json::from_str(&s).ok()).unwrap_or_default()}
async fn fetch_or_cache<T:DeserializeOwned+Serialize+Default>(endpoint:Option<String>,name:&str)->Result<T>{let Some(url)=endpoint else{return Ok(load_cache(name))};match client()?.get(url).send().await.and_then(|r|r.error_for_status()){Ok(r)=>{let v=r.json::<T>().await?;let _=cache(name,&v);Ok(v)},Err(_)=>Ok(load_cache(name))}}
pub async fn fetch_news()->Result<Vec<NewsItem>>{let m=manifest::load_local()?;let data:Vec<NewsItem>=fetch_or_cache(m.endpoints.news,"news.json").await?;if data.len()>100{return Err(LauncherError::Config("API de notícias retornou itens demais".into()))}Ok(data)}
pub async fn fetch_events()->Result<Vec<EventItem>>{let m=manifest::load_local()?;let data:Vec<EventItem>=fetch_or_cache(m.endpoints.events,"events.json").await?;if data.len()>100{return Err(LauncherError::Config("API de eventos retornou itens demais".into()))}Ok(data.into_iter().filter(|e|e.enabled).collect())}
