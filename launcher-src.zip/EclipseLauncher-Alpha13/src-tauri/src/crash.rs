use std::{collections::HashSet,fs,io::{Read,Write},path::{Path,PathBuf},time::UNIX_EPOCH};
use crate::{conflicts,error::{LauncherError,Result},models::{CrashAnalysis,LauncherSettings,SupportBundleReport},paths};

fn newest_file(dir:&Path,filter:impl Fn(&Path)->bool)->Option<PathBuf>{
    let mut files=vec![];for e in fs::read_dir(dir).ok()?.flatten(){let p=e.path();if p.is_file()&&filter(&p){let t=e.metadata().ok()?.modified().ok()?.duration_since(UNIX_EPOCH).ok()?.as_secs();files.push((t,p));}}files.sort_by_key(|x|x.0);files.pop().map(|x|x.1)
}
fn read_limited(path:&Path)->Result<String>{let mut f=fs::File::open(path)?;let len=f.metadata()?.len();if len>2_000_000{use std::io::Seek;f.seek(std::io::SeekFrom::End(-2_000_000))?;}let mut s=String::new();f.read_to_string(&mut s)?;Ok(s)}
fn sanitize(mut s:String)->String{
    if let Some(home)=dirs::home_dir(){let h=home.display().to_string();s=s.replace(&h,"<USER_HOME>");s=s.replace(&h.replace('\\',"/"),"<USER_HOME>");}
    for key in ["access_token","refresh_token","Authorization: Bearer","Bearer ey"]{if let Some(pos)=s.find(key){let end=(pos+160).min(s.len());s.replace_range(pos..end,"<REDACTED_TOKEN>");}}
    s
}
fn extract_jars(text:&str)->Vec<String>{let mut out=HashSet::new();for token in text.split(|c:char|c.is_whitespace()||matches!(c,'(' | ')' | '[' | ']' | ',' | ';' | '"' | '\'')){let t=token.trim_matches(|c:char|!c.is_ascii_alphanumeric()&&c!='.'&&c!='-'&&c!='_');if t.to_ascii_lowercase().ends_with(".jar")&&t.len()<180{out.insert(t.to_string());}}let mut v:Vec<_>=out.into_iter().collect();v.sort();v.truncate(12);v}

pub fn analyze()->Result<CrashAnalysis>{
    let instance=paths::instance_dir()?;let crash_dir=instance.join("crash-reports");let logs=instance.join("logs");
    let candidate=newest_file(&crash_dir,|p|p.extension().and_then(|x|x.to_str())==Some("txt")).or_else(||newest_file(&logs,|p|p.file_name().and_then(|x|x.to_str())==Some("latest.log")));
    let Some(path)=candidate else{return Ok(CrashAnalysis{found:false,summary:"Nenhum crash-report/latest.log foi encontrado.".into(),suggested_action:"Abra o jogo uma vez para gerar logs.".into(),..Default::default()})};
    let text=sanitize(read_limited(&path)?);let mut causes=vec![];
    for line in text.lines(){let l=line.trim();if l.contains("Caused by:")||l.contains("Failure message:")||l.contains("NoClassDefFoundError")||l.contains("Mixin")||l.contains("Exception")||l.contains("Mod File:"){let mut x=l.to_string();if x.len()>220{x.truncate(220);}if !causes.contains(&x){causes.push(x);}if causes.len()>=8{break;}}}
    let jars=extract_jars(&text);let summary=if let Some(c)=causes.first(){c.clone()}else{"O jogo fechou sem uma causa explícita nas linhas analisadas.".into()};
    let action=if !jars.is_empty(){"Verifique os mods citados e rode Reparar instalação. Se persistir, gere o pacote de suporte."}else{"Rode a verificação/reparo e gere o pacote de suporte se o crash persistir."};
    Ok(CrashAnalysis{found:true,source:path.display().to_string(),summary,probable_mods:jars,probable_causes:causes,suggested_action:action.into()})
}

fn zip_text<W:Write+std::io::Seek>(zip:&mut zip::ZipWriter<W>,name:&str,text:&str)->Result<u64>{
    let opt=zip::write::SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated);zip.start_file(name,opt).map_err(|e|LauncherError::Config(format!("ZIP suporte: {e}")))?;zip.write_all(text.as_bytes())?;Ok(text.len() as u64)
}

pub fn support_bundle(settings:&LauncherSettings)->Result<SupportBundleReport>{
    paths::ensure_layout()?;let id=std::time::SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();let target=paths::support_dir()?.join(format!("Eclipse-Support-{id}.zip"));let file=fs::File::create(&target)?;let mut zip=zip::ZipWriter::new(file);let mut count=0usize;let mut bytes=0u64;
    let crash=analyze()?;bytes+=zip_text(&mut zip,"crash-analysis.json",&serde_json::to_string_pretty(&crash)?)?;count+=1;
    let conflicts=conflicts::scan(settings)?;bytes+=zip_text(&mut zip,"conflicts.json",&serde_json::to_string_pretty(&conflicts)?)?;count+=1;
    if let Ok(m)=crate::manifest::load_local(){bytes+=zip_text(&mut zip,"manifest-summary.json",&serde_json::to_string_pretty(&m.pack)?)?;count+=1;}
    let instance=paths::instance_dir()?;for (src,name) in [(instance.join("logs/latest.log"),"logs/latest.log".to_string())]{if src.exists(){let t=sanitize(read_limited(&src)?);bytes+=zip_text(&mut zip,&name,&t)?;count+=1;}}
    if let Some(src)=newest_file(&instance.join("crash-reports"),|p|p.extension().and_then(|x|x.to_str())==Some("txt")){let t=sanitize(read_limited(&src)?);bytes+=zip_text(&mut zip,"crash-reports/latest-crash.txt",&t)?;count+=1;}
    zip.finish().map_err(|e|LauncherError::Config(format!("Falha finalizando ZIP: {e}")))?;Ok(SupportBundleReport{path:target.display().to_string(),files:count,bytes})
}
