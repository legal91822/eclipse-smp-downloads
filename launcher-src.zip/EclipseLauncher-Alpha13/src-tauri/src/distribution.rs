use std::fs;
use serde::{de::DeserializeOwned, Serialize};
use crate::{error::{LauncherError, Result}, models::{DistributionChannels, LauncherSettings}, paths, release, settings};

fn client() -> Result<reqwest::Client> {
    Ok(reqwest::Client::builder()
        .user_agent("EclipseLauncher/1.0")
        .connect_timeout(std::time::Duration::from_secs(8))
        .timeout(std::time::Duration::from_secs(15))
        .build()?)
}

fn cache_path() -> Result<std::path::PathBuf> {
    Ok(paths::cache_dir()?.join("distribution/channels.json"))
}

fn validate_https(label:&str, value:&str)->Result<()> {
    if value.trim().is_empty(){return Ok(())}
    let parsed=url::Url::parse(value).map_err(|_|LauncherError::Config(format!("{label} inválida")))?;
    if parsed.scheme()!="https" && !(cfg!(debug_assertions)&&parsed.scheme()=="http") {
        return Err(LauncherError::Config(format!("{label} precisa usar HTTPS")));
    }
    Ok(())
}

fn validate(ch:&DistributionChannels)->Result<()> {
    if ch.stable.trim().is_empty(){return Err(LauncherError::Config("Bootstrap não informou manifesto Stable".into()))}
    validate_https("Manifesto Stable",&ch.stable)?;
    validate_https("Manifesto Beta",&ch.beta)?;
    validate_https("Manifesto Staff",&ch.staff)?;
    Ok(())
}

fn write_cache<T:Serialize>(data:&T)->Result<()> {
    let p=cache_path()?; if let Some(parent)=p.parent(){fs::create_dir_all(parent)?;}
    let tmp=p.with_extension("json.tmp"); fs::write(&tmp,serde_json::to_vec_pretty(data)?)?; fs::rename(tmp,p)?; Ok(())
}
fn read_cache<T:DeserializeOwned>()->Option<T>{let p=cache_path().ok()?;serde_json::from_str(&fs::read_to_string(p).ok()?).ok()}

fn compiled_channels()->Option<DistributionChannels>{
    let ch=DistributionChannels{
        stable:release::value("ECLIPSE_STABLE_MANIFEST_URL"),
        beta:release::value("ECLIPSE_BETA_MANIFEST_URL"),
        staff:release::value("ECLIPSE_STAFF_MANIFEST_URL"),
    };
    if ch.stable.trim().is_empty(){None}else{Some(ch)}
}

pub async fn fetch_channels(settings:&LauncherSettings)->Result<DistributionChannels> {
    let bootstrap=if settings.bootstrap_url.trim().is_empty(){release::value("ECLIPSE_BOOTSTRAP_URL")}else{settings.bootstrap_url.clone()};
    if bootstrap.trim().is_empty(){
        if let Some(ch)=compiled_channels(){validate(&ch)?;return Ok(ch)}
        return Err(LauncherError::Config("URL bootstrap do Eclipse não configurada".into()))
    }
    validate_https("Bootstrap URL",&bootstrap)?;
    match client()?.get(&bootstrap).send().await.and_then(|r|r.error_for_status()) {
        Ok(resp)=>{
            let ch=resp.json::<DistributionChannels>().await?; validate(&ch)?; let _=write_cache(&ch); Ok(ch)
        }
        Err(err)=>{
            if let Some(ch)=read_cache::<DistributionChannels>(){validate(&ch)?;return Ok(ch)}
            if let Some(ch)=compiled_channels(){validate(&ch)?;return Ok(ch)}
            Err(err.into())
        }
    }
}

pub async fn refresh_settings() -> Result<LauncherSettings> {
    let mut s=settings::load()?;
    if s.bootstrap_url.trim().is_empty(){s.bootstrap_url=release::value("ECLIPSE_BOOTSTRAP_URL");}
    let ch=fetch_channels(&s).await?;
    s.stable_manifest_url=ch.stable;
    s.beta_manifest_url=ch.beta;
    s.staff_manifest_url=ch.staff;
    if s.manifest_url.trim().is_empty(){s.manifest_url=s.stable_manifest_url.clone();}
    settings::save(&s)?;
    Ok(s)
}

pub async fn ensure_active_manifest_url() -> Result<LauncherSettings> {
    let s=settings::load()?;
    if !settings::active_manifest_url(&s).trim().is_empty(){return Ok(s)}
    refresh_settings().await
}
