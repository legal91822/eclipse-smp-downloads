use thiserror::Error;

pub type Result<T> = std::result::Result<T, LauncherError>;

#[derive(Debug, Error)]
pub enum LauncherError {
    #[error("Erro de arquivo: {0}")]
    Io(#[from] std::io::Error),
    #[error("JSON inválido: {0}")]
    Json(#[from] serde_json::Error),
    #[error("Falha de rede: {0}")]
    Network(#[from] reqwest::Error),
    #[error("Configuração inválida: {0}")]
    Config(String),
    #[error("Manifesto inválido: {0}")]
    Manifest(String),
    #[error("Launch indisponível: {0}")]
    Launch(String),
    #[error("Integridade inválida: {0}")]
    Integrity(String),
}

impl serde::Serialize for LauncherError {
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where S: serde::Serializer { serializer.serialize_str(&self.to_string()) }
}
