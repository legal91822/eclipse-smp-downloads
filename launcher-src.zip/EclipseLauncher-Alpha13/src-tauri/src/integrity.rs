use sha2::{Digest,Sha256};
use std::{fs::File,io::Read};
use crate::{error::Result, manifest, models::{LauncherSettings,ManagedFile,VerifyReport}, paths};

fn sha256(path:&std::path::Path)->Result<String>{
    let mut file=File::open(path)?; let mut h=Sha256::new(); let mut buf=[0u8;1024*1024];
    loop{let n=file.read(&mut buf)?;if n==0{break;}h.update(&buf[..n]);}
    Ok(hex::encode(h.finalize()))
}

fn enabled(file:&ManagedFile,settings:&LauncherSettings)->bool{
    match file.mode.as_str(){
        "managed"=>true,
        "optional"=>settings.optional_enabled.iter().any(|x|x==&file.id),
        _=>false,
    }
}

pub fn verify_with_settings(settings:&LauncherSettings)->Result<VerifyReport>{
    let m=manifest::load_local()?; let base=paths::instance_dir()?; let mut r=VerifyReport::default();
    for f in &m.files{
        if !enabled(f,settings){r.ignored.push(f.path.clone());continue;}
        r.checked+=1; let p=base.join(&f.path);
        if !p.exists(){r.missing.push(f.path.clone());continue;}
        let meta=std::fs::metadata(&p)?; if !meta.is_file()||meta.len()!=f.size{r.corrupted.push(f.path.clone());continue;}
        if sha256(&p)?.eq_ignore_ascii_case(&f.sha256){r.ok+=1}else{r.corrupted.push(f.path.clone());}
    }
    Ok(r)
}

pub fn verify()->Result<VerifyReport>{ let s=crate::settings::load()?; verify_with_settings(&s) }
