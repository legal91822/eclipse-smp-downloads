use serde::Deserialize;
use std::{path::{Path, PathBuf}, process::Command};
use crate::{error::{LauncherError, Result}, models::{LauncherSettings, MinecraftSession}, offline, paths};

#[derive(Debug, Deserialize)]
#[serde(default)]
struct LaunchSpec {
    main_class: String,
    classpath: Vec<String>,
    jvm_args: Vec<String>,
    game_args: Vec<String>,
    working_directory: Option<String>,
    minecraft_home: Option<String>,
    assets_index: Option<String>,
}
impl Default for LaunchSpec { fn default()->Self{Self{main_class:String::new(),classpath:vec![],jvm_args:vec![],game_args:vec![],working_directory:None,minecraft_home:None,assets_index:None}} }

#[derive(Debug,Clone)]
struct Identity { name:String,uuid:String,access_token:String,user_type:String,xuid:String,client_id:String }

pub fn locate_official_launcher(settings:&LauncherSettings)->Option<PathBuf>{
    if let Some(p)=settings.official_launcher_path.as_deref().map(PathBuf::from).filter(|p|p.exists()){return Some(p)}
    #[cfg(target_os="windows")]
    {let candidates=[std::env::var_os("ProgramFiles(x86)").map(PathBuf::from).map(|p|p.join("Minecraft Launcher/MinecraftLauncher.exe")),std::env::var_os("ProgramFiles").map(PathBuf::from).map(|p|p.join("Minecraft Launcher/MinecraftLauncher.exe")),std::env::var_os("LOCALAPPDATA").map(PathBuf::from).map(|p|p.join("Programs/Minecraft Launcher/MinecraftLauncher.exe"))];for p in candidates.into_iter().flatten(){if p.exists(){return Some(p)}}}None
}
#[cfg(target_os="windows")]
pub fn store_launcher_available()->bool{std::env::var_os("LOCALAPPDATA").map(PathBuf::from).map(|p|p.join("Packages/Microsoft.4297127D64EC6_8wekyb3d8bbwe")).map(|p|p.exists()).unwrap_or(false)}
#[cfg(not(target_os="windows"))] pub fn store_launcher_available()->bool{false}
pub fn official_launcher_ready(settings:&LauncherSettings)->bool{locate_official_launcher(settings).is_some()||store_launcher_available()}

pub fn runtime_path()->Result<PathBuf>{let dir=paths::runtime_dir()?.join("bin");let preferred=dir.join(if cfg!(target_os="windows"){"javaw.exe"}else{"java"});if preferred.exists(){return Ok(preferred)}Ok(dir.join(if cfg!(target_os="windows"){"java.exe"}else{"java"}))}
pub fn runtime_console_path()->Result<PathBuf>{Ok(paths::runtime_dir()?.join("bin").join(if cfg!(target_os="windows"){"java.exe"}else{"java"}))}
pub fn runtime_ready()->Result<bool>{Ok(runtime_console_path()?.exists())}
pub fn forge_ready()->Result<bool>{Ok(crate::bootstrap::forge_ready())}

fn expand(value:&str,_settings:&LauncherSettings,instance:&Path,root:&Path,spec:&LaunchSpec,id:&Identity)->String{
    let mc_home=spec.minecraft_home.as_deref().map(PathBuf::from).unwrap_or_else(||root.to_path_buf());
    let instance_s=instance.display().to_string(); let root_s=root.display().to_string();
    let assets_s=mc_home.join("assets").display().to_string(); let libs_s=mc_home.join("libraries").display().to_string(); let natives_s=instance.join(".eclipse/natives").display().to_string();
    let sep=if cfg!(target_os="windows"){";"}else{":"};
    let reps:Vec<(&str,String)>=vec![
        ("{auth_player_name}",id.name.clone()),("${auth_player_name}",id.name.clone()),
        ("{auth_uuid}",id.uuid.clone()),("${auth_uuid}",id.uuid.clone()),
        ("{auth_access_token}",id.access_token.clone()),("${auth_access_token}",id.access_token.clone()),
        ("{user_type}",id.user_type.clone()),("${user_type}",id.user_type.clone()),
        ("${xuid}",id.xuid.clone()),("${clientid}",id.client_id.clone()),
        ("{game_directory}",instance_s.clone()),("${game_directory}",instance_s),
        ("{launcher_root}",root_s),("{assets_root}",assets_s.clone()),("${assets_root}",assets_s),
        ("${assets_index_name}",spec.assets_index.clone().unwrap_or_else(||"1.20".into())),
        ("${natives_directory}",natives_s),("${library_directory}",libs_s),
        ("${launcher_name}","EclipseLauncher".into()),("${launcher_version}",env!("CARGO_PKG_VERSION").into()),
        ("${classpath_separator}",sep.into()),("${version_type}","Eclipse".into()),
    ];
    let mut s=value.to_string();for (a,b) in reps{s=s.replace(a,&b);}s
}

fn launch_identity(settings:&LauncherSettings,id:Identity)->Result<String>{
    if !runtime_ready()?{return Err(LauncherError::Launch("Runtime Java gerenciado ainda não foi instalado.".into()))}if !forge_ready()?{return Err(LauncherError::Launch("Forge ainda não foi preparado.".into()))}
    let instance=paths::instance_dir()?;let root=paths::root_dir()?;let spec_path=instance.join(".eclipse/launch.json");if !spec_path.exists(){return Err(LauncherError::Launch("Arquivos Direct/Offline ainda não foram preparados. Use Preparar Minecraft.".into()))}
    let spec:LaunchSpec=serde_json::from_str(&std::fs::read_to_string(&spec_path)?).map_err(|e|LauncherError::Launch(format!("launch.json inválido: {e}")))?;if spec.main_class.trim().is_empty()||spec.classpath.is_empty(){return Err(LauncherError::Launch("launch.json incompleto".into()))}
    let sep=if cfg!(target_os="windows"){";"}else{":"};let classpath=spec.classpath.iter().map(|p|{let expanded=expand(p,settings,&instance,&root,&spec,&id);let path=PathBuf::from(&expanded);if path.is_absolute(){path}else{root.join(path)}}).map(|p|p.display().to_string()).collect::<Vec<_>>().join(sep);
    let mut cmd=Command::new(runtime_path()?);cmd.arg(format!("-Xms{}M",std::cmp::min(2048,settings.ram_mb))).arg(format!("-Xmx{}M",settings.ram_mb));for a in &spec.jvm_args{cmd.arg(expand(a,settings,&instance,&root,&spec,&id));}cmd.arg("-cp").arg(classpath).arg(&spec.main_class);for a in &spec.game_args{cmd.arg(expand(a,settings,&instance,&root,&spec,&id));}
    let cwd=spec.working_directory.as_deref().map(|v|PathBuf::from(expand(v,settings,&instance,&root,&spec,&id))).unwrap_or_else(||instance.clone());cmd.current_dir(cwd);cmd.spawn().map_err(|e|LauncherError::Launch(format!("Falha ao iniciar Minecraft: {e}")))?;Ok(format!("Minecraft iniciado como {}.",id.name))
}

pub fn launch_offline(settings:&LauncherSettings)->Result<String>{let uuid=offline::minecraft_offline_uuid(&settings.offline_name).replace('-','');launch_identity(settings,Identity{name:settings.offline_name.clone(),uuid,access_token:"0".into(),user_type:"legacy".into(),xuid:String::new(),client_id:String::new()})}
pub fn launch_direct(settings:&LauncherSettings,session:MinecraftSession)->Result<String>{launch_identity(settings,Identity{name:session.name,uuid:session.uuid.replace('-',''),access_token:session.access_token,user_type:session.user_type,xuid:session.xuid,client_id:session.client_id})}
pub fn launch_official(settings:&LauncherSettings)->Result<String>{
    if !crate::bootstrap::official_profile_ready(){return Err(LauncherError::Launch("Perfil Eclipse SMP ainda não foi preparado. Use Preparar Minecraft primeiro.".into()))}
    if let Some(launcher)=locate_official_launcher(settings){Command::new(&launcher).spawn().map_err(|e|LauncherError::Launch(format!("Falha ao abrir {}: {e}",launcher.display())))?;}else if store_launcher_available(){#[cfg(target_os="windows")]Command::new("explorer.exe").arg("shell:AppsFolder\\Microsoft.4297127D64EC6_8wekyb3d8bbwe!Minecraft").spawn().map_err(|e|LauncherError::Launch(format!("Falha ao abrir Minecraft Launcher: {e}")))?;}else{return Err(LauncherError::Launch("Minecraft Launcher oficial não encontrado.".into()))}
    Ok("Minecraft Launcher oficial aberto com o perfil Eclipse SMP selecionado.".into())
}
