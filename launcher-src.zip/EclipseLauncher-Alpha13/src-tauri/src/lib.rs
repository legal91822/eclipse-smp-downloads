mod actions;
mod auth;
mod backup;
mod bootstrap;
mod conflicts;
mod content;
mod crash;
mod distribution;
mod error;
mod integrity;
mod launch;
mod logs;
mod manifest;
mod minecraft;
mod models;
mod offline;
mod pack;
mod paths;
mod provision;
mod release;
mod repair;
mod settings;
mod seed;
mod status;
mod system;
mod updater;

use models::{
    BackupInfo, BootstrapReport, CacheReport, ConflictReport, DiagnosticReport, DownloadProgress,
    EventItem, ForgeInstallReport, LauncherSettings, LauncherState, LaunchMode, LauncherUpdateInfo,
    MicrosoftProfile, NewsItem, OptionalModInfo, PackStats, Readiness, RepairReport, ServerStatus,
    SupportBundleReport, SystemProfile, VerifyReport, StartupReport, ProvisionReport, UpdateEstimate,
    PublicConfig, ReleaseReadiness, SeedPackStatus, SeedInstallReport,
};

fn readiness(settings:&LauncherSettings)->Result<Readiness,error::LauncherError>{
    Ok(Readiness{
        manifest:manifest::load_local().is_ok(),
        minecraft_runtime:launch::runtime_ready()?,
        forge:bootstrap::forge_ready(),
        official_launcher:launch::official_launcher_ready(settings),
        official_profile:bootstrap::official_profile_ready(),
        direct_files:minecraft::direct_ready(),
        microsoft_auth:auth::state().connected,
    })
}

fn enforce_min_version(required:Option<&str>)->Result<(),error::LauncherError>{
    let Some(required)=required else{return Ok(())};
    let current=semver::Version::parse(env!("CARGO_PKG_VERSION")).map_err(|_|error::LauncherError::Config("Versão local inválida".into()))?;
    let required=semver::Version::parse(required).map_err(|_|error::LauncherError::Config("Versão mínima remota inválida".into()))?;
    if current<required{return Err(error::LauncherError::Launch(format!("Eclipse Launcher {} ou superior é obrigatório.",required)))}Ok(())
}

#[tauri::command]
fn get_launcher_state()->Result<LauncherState,error::LauncherError>{
    paths::ensure_layout()?;logs::rotate()?;let settings=settings::load()?;let local=manifest::load_local().ok();let offline_uuid=if settings.offline_name.is_empty(){None}else{Some(offline::minecraft_offline_uuid(&settings.offline_name))};
    Ok(LauncherState{app_version:env!("CARGO_PKG_VERSION").into(),instance_dir:paths::instance_dir()?.display().to_string(),cache_dir:paths::cache_dir()?.display().to_string(),logs_dir:paths::logs_dir()?.display().to_string(),backups_dir:paths::backups_dir()?.display().to_string(),readiness:readiness(&settings)?,pack:local.map(|m|m.pack),settings,offline_uuid})
}

#[tauri::command]
fn save_settings(settings:LauncherSettings)->Result<(),error::LauncherError>{settings::save(&settings)?;if bootstrap::official_profile_ready(){let _=bootstrap::repair_official_profile(&settings);}logs::write("settings","Configurações salvas");Ok(())}
#[tauri::command] fn reset_settings()->Result<LauncherSettings,error::LauncherError>{settings::reset()}
#[tauri::command] fn verify_pack()->Result<VerifyReport,error::LauncherError>{integrity::verify()}
#[tauri::command] async fn repair_pack()->Result<RepairReport,error::LauncherError>{let s=settings::load()?;let r=repair::repair(&s).await;match &r{Ok(v)=>logs::write("repair",&format!("{} arquivos reparados",v.repaired)),Err(e)=>logs::write("repair-error",&e.to_string())}r}
#[tauri::command] fn repair_progress()->DownloadProgress{repair::progress()}
#[tauri::command] fn pause_downloads(){repair::pause()}
#[tauri::command] fn resume_downloads(){repair::resume()}
#[tauri::command] fn cancel_downloads(){repair::cancel()}


#[tauri::command] async fn refresh_distribution()->Result<LauncherSettings,error::LauncherError>{distribution::refresh_settings().await}
#[tauri::command] async fn startup_check()->Result<StartupReport,error::LauncherError>{provision::startup_check().await}
#[tauri::command] async fn estimate_pack_update()->Result<UpdateEstimate,error::LauncherError>{let s=settings::load()?;repair::estimate(&s).await}
#[tauri::command] async fn provision_installation()->Result<ProvisionReport,error::LauncherError>{provision::provision_all().await}

#[tauri::command]
async fn sync_manifest(url:Option<String>)->Result<models::PackManifest,error::LauncherError>{let s=settings::load()?;let chosen=url.filter(|x|!x.trim().is_empty()).unwrap_or_else(||settings::active_manifest_url(&s));manifest::sync_from(&chosen).await}

#[tauri::command] async fn server_status()->Result<ServerStatus,error::LauncherError>{status::fetch().await}
#[tauri::command] async fn fetch_news()->Result<Vec<NewsItem>,error::LauncherError>{content::fetch_news().await}
#[tauri::command] async fn fetch_events()->Result<Vec<EventItem>,error::LauncherError>{content::fetch_events().await}

#[tauri::command] async fn bootstrap_minecraft()->Result<BootstrapReport,error::LauncherError>{let s=settings::load()?;let r=bootstrap::bootstrap_all(&s).await;match &r{Ok(_)=>logs::write("bootstrap","Minecraft/Forge preparados"),Err(e)=>logs::write("bootstrap-error",&e.to_string())}r}
#[tauri::command] async fn install_managed_java()->Result<models::RuntimeInstallReport,error::LauncherError>{let m=manifest::load_local()?;bootstrap::install_runtime(m.launch.java_major.unwrap_or(17)).await}
#[tauri::command] async fn install_forge()->Result<ForgeInstallReport,error::LauncherError>{let s=settings::load()?;bootstrap::install_forge_and_profile(&s).await}
#[tauri::command] fn repair_official_profile()->Result<ForgeInstallReport,error::LauncherError>{let s=settings::load()?;bootstrap::repair_official_profile(&s)}

#[tauri::command] async fn microsoft_login()->Result<MicrosoftProfile,error::LauncherError>{auth::login().await}
#[tauri::command] fn microsoft_logout()->Result<(),error::LauncherError>{auth::logout()}
#[tauri::command] fn microsoft_state()->MicrosoftProfile{auth::state()}

#[tauri::command] fn list_optional_mods()->Result<Vec<OptionalModInfo>,error::LauncherError>{let s=settings::load()?;pack::optional(&s)}
#[tauri::command] fn set_optional_mod(id:String,enabled:bool)->Result<LauncherSettings,error::LauncherError>{pack::set_optional(&id,enabled)}
#[tauri::command] fn pack_stats()->Result<PackStats,error::LauncherError>{pack::stats()}
#[tauri::command] fn scan_conflicts()->Result<ConflictReport,error::LauncherError>{let s=settings::load()?;conflicts::scan(&s)}
#[tauri::command] fn system_profile()->Result<SystemProfile,error::LauncherError>{system::profile()}

#[tauri::command] fn create_backup()->Result<BackupInfo,error::LauncherError>{let s=settings::load()?;backup::create(&s)}
#[tauri::command] fn list_backups()->Result<Vec<BackupInfo>,error::LauncherError>{backup::list()}
#[tauri::command] fn rollback_backup(id:String)->Result<usize,error::LauncherError>{backup::rollback(&id)}
#[tauri::command] fn delete_backup(id:String)->Result<(),error::LauncherError>{backup::delete(&id)}

#[tauri::command] fn analyze_crash()->Result<models::CrashAnalysis,error::LauncherError>{crash::analyze()}
#[tauri::command] fn create_support_bundle()->Result<SupportBundleReport,error::LauncherError>{let s=settings::load()?;crash::support_bundle(&s)}

#[tauri::command] async fn check_launcher_update()->Result<Option<LauncherUpdateInfo>,error::LauncherError>{updater::check().await}
#[tauri::command] async fn install_launcher_update(app:tauri::AppHandle)->Result<(),error::LauncherError>{updater::install(app).await}



#[tauri::command] fn seed_pack_status()->SeedPackStatus{seed::detect()}
#[tauri::command] async fn download_seed_pack()->Result<SeedPackStatus,error::LauncherError>{seed::download_configured().await}
#[tauri::command] fn install_seed_pack(path:Option<String>)->Result<SeedInstallReport,error::LauncherError>{let r=seed::install(path);match &r{Ok(v)=>logs::write("seed",&format!("Seed {} instalado: {} arquivos",v.pack_version,v.installed_files)),Err(e)=>logs::write("seed-error",&e.to_string())}r}

#[tauri::command] fn public_config()->PublicConfig{release::public_config()}
#[tauri::command] fn release_readiness()->ReleaseReadiness{release::readiness()}

#[tauri::command] fn open_instance_folder()->Result<(),error::LauncherError>{actions::open_instance()}
#[tauri::command] fn open_logs_folder()->Result<(),error::LauncherError>{actions::open_logs()}
#[tauri::command] fn open_cache_folder()->Result<(),error::LauncherError>{actions::open_cache()}
#[tauri::command] fn open_backups_folder()->Result<(),error::LauncherError>{actions::open_backups()}
#[tauri::command] fn open_support_folder()->Result<(),error::LauncherError>{actions::open_support()}
#[tauri::command] fn open_external_url(url:String)->Result<(),error::LauncherError>{actions::open_url(&url)}
#[tauri::command] fn clear_cache()->Result<CacheReport,error::LauncherError>{actions::clear_cache()}

#[tauri::command]
fn diagnostics()->Result<DiagnosticReport,error::LauncherError>{
    let settings=settings::load()?;let mode=match &settings.launch_mode{LaunchMode::Official=>"official",LaunchMode::Direct=>"direct",LaunchMode::Offline=>"offline"}.to_string();
    Ok(DiagnosticReport{app_version:env!("CARGO_PKG_VERSION").into(),os:std::env::consts::OS.into(),arch:std::env::consts::ARCH.into(),instance_dir:paths::instance_dir()?.display().to_string(),cache_dir:paths::cache_dir()?.display().to_string(),logs_dir:paths::logs_dir()?.display().to_string(),launch_mode:mode,channel:settings.channel.clone(),ram_mb:settings.ram_mb,readiness:readiness(&settings)?,pack:manifest::load_local().ok().map(|m|m.pack),conflicts:conflicts::scan(&settings).unwrap_or_default(),crash:crash::analyze().ok()})
}

#[tauri::command]
async fn launch_game()->Result<String,error::LauncherError>{
    // Alpha 8: every launch re-checks the selected channel before Minecraft starts.
    // This is what makes "open launcher -> play" keep itself in sync without manual ZIPs.
    provision::ensure_ready_before_launch().await?;
    let settings=settings::load()?;
    let m=manifest::load_local()?;
    enforce_min_version(m.launch.min_launcher_version.as_deref())?;
    if let Ok(s)=status::fetch().await{
        enforce_min_version(s.min_launcher_version.as_deref())?;
        if s.maintenance&&settings.channel!="staff"{return Err(error::LauncherError::Launch(s.maintenance_message.unwrap_or_else(||"Eclipse SMP está em manutenção.".into())))}
        if let Some(required)=s.required_pack_version.as_deref(){if required!=m.pack.version{return Err(error::LauncherError::Launch(format!("O servidor exige o modpack {required}; instalado: {}.",m.pack.version)))}}
    }
    let result=match settings.launch_mode{LaunchMode::Official=>launch::launch_official(&settings),LaunchMode::Offline=>launch::launch_offline(&settings),LaunchMode::Direct=>{let session=auth::session().await?;launch::launch_direct(&settings,session)}};
    match &result{Ok(v)=>logs::write("launch",v),Err(e)=>logs::write("launch-error",&e.to_string())}result
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run(){
    let _=paths::ensure_layout();let _=logs::rotate();
    tauri::Builder::default().invoke_handler(tauri::generate_handler![
        get_launcher_state,save_settings,reset_settings,verify_pack,repair_pack,repair_progress,pause_downloads,resume_downloads,cancel_downloads,refresh_distribution,startup_check,estimate_pack_update,provision_installation,sync_manifest,
        server_status,fetch_news,fetch_events,bootstrap_minecraft,install_managed_java,install_forge,repair_official_profile,
        microsoft_login,microsoft_logout,microsoft_state,list_optional_mods,set_optional_mod,pack_stats,scan_conflicts,system_profile,
        create_backup,list_backups,rollback_backup,delete_backup,analyze_crash,create_support_bundle,
        check_launcher_update,install_launcher_update,seed_pack_status,download_seed_pack,install_seed_pack,public_config,release_readiness,open_instance_folder,open_logs_folder,open_cache_folder,open_backups_folder,open_support_folder,open_external_url,clear_cache,diagnostics,launch_game
    ]).run(tauri::generate_context!()).expect("erro ao iniciar Eclipse Launcher");
}
