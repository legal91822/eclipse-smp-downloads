use std::{fs,io::Write,path::Path};
use crate::{error::Result,paths};

const MAX_BYTES:u64=2*1024*1024;
const KEEP:usize=5;

fn log_path()->Result<std::path::PathBuf>{Ok(paths::logs_dir()?.join("launcher.log"))}

pub fn rotate()->Result<()> {
    paths::ensure_layout()?;let p=log_path()?;if !p.exists()||fs::metadata(&p)?.len()<MAX_BYTES{return Ok(())}
    for i in (1..KEEP).rev(){let from=p.with_extension(format!("log.{i}"));let to=p.with_extension(format!("log.{}",i+1));if from.exists(){let _=fs::rename(from,to);}}
    let first=p.with_extension("log.1");let _=fs::rename(&p,first);Ok(())
}

pub fn write(event:&str,message:&str){
    let _=(||->Result<()>{rotate()?;let p=log_path()?;let mut f=fs::OpenOptions::new().create(true).append(true).open(p)?;let ts=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_secs();writeln!(f,"[{ts}] [{event}] {}",sanitize(message))?;Ok(())})();
}
fn sanitize(s:&str)->String{let mut v=s.to_string();if let Some(home)=dirs::home_dir(){v=v.replace(&home.display().to_string(),"<USER_HOME>");}if v.len()>4000{v.truncate(4000);}v}

pub fn is_log_file(path:&Path)->bool{path.extension().and_then(|x|x.to_str()).map(|x|matches!(x,"log"|"txt")).unwrap_or(false)}
