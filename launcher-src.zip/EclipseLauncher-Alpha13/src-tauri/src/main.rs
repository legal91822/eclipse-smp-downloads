fn main() {
    eclipse_launcher_lib::run();
}
