use std::{collections::HashSet, fs, path::{Component, Path}};
use crate::{error::{LauncherError, Result}, models::PackManifest, paths};

fn validate_https(label: &str, value: &str) -> Result<()> {
    let parsed = url::Url::parse(value).map_err(|_| LauncherError::Manifest(format!("URL inválida em {label}")))?;
    if parsed.scheme() != "https" && !(cfg!(debug_assertions) && parsed.scheme() == "http") {
        return Err(LauncherError::Manifest(format!("URL não segura em {label}")));
    }
    Ok(())
}

pub fn load_local() -> Result<PackManifest> {
    let path = paths::manifest_path()?;
    if !path.exists() { return Err(LauncherError::Manifest("Manifesto ainda não foi instalado".into())); }
    let manifest: PackManifest = serde_json::from_str(&fs::read_to_string(path)?)?;
    validate(&manifest)?;
    Ok(manifest)
}

pub fn load_previous() -> Option<PackManifest> {
    let path = paths::previous_manifest_path().ok()?;
    let text = fs::read_to_string(path).ok()?;
    let manifest: PackManifest = serde_json::from_str(&text).ok()?;
    validate(&manifest).ok()?;
    Some(manifest)
}

pub async fn sync_from(url: &str) -> Result<PackManifest> {
    if url.trim().is_empty() { return Err(LauncherError::Config("URL do manifesto não configurada".into())); }
    let parsed = url::Url::parse(url).map_err(|_| LauncherError::Config("URL do manifesto inválida".into()))?;
    if parsed.scheme() != "https" && !(cfg!(debug_assertions) && parsed.scheme() == "http") {
        return Err(LauncherError::Config("O manifesto deve usar HTTPS (HTTP só é aceito em build de desenvolvimento)".into()));
    }

    let client = reqwest::Client::builder()
        .user_agent("EclipseLauncher/1.0")
        .timeout(std::time::Duration::from_secs(30))
        .build()?;
    let manifest: PackManifest = client.get(parsed).send().await?.error_for_status()?.json().await?;
    validate(&manifest)?;

    paths::ensure_layout()?;
    let path = paths::manifest_path()?;
    let previous = paths::previous_manifest_path()?;
    let temp = path.with_extension("json.tmp");
    fs::write(&temp, serde_json::to_vec_pretty(&manifest)?)?;
    if path.exists() {
        let _ = fs::remove_file(&previous);
        fs::copy(&path, &previous)?;
        let backup = path.with_extension("json.bak");
        let _ = fs::remove_file(&backup);
        fs::rename(&path, &backup)?;
        if let Err(e) = fs::rename(&temp, &path) {
            let _ = fs::rename(&backup, &path);
            let _ = fs::remove_file(&temp);
            return Err(e.into());
        }
        let _ = fs::remove_file(&backup);
    } else { fs::rename(&temp, &path)?; }
    Ok(manifest)
}

pub fn validate(m: &PackManifest) -> Result<()> {
    if !(1..=2).contains(&m.schema_version) {
        return Err(LauncherError::Manifest(format!("schema_version {} não suportado", m.schema_version)));
    }
    if m.pack.name.trim().is_empty() || m.pack.version.trim().is_empty() || m.pack.minecraft.trim().is_empty() || m.pack.forge.trim().is_empty() {
        return Err(LauncherError::Manifest("Dados básicos do pack estão incompletos".into()));
    }
    if let Some(base) = &m.endpoints.file_base { validate_https("endpoints.file_base", base)?; }
    for (i, base) in m.endpoints.file_bases.iter().enumerate() { validate_https(&format!("endpoints.file_bases[{i}]"), base)?; }
    if let Some(status) = &m.endpoints.status { validate_https("endpoints.status", status)?; }
    if let Some(news) = &m.endpoints.news { validate_https("endpoints.news", news)?; }
    if let Some(events) = &m.endpoints.events { validate_https("endpoints.events", events)?; }
    if let Some(update) = &m.endpoints.launcher_update { validate_https("endpoints.launcher_update", update)?; }
    if let Some(min) = m.launch.min_ram_mb { if !(1024..=32768).contains(&min) { return Err(LauncherError::Manifest("min_ram_mb fora do limite".into())); } }
    if let Some(rec) = m.launch.recommended_ram_mb {
        if !(1024..=32768).contains(&rec) { return Err(LauncherError::Manifest("recommended_ram_mb fora do limite".into())); }
        if let Some(min) = m.launch.min_ram_mb { if rec < min { return Err(LauncherError::Manifest("recommended_ram_mb não pode ser menor que min_ram_mb".into())); } }
    }
    if let Some(min_version)=m.launch.min_launcher_version.as_deref(){ semver::Version::parse(min_version).map_err(|_|LauncherError::Manifest("min_launcher_version precisa ser SemVer".into()))?; }
    if !m.auth.client_id.trim().is_empty() {
        validate_https("auth.authorize_url", &m.auth.authorize_url)?;
        validate_https("auth.token_url", &m.auth.token_url)?;
        if !m.auth.scope.contains("offline_access") { return Err(LauncherError::Manifest("OAuth Direct precisa de offline_access para refresh seguro".into())); }
    }

    let mut seen = HashSet::new();
    let mut ids = HashSet::new();
    for f in &m.files {
        let path = Path::new(&f.path);
        if f.path.trim().is_empty() || path.is_absolute() { return Err(LauncherError::Manifest(format!("caminho inseguro no manifesto: {}", f.path))); }
        for component in path.components() {
            if matches!(component, Component::ParentDir | Component::RootDir | Component::Prefix(_)) { return Err(LauncherError::Manifest(format!("caminho inseguro no manifesto: {}", f.path))); }
        }
        if f.path.contains('\\') || f.path.contains(':') { return Err(LauncherError::Manifest(format!("caminho não-portável no manifesto: {}", f.path))); }
        if !seen.insert(f.path.to_ascii_lowercase()) { return Err(LauncherError::Manifest(format!("arquivo duplicado no manifesto: {}", f.path))); }
        if !matches!(f.mode.as_str(), "managed" | "preserve" | "optional") { return Err(LauncherError::Manifest(format!("modo de arquivo inválido em {}: {}", f.path, f.mode))); }
        if f.mode=="optional" {
            if f.id.trim().is_empty(){return Err(LauncherError::Manifest(format!("arquivo optional precisa de id: {}",f.path)))}
            if !ids.insert(f.id.to_ascii_lowercase()){return Err(LauncherError::Manifest(format!("id optional duplicado: {}",f.id)))}
        }
        if f.sha256.len() != 64 || !f.sha256.chars().all(|c| c.is_ascii_hexdigit()) { return Err(LauncherError::Manifest(format!("SHA-256 inválido: {}", f.path))); }
        if let Some(url) = &f.url { validate_https(&format!("arquivo {}", f.path), url)?; }
        for (i,url) in f.mirrors.iter().enumerate(){ validate_https(&format!("arquivo {} mirror {i}",f.path),url)?; }
    }
    Ok(())
}
