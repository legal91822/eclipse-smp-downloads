use futures_util::{stream,StreamExt};
use serde::{Deserialize,Serialize};
use serde_json::Value;
use sha1::{Digest,Sha1};
use std::{collections::HashSet,fs,path::{Path,PathBuf}};
use tokio::io::{AsyncReadExt,AsyncWriteExt};
use crate::{error::{LauncherError,Result},paths};

#[derive(Debug,Clone,Serialize,Deserialize,Default)]
struct LaunchSpec{main_class:String,classpath:Vec<String>,jvm_args:Vec<String>,game_args:Vec<String>,working_directory:Option<String>,minecraft_home:Option<String>,assets_index:Option<String>}

fn os_name()->&'static str{if cfg!(target_os="windows"){"windows"}else if cfg!(target_os="macos"){"osx"}else{"linux"}}
fn arch_bits()->&'static str{if cfg!(target_pointer_width="64"){"64"}else{"32"}}
fn rule_allows(obj:&Value)->bool{
    let Some(rules)=obj.get("rules").and_then(|v|v.as_array()) else{return true};let mut allowed=false;
    for rule in rules{let os_ok=rule.get("os").and_then(|o|o.get("name")).and_then(|x|x.as_str()).map(|n|n==os_name()).unwrap_or(true);let feature_ok=rule.get("features").map(|f|f.as_object().map(|x|x.is_empty()).unwrap_or(false)).unwrap_or(true);if os_ok&&feature_ok{allowed=rule.get("action").and_then(|x|x.as_str())==Some("allow");}}
    allowed
}

async fn sha1_file(path:&Path)->Result<String>{let mut f=tokio::fs::File::open(path).await?;let mut h=Sha1::new();let mut b=vec![0u8;1024*1024];loop{let n=f.read(&mut b).await?;if n==0{break}h.update(&b[..n]);}Ok(hex::encode(h.finalize()))}
async fn download_sha1(client:&reqwest::Client,url:&str,target:&Path,expected:&str,size:Option<u64>)->Result<u64>{
    if target.exists(){let meta=tokio::fs::metadata(target).await?;let size_ok=size.map(|x|x==meta.len()).unwrap_or(true);if size_ok&&(expected.is_empty()||sha1_file(target).await?.eq_ignore_ascii_case(expected)){return Ok(0)}}
    if let Some(p)=target.parent(){tokio::fs::create_dir_all(p).await?;}let part=PathBuf::from(format!("{}.part",target.display()));let _=tokio::fs::remove_file(&part).await;let res=client.get(url).send().await?.error_for_status()?;let mut out=tokio::fs::File::create(&part).await?;let mut h=Sha1::new();let mut total=0u64;let mut st=res.bytes_stream();while let Some(c)=st.next().await{let c=c?;out.write_all(&c).await?;h.update(&c);total+=c.len() as u64;}out.flush().await?;drop(out);if let Some(s)=size{if total!=s{let _=tokio::fs::remove_file(&part).await;return Err(LauncherError::Integrity(format!("Tamanho inválido ao baixar {}",target.display())))}}let got=hex::encode(h.finalize());if !expected.is_empty()&&!got.eq_ignore_ascii_case(expected){let _=tokio::fs::remove_file(&part).await;return Err(LauncherError::Integrity(format!("SHA-1 inválido ao baixar {}",target.display())))}let _=tokio::fs::remove_file(target).await;tokio::fs::rename(part,target).await?;Ok(total)
}

fn maven_path(name:&str)->Option<String>{let p:Vec<&str>=name.split(':').collect();if p.len()<3{return None}let group=p[0].replace('.', "/");let artifact=p[1];let version=p[2];let classifier=if p.len()>3{format!("-{}",p[3])}else{String::new()};Some(format!("{group}/{artifact}/{version}/{artifact}-{version}{classifier}.jar"))}

async fn ensure_library(client:&reqwest::Client,home:&Path,lib:&Value,natives:&Path,classpath:&mut Vec<String>)->Result<()> {
    if !rule_allows(lib){return Ok(())}
    let name=lib.get("name").and_then(|x|x.as_str()).unwrap_or("");let artifact=lib.get("downloads").and_then(|x|x.get("artifact"));
    let mut artifact_path=None;
    if let Some(a)=artifact{if let Some(path)=a.get("path").and_then(|x|x.as_str()){let target=home.join("libraries").join(path);let url=a.get("url").and_then(|x|x.as_str()).unwrap_or("");let sha=a.get("sha1").and_then(|x|x.as_str()).unwrap_or("");let size=a.get("size").and_then(|x|x.as_u64());if !url.is_empty(){download_sha1(client,url,&target,sha,size).await?;}artifact_path=Some(target);}}
    if artifact_path.is_none(){if let Some(rel)=maven_path(name){let base=lib.get("url").and_then(|x|x.as_str()).unwrap_or("https://libraries.minecraft.net/");let url=format!("{}{}",base.trim_end_matches('/').to_string()+"/",rel);let target=home.join("libraries").join(&rel);download_sha1(client,&url,&target,"",None).await?;artifact_path=Some(target);}}
    if let Some(p)=artifact_path{if p.exists(){classpath.push(p.display().to_string());}}
    let native_key=lib.get("natives").and_then(|n|n.get(os_name())).and_then(|x|x.as_str()).map(|s|s.replace("${arch}",arch_bits()));
    if let Some(key)=native_key{if let Some(c)=lib.get("downloads").and_then(|x|x.get("classifiers")).and_then(|x|x.get(&key)){let Some(path)=c.get("path").and_then(|x|x.as_str()) else{return Ok(())};let target=home.join("libraries").join(path);let url=c.get("url").and_then(|x|x.as_str()).unwrap_or("");let sha=c.get("sha1").and_then(|x|x.as_str()).unwrap_or("");let size=c.get("size").and_then(|x|x.as_u64());download_sha1(client,url,&target,sha,size).await?;extract_natives(&target,natives)?;}}
    Ok(())
}

fn extract_natives(jar:&Path,natives:&Path)->Result<()> {fs::create_dir_all(natives)?;let f=fs::File::open(jar)?;let mut zip=zip::ZipArchive::new(f).map_err(|e|LauncherError::Config(format!("Native JAR inválido: {e}")))?;for i in 0..zip.len(){let mut it=zip.by_index(i).map_err(|e|LauncherError::Config(format!("Native ZIP: {e}")))?;let Some(rel)=it.enclosed_name().map(|x|x.to_owned()) else{continue};if rel.to_string_lossy().starts_with("META-INF/")||it.is_dir(){continue}let out=natives.join(rel);if let Some(p)=out.parent(){fs::create_dir_all(p)?;}let mut o=fs::File::create(out)?;std::io::copy(&mut it,&mut o)?;}Ok(())}

fn flatten_args(section:Option<&Value>)->Vec<String>{let mut out=vec![];let Some(arr)=section.and_then(|x|x.as_array()) else{return out};for item in arr{if let Some(s)=item.as_str(){out.push(s.into());continue}if !rule_allows(item){continue}if let Some(v)=item.get("value"){if let Some(s)=v.as_str(){out.push(s.into())}else if let Some(a)=v.as_array(){for x in a{if let Some(s)=x.as_str(){out.push(s.into())}}}}}out}
fn strip_classpath_args(args:Vec<String>)->Vec<String>{let mut out=vec![];let mut skip=false;for a in args{if skip{skip=false;continue}if a=="-cp"||a=="-classpath"{skip=true;continue}if a=="${classpath}"{continue}out.push(a)}out}

pub fn direct_ready()->bool{paths::instance_dir().ok().map(|p|p.join(".eclipse/launch.json").exists()).unwrap_or(false)}

pub async fn prepare(home:&Path,forge_version_id:&str,minecraft_version:&str)->Result<bool>{
    let client=reqwest::Client::builder().user_agent("EclipseLauncher/1.0").connect_timeout(std::time::Duration::from_secs(15)).timeout(std::time::Duration::from_secs(600)).build()?;
    let vm:Value=client.get("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json").send().await?.error_for_status()?.json().await?;let base_url=vm.get("versions").and_then(|x|x.as_array()).and_then(|a|a.iter().find(|x|x.get("id").and_then(|v|v.as_str())==Some(minecraft_version))).and_then(|x|x.get("url")).and_then(|x|x.as_str()).ok_or_else(||LauncherError::Config(format!("Minecraft {minecraft_version} não encontrado no version manifest")))?.to_string();
    let base:Value=client.get(&base_url).send().await?.error_for_status()?.json().await?;let base_dir=home.join("versions").join(minecraft_version);tokio::fs::create_dir_all(&base_dir).await?;tokio::fs::write(base_dir.join(format!("{minecraft_version}.json")),serde_json::to_vec_pretty(&base)?).await?;
    if let Some(c)=base.get("downloads").and_then(|x|x.get("client")){let u=c.get("url").and_then(|x|x.as_str()).unwrap_or("");let h=c.get("sha1").and_then(|x|x.as_str()).unwrap_or("");let size=c.get("size").and_then(|x|x.as_u64());download_sha1(&client,u,&base_dir.join(format!("{minecraft_version}.jar")),h,size).await?;}
    let natives=paths::instance_dir()?.join(".eclipse/natives");if natives.exists(){let _=fs::remove_dir_all(&natives);}fs::create_dir_all(&natives)?;let mut cp=vec![];
    if let Some(libs)=base.get("libraries").and_then(|x|x.as_array()){for lib in libs{ensure_library(&client,home,lib,&natives,&mut cp).await?;}}
    let forge_json_path=home.join("versions").join(forge_version_id).join(format!("{forge_version_id}.json"));let forge:Value=serde_json::from_str(&fs::read_to_string(&forge_json_path).map_err(|_|LauncherError::Config(format!("JSON Forge não encontrado: {}",forge_json_path.display())))?)?;
    if let Some(libs)=forge.get("libraries").and_then(|x|x.as_array()){for lib in libs{ensure_library(&client,home,lib,&natives,&mut cp).await?;}}
    cp.push(base_dir.join(format!("{minecraft_version}.jar")).display().to_string());let mut seen=HashSet::new();cp.retain(|x|seen.insert(x.clone()));
    let asset_index=base.get("assetIndex").cloned().unwrap_or(Value::Null);let asset_id=asset_index.get("id").and_then(|x|x.as_str()).unwrap_or(minecraft_version).to_string();if let Some(u)=asset_index.get("url").and_then(|x|x.as_str()){let idx:Value=client.get(u).send().await?.error_for_status()?.json().await?;let index_path=home.join("assets/indexes").join(format!("{asset_id}.json"));if let Some(p)=index_path.parent(){tokio::fs::create_dir_all(p).await?;}tokio::fs::write(&index_path,serde_json::to_vec(&idx)?).await?;let objects=idx.get("objects").and_then(|x|x.as_object()).cloned().unwrap_or_default();let home2=home.to_path_buf();let client2=client.clone();let tasks=stream::iter(objects.into_values().filter_map(|v|{let hash=v.get("hash")?.as_str()?.to_string();let size=v.get("size").and_then(|x|x.as_u64());Some((hash,size))}).map(move |(hash,size)|{let home=home2.clone();let client=client2.clone();async move{let rel=format!("{}/{}",&hash[..2],hash);let url=format!("https://resources.download.minecraft.net/{rel}");download_sha1(&client,&url,&home.join("assets/objects").join(rel),&hash,size).await.map(|_|())}})).buffer_unordered(16).collect::<Vec<_>>().await;for t in tasks{t?;}}
    let main=forge.get("mainClass").or_else(||base.get("mainClass")).and_then(|x|x.as_str()).ok_or_else(||LauncherError::Config("mainClass não encontrado".into()))?.to_string();let mut jvm=flatten_args(base.get("arguments").and_then(|x|x.get("jvm")));jvm.extend(flatten_args(forge.get("arguments").and_then(|x|x.get("jvm"))));jvm=strip_classpath_args(jvm);let mut game=if let Some(legacy)=base.get("minecraftArguments").and_then(|x|x.as_str()){legacy.split_whitespace().map(|x|x.to_string()).collect()}else{flatten_args(base.get("arguments").and_then(|x|x.get("game")))};game.extend(flatten_args(forge.get("arguments").and_then(|x|x.get("game"))));
    let spec=LaunchSpec{main_class:main,classpath:cp,jvm_args:jvm,game_args:game,working_directory:Some("{game_directory}".into()),minecraft_home:Some(home.display().to_string()),assets_index:Some(asset_id)};let out=paths::instance_dir()?.join(".eclipse/launch.json");if let Some(p)=out.parent(){fs::create_dir_all(p)?;}fs::write(out,serde_json::to_vec_pretty(&spec)?)?;Ok(true)
}
