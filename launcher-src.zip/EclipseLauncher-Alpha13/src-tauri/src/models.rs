use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum LaunchMode { Official, Direct, Offline }
impl Default for LaunchMode { fn default() -> Self { Self::Official } }

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct LauncherSettings {
    pub launch_mode: LaunchMode,
    pub offline_name: String,
    pub ram_mb: u32,
    pub channel: String,
    pub manifest_url: String,
    pub stable_manifest_url: String,
    pub beta_manifest_url: String,
    pub staff_manifest_url: String,
    pub official_launcher_path: Option<String>,
    pub auto_verify_on_start: bool,
    pub auto_repair_before_launch: bool,
    pub auto_update_launcher: bool,
    pub auto_backup_before_update: bool,
    pub backup_limit: u8,
    pub minimize_on_launch: bool,
    pub close_after_launch: bool,
    pub max_parallel_downloads: u8,
    pub optional_enabled: Vec<String>,
    pub reduce_data_usage: bool,
    pub auto_update_pack: bool,
    pub verify_after_update: bool,
    pub bootstrap_url: String,
}
impl Default for LauncherSettings {
    fn default() -> Self {
        Self {
            launch_mode: LaunchMode::Official,
            offline_name: "Player".into(),
            ram_mb: 8192,
            channel: "stable".into(),
            manifest_url: String::new(),
            stable_manifest_url: option_env!("ECLIPSE_STABLE_MANIFEST_URL").unwrap_or("").into(),
            beta_manifest_url: option_env!("ECLIPSE_BETA_MANIFEST_URL").unwrap_or("").into(),
            staff_manifest_url: option_env!("ECLIPSE_STAFF_MANIFEST_URL").unwrap_or("").into(),
            official_launcher_path: None,
            auto_verify_on_start: true,
            auto_repair_before_launch: false,
            auto_update_launcher: true,
            auto_backup_before_update: true,
            backup_limit: 5,
            minimize_on_launch: true,
            close_after_launch: false,
            max_parallel_downloads: 4,
            optional_enabled: vec![],
            reduce_data_usage: false,
            auto_update_pack: true,
            verify_after_update: true,
            bootstrap_url: option_env!("ECLIPSE_BOOTSTRAP_URL").unwrap_or("").into(),
        }
    }
}


#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct PublicConfig {
    pub site_url: String,
    pub discord_url: String,
    pub rules_url: String,
    pub wiki_url: String,
    pub support_url: String,
    pub bootstrap_url: String,
    pub seed_url: String,
    pub seed_sha256: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ReleaseReadiness {
    pub distribution_ready: bool,
    pub signed_updates_ready: bool,
    pub microsoft_direct_ready: bool,
    pub public_links_ready: bool,
    pub send_ready: bool,
    pub blockers: Vec<String>,
    pub warnings: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Readiness {
    pub manifest: bool,
    pub minecraft_runtime: bool,
    pub forge: bool,
    pub official_launcher: bool,
    pub official_profile: bool,
    pub direct_files: bool,
    pub microsoft_auth: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LauncherState {
    pub app_version: String,
    pub instance_dir: String,
    pub cache_dir: String,
    pub logs_dir: String,
    pub backups_dir: String,
    pub settings: LauncherSettings,
    pub offline_uuid: Option<String>,
    pub readiness: Readiness,
    pub pack: Option<PackInfo>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PackManifest {
    pub schema_version: u32,
    pub pack: PackInfo,
    #[serde(default)] pub endpoints: Endpoints,
    #[serde(default)] pub launch: LaunchInfo,
    #[serde(default)] pub auth: AuthConfig,
    #[serde(default)] pub files: Vec<ManagedFile>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PackInfo {
    pub name: String,
    pub version: String,
    pub minecraft: String,
    pub forge: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Endpoints {
    pub status: Option<String>,
    pub news: Option<String>,
    pub events: Option<String>,
    pub launcher_update: Option<String>,
    pub file_base: Option<String>,
    #[serde(default)] pub file_bases: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct LaunchInfo {
    pub server_address: Option<String>,
    pub java_major: Option<u32>,
    pub min_ram_mb: Option<u32>,
    pub recommended_ram_mb: Option<u32>,
    pub min_launcher_version: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct AuthConfig {
    pub client_id: String,
    pub authorize_url: String,
    pub token_url: String,
    pub scope: String,
}
impl Default for AuthConfig {
    fn default() -> Self {
        Self {
            client_id: String::new(),
            authorize_url: "https://login.live.com/oauth20_authorize.srf".into(),
            token_url: "https://login.live.com/oauth20_token.srf".into(),
            scope: "XboxLive.signin offline_access".into(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ManagedFile {
    pub id: String,
    pub path: String,
    pub sha256: String,
    pub size: u64,
    pub mode: String,
    pub url: Option<String>,
    pub mirrors: Vec<String>,
    pub display_name: String,
    pub description: String,
    pub group: String,
    pub conflicts: Vec<String>,
    pub enabled_by_default: bool,
}
impl Default for ManagedFile {
    fn default() -> Self {
        Self {
            id: String::new(), path: String::new(), sha256: String::new(), size: 0,
            mode: "managed".into(), url: None, mirrors: vec![], display_name: String::new(),
            description: String::new(), group: String::new(), conflicts: vec![], enabled_by_default: false,
        }
    }
}


#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct DistributionChannels {
    pub stable: String,
    pub beta: String,
    pub staff: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct UpdateEstimate {
    pub files: usize,
    pub bytes: u64,
    pub resumed_bytes: u64,
    pub stale_files: usize,
    pub first_install: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct StartupReport {
    pub first_install: bool,
    pub channel: String,
    pub previous_pack_version: Option<String>,
    pub remote_pack_version: String,
    pub estimate: UpdateEstimate,
    pub manifest_synced: bool,
    pub maintenance: bool,
    pub maintenance_message: Option<String>,
    pub launcher_update: Option<LauncherUpdateInfo>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ProvisionReport {
    pub first_install: bool,
    pub pack_version: String,
    pub repair: RepairReport,
    pub bootstrap: BootstrapReport,
    pub final_verify: VerifyReport,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct VerifyReport {
    pub checked: usize,
    pub ok: usize,
    pub missing: Vec<String>,
    pub corrupted: Vec<String>,
    pub ignored: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RepairReport {
    pub repaired: usize,
    pub removed_stale: usize,
    pub bytes_downloaded: u64,
    pub resumed_bytes: u64,
    pub backup_id: Option<String>,
}
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct CacheReport { pub files_removed: usize, pub bytes_removed: u64 }

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct ServerStatus {
    pub online: bool,
    pub players_online: Option<u32>,
    pub players_max: Option<u32>,
    pub ping_ms: Option<u32>,
    pub tps: Option<f32>,
    pub message: Option<String>,
    pub maintenance: bool,
    pub maintenance_message: Option<String>,
    pub min_launcher_version: Option<String>,
    pub required_pack_version: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct NewsItem {
    pub id: String,
    pub title: String,
    pub summary: String,
    pub category: String,
    pub published_at: String,
    pub url: Option<String>,
    pub image_url: Option<String>,
    pub pinned: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct EventItem {
    pub id: String,
    pub title: String,
    pub summary: String,
    pub starts_at: String,
    pub ends_at: Option<String>,
    pub image_url: Option<String>,
    pub enabled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiagnosticReport {
    pub app_version: String,
    pub os: String,
    pub arch: String,
    pub instance_dir: String,
    pub cache_dir: String,
    pub logs_dir: String,
    pub launch_mode: String,
    pub channel: String,
    pub ram_mb: u32,
    pub readiness: Readiness,
    pub pack: Option<PackInfo>,
    pub conflicts: ConflictReport,
    pub crash: Option<CrashAnalysis>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RuntimeInstallReport {
    pub installed: bool,
    pub java_major: u32,
    pub path: String,
    pub bytes_downloaded: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ForgeInstallReport {
    pub installed: bool,
    pub forge_version: String,
    pub version_id: String,
    pub profile_files_updated: usize,
    pub installer_bytes: u64,
    pub direct_files_prepared: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct BootstrapReport {
    pub runtime: RuntimeInstallReport,
    pub forge: ForgeInstallReport,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct BootstrapMarker {
    pub minecraft_home: String,
    pub version_id: String,
    pub minecraft: String,
    pub forge: String,
    pub java_major: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct LauncherUpdateInfo {
    pub version: String,
    pub notes: String,
    pub url: String,
    pub sha256: String,
    pub signature: String,
    pub mandatory: bool,
    pub installer_type: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct OptionalModInfo {
    pub id: String,
    pub name: String,
    pub description: String,
    pub group: String,
    pub enabled: bool,
    pub size: u64,
    pub conflicts: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ConflictReport {
    pub extra_mods: Vec<String>,
    pub duplicate_mods: Vec<String>,
    pub missing_managed: Vec<String>,
    pub corrupted_managed: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct BackupInfo {
    pub id: String,
    pub created_at: String,
    pub pack_version: String,
    pub files: usize,
    pub bytes: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct PackStats {
    pub installed_bytes: u64,
    pub managed_files: usize,
    pub optional_files: usize,
    pub mods_count: usize,
    pub backups: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SystemProfile {
    pub total_ram_mb: u64,
    pub cpu_threads: usize,
    pub recommended_ram_mb: u32,
    pub free_instance_disk_bytes: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DownloadProgress {
    pub running: bool,
    pub paused: bool,
    pub cancelled: bool,
    pub current_file: String,
    pub files_total: usize,
    pub files_done: usize,
    pub bytes_total: u64,
    pub bytes_done: u64,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct CrashAnalysis {
    pub found: bool,
    pub source: String,
    pub summary: String,
    pub probable_mods: Vec<String>,
    pub probable_causes: Vec<String>,
    pub suggested_action: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SupportBundleReport {
    pub path: String,
    pub files: usize,
    pub bytes: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct MicrosoftProfile {
    pub connected: bool,
    pub minecraft_name: String,
    pub minecraft_uuid: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct MinecraftSession {
    pub name: String,
    pub uuid: String,
    pub access_token: String,
    pub user_type: String,
    pub xuid: String,
    pub client_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SeedPackStatus {
    pub available: bool,
    pub path: Option<String>,
    pub size: u64,
    pub pack_version: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SeedInstallReport {
    pub installed_files: usize,
    pub bytes_installed: u64,
    pub pack_version: String,
    pub seed_path: String,
}
