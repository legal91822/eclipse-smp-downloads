use std::{fs, path::PathBuf};
use crate::error::{LauncherError, Result};

pub fn root_dir() -> Result<PathBuf> {
    let home = dirs::home_dir().ok_or_else(|| LauncherError::Config("Não foi possível localizar a pasta do usuário".into()))?;
    Ok(home.join(".eclipse-launcher"))
}

pub fn instance_dir() -> Result<PathBuf> { Ok(root_dir()?.join("instances").join("eclipse-smp")) }
pub fn config_path() -> Result<PathBuf> { Ok(root_dir()?.join("launcher.json")) }
pub fn manifest_path() -> Result<PathBuf> { Ok(root_dir()?.join("manifest.json")) }
pub fn previous_manifest_path() -> Result<PathBuf> { Ok(root_dir()?.join("manifest.previous.json")) }
pub fn cache_dir() -> Result<PathBuf> { Ok(root_dir()?.join("cache")) }
pub fn logs_dir() -> Result<PathBuf> { Ok(root_dir()?.join("logs")) }
pub fn runtime_dir() -> Result<PathBuf> { Ok(root_dir()?.join("runtime")) }
pub fn backups_dir() -> Result<PathBuf> { Ok(root_dir()?.join("backups")) }
pub fn support_dir() -> Result<PathBuf> { Ok(root_dir()?.join("support")) }
pub fn secrets_dir() -> Result<PathBuf> { Ok(root_dir()?.join("secrets")) }
pub fn auth_profile_path() -> Result<PathBuf> { Ok(root_dir()?.join("auth-profile.json")) }

pub fn ensure_layout() -> Result<()> {
    let root = root_dir()?;
    for p in [root.clone(), instance_dir()?, cache_dir()?, logs_dir()?, backups_dir()?, support_dir()?, secrets_dir()?] {
        fs::create_dir_all(p)?;
    }
    Ok(())
}
