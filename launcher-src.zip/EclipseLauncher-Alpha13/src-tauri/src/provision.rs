use crate::{
    bootstrap, distribution,
    error::{LauncherError, Result},
    integrity, manifest,
    models::{LauncherSettings, ProvisionReport, StartupReport},
    repair, settings, status, updater,
};

async fn sync_manifest_resilient(settings:&LauncherSettings)->Result<(crate::models::PackManifest,bool)> {
    let url=settings::active_manifest_url(settings);
    if url.trim().is_empty(){return Err(LauncherError::Config("Canal do Eclipse ainda não possui manifesto publicado".into()))}
    match manifest::sync_from(&url).await {
        Ok(m)=>Ok((m,true)),
        Err(err)=>{
            if let Ok(local)=manifest::load_local(){Ok((local,false))}else{Err(err)}
        }
    }
}

pub async fn startup_check()->Result<StartupReport>{
    let local_before=manifest::load_local().ok();
    let previous=local_before.as_ref().map(|m|m.pack.version.clone());
    let had_manifest=local_before.is_some();
    let mut s=settings::load()?;

    // Online distribution is preferred. A locally installed Seed Pack is a deliberate
    // fallback so the launcher can be shipped before the CDN/bootstrap is live.
    if settings::active_manifest_url(&s).trim().is_empty(){
        match distribution::refresh_settings().await {
            Ok(refreshed)=>s=refreshed,
            Err(err)=>{
                if local_before.is_none(){
                    // Portable/player bundle fallback: a first-run Seed Pack can be installed
                    // without any CDN/bootstrap being configured yet. Do not surface a fake
                    // distribution error while a valid local Seed Pack is sitting beside the EXE.
                    let seed = crate::seed::detect();
                    if seed.available {
                        let seed_path = seed.path.clone().ok_or(err)?;
                        let seed_manifest = crate::seed::read_manifest(std::path::Path::new(&seed_path))?;
                        let bytes = seed_manifest.files.iter().filter(|f| f.mode != "optional").map(|f| f.size).sum();
                        let files = seed_manifest.files.iter().filter(|f| f.mode != "optional").count();
                        let server=status::fetch().await.ok();
                        let launcher_update=if s.auto_update_launcher{updater::check().await.ok().flatten()}else{None};
                        return Ok(StartupReport{
                            first_install:true,
                            channel:s.channel.clone(),
                            previous_pack_version:None,
                            remote_pack_version:seed_manifest.pack.version,
                            estimate:crate::models::UpdateEstimate{files,bytes,resumed_bytes:0,stale_files:0,first_install:true},
                            manifest_synced:false,
                            maintenance:server.as_ref().map(|x|x.maintenance).unwrap_or(false),
                            maintenance_message:server.and_then(|x|x.maintenance_message),
                            launcher_update,
                        });
                    }
                    // Single-download release mode: only the launcher is distributed. On the
                    // first PLAY/INSTALL click, provision_all downloads the signed-by-hash Seed.
                    let remote_seed = crate::release::value("ECLIPSE_SEED_URL");
                    let remote_hash = crate::release::value("ECLIPSE_SEED_SHA256");
                    if !remote_seed.trim().is_empty() && remote_hash.len()==64 {
                        let server=status::fetch().await.ok();
                        let launcher_update=if s.auto_update_launcher{updater::check().await.ok().flatten()}else{None};
                        return Ok(StartupReport{
                            first_install:true, channel:s.channel.clone(), previous_pack_version:None,
                            remote_pack_version:"Eclipse SMP".into(),
                            estimate:crate::models::UpdateEstimate{files:0,bytes:0,resumed_bytes:0,stale_files:0,first_install:true},
                            manifest_synced:false,
                            maintenance:server.as_ref().map(|x|x.maintenance).unwrap_or(false),
                            maintenance_message:server.and_then(|x|x.maintenance_message),
                            launcher_update,
                        });
                    }
                    return Err(err)
                }
            }
        }
    } else if let Ok(refreshed)=distribution::refresh_settings().await{s=refreshed;}

    let (remote,synced)=if settings::active_manifest_url(&s).trim().is_empty(){
        (manifest::load_local()?,false)
    } else {
        sync_manifest_resilient(&s).await?
    };
    let estimate=repair::estimate(&s).await?;
    let server=status::fetch().await.ok();
    let launcher_update=if s.auto_update_launcher{updater::check().await.ok().flatten()}else{None};
    Ok(StartupReport{
        first_install:!had_manifest||estimate.first_install,
        channel:s.channel.clone(),
        previous_pack_version:previous,
        remote_pack_version:remote.pack.version,
        estimate,
        manifest_synced:synced,
        maintenance:server.as_ref().map(|x|x.maintenance).unwrap_or(false),
        maintenance_message:server.and_then(|x|x.maintenance_message),
        launcher_update,
    })
}

pub async fn provision_all()->Result<ProvisionReport>{
    // One-click portable release: if there is no installed manifest yet and a Seed Pack
    // is next to the executable, consume it automatically before any network repair.
    if manifest::load_local().is_err() {
        if crate::seed::detect().available {
            crate::seed::install(None)?;
        } else if !crate::release::value("ECLIPSE_SEED_URL").trim().is_empty() {
            crate::seed::download_configured().await?;
            crate::seed::install(None)?;
        }
    }
    let startup=startup_check().await?;
    let s=settings::load()?;
    if startup.maintenance&&s.channel!="staff"{
        // Installation/update is still allowed during maintenance; only launch is blocked.
    }
    let repair=repair::repair(&s).await?;
    let bootstrap=bootstrap::bootstrap_all(&s).await?;
    let final_verify=integrity::verify_with_settings(&s)?;
    if !final_verify.missing.is_empty()||!final_verify.corrupted.is_empty(){
        return Err(LauncherError::Integrity("A instalação terminou, mas ainda existem arquivos ausentes ou corrompidos".into()))
    }
    Ok(ProvisionReport{
        first_install:startup.first_install,
        pack_version:manifest::load_local()?.pack.version,
        repair,
        bootstrap,
        final_verify,
    })
}

pub async fn ensure_ready_before_launch()->Result<()> {
    // Defense in depth: direct invocation of the backend launch command still performs
    // first-run Seed installation. The UI is not trusted to do this correctly.
    if manifest::load_local().is_err() {
        if crate::seed::detect().available {
            crate::seed::install(None)?;
        } else if !crate::release::value("ECLIPSE_SEED_URL").trim().is_empty() {
            crate::seed::download_configured().await?;
            crate::seed::install(None)?;
        }
    }
    let startup=startup_check().await?;
    let s=settings::load()?;
    if startup.maintenance&&s.channel!="staff"{
        return Err(LauncherError::Launch(startup.maintenance_message.unwrap_or_else(||"Eclipse SMP está em manutenção.".into())))
    }
    if let Some(update)=startup.launcher_update.as_ref(){
        if update.mandatory{return Err(LauncherError::Launch(format!("Atualização obrigatória do Eclipse Launcher disponível: {}",update.version)))}
    }
    if s.auto_update_pack||startup.first_install||startup.estimate.files>0||startup.estimate.stale_files>0{
        let _=repair::repair(&s).await?;
    }
    let runtime_ready=crate::launch::runtime_ready()?;
    let ready=match &s.launch_mode {
        crate::models::LaunchMode::Official => runtime_ready && bootstrap::forge_ready() && bootstrap::official_profile_ready(),
        crate::models::LaunchMode::Direct => runtime_ready && bootstrap::forge_ready() && crate::minecraft::direct_ready() && crate::auth::state().connected,
        crate::models::LaunchMode::Offline => runtime_ready && bootstrap::forge_ready() && crate::minecraft::direct_ready(),
    };
    if !ready{let _=bootstrap::bootstrap_all(&s).await?;}
    if s.verify_after_update||s.auto_verify_on_start{
        let report=integrity::verify_with_settings(&s)?;
        if !report.missing.is_empty()||!report.corrupted.is_empty(){return Err(LauncherError::Integrity("O modpack não está íntegro; o jogo não será aberto".into()))}
    }
    Ok(())
}
