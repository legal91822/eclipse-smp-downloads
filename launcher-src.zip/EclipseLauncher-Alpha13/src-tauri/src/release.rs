use std::{fs, path::PathBuf};
use serde::Deserialize;
use crate::{models::{PublicConfig, ReleaseReadiness}, paths};

#[derive(Debug, Clone, Default, Deserialize)]
#[serde(default)]
struct RuntimeReleaseConfig {
    bootstrap_url: String,
    stable_manifest_url: String,
    beta_manifest_url: String,
    staff_manifest_url: String,
    site_url: String,
    discord_url: String,
    rules_url: String,
    wiki_url: String,
    support_url: String,
    update_public_key_b64: String,
    microsoft_client_id: String,
    seed_url: String,
    seed_sha256: String,
}

fn config_candidates() -> Vec<PathBuf> {
    let mut out = Vec::new();
    if let Ok(exe) = std::env::current_exe() {
        if let Some(parent) = exe.parent() { out.push(parent.join("eclipse-release.json")); }
    }
    if let Ok(cwd) = std::env::current_dir() { out.push(cwd.join("eclipse-release.json")); }
    if let Ok(root) = paths::root_dir() { out.push(root.join("release.json")); }
    out
}

fn runtime_config() -> RuntimeReleaseConfig {
    for p in config_candidates() {
        if let Ok(text) = fs::read_to_string(&p) {
            if let Ok(cfg) = serde_json::from_str::<RuntimeReleaseConfig>(&text) {
                if let Ok(root) = paths::root_dir() {
                    let persisted = root.join("release.json");
                    if p != persisted {
                        let _ = fs::create_dir_all(&root);
                        let _ = fs::copy(&p, persisted);
                    }
                }
                return cfg;
            }
        }
    }
    RuntimeReleaseConfig::default()
}

fn env_value(name: &str) -> String {
    match name {
        "ECLIPSE_BOOTSTRAP_URL" => option_env!("ECLIPSE_BOOTSTRAP_URL").unwrap_or(""),
        "ECLIPSE_STABLE_MANIFEST_URL" => option_env!("ECLIPSE_STABLE_MANIFEST_URL").unwrap_or(""),
        "ECLIPSE_BETA_MANIFEST_URL" => option_env!("ECLIPSE_BETA_MANIFEST_URL").unwrap_or(""),
        "ECLIPSE_STAFF_MANIFEST_URL" => option_env!("ECLIPSE_STAFF_MANIFEST_URL").unwrap_or(""),
        "ECLIPSE_SITE_URL" => option_env!("ECLIPSE_SITE_URL").unwrap_or(""),
        "ECLIPSE_DISCORD_URL" => option_env!("ECLIPSE_DISCORD_URL").unwrap_or(""),
        "ECLIPSE_RULES_URL" => option_env!("ECLIPSE_RULES_URL").unwrap_or(""),
        "ECLIPSE_WIKI_URL" => option_env!("ECLIPSE_WIKI_URL").unwrap_or(""),
        "ECLIPSE_SUPPORT_URL" => option_env!("ECLIPSE_SUPPORT_URL").unwrap_or(""),
        "ECLIPSE_UPDATE_PUBLIC_KEY_B64" => option_env!("ECLIPSE_UPDATE_PUBLIC_KEY_B64").unwrap_or(""),
        "ECLIPSE_MICROSOFT_CLIENT_ID" => option_env!("ECLIPSE_MICROSOFT_CLIENT_ID").unwrap_or(""),
        "ECLIPSE_SEED_URL" => option_env!("ECLIPSE_SEED_URL").unwrap_or(""),
        "ECLIPSE_SEED_SHA256" => option_env!("ECLIPSE_SEED_SHA256").unwrap_or(""),
        _ => "",
    }.trim().to_string()
}

pub fn value(name: &str) -> String {
    let c = runtime_config();
    let runtime = match name {
        "ECLIPSE_BOOTSTRAP_URL" => c.bootstrap_url,
        "ECLIPSE_STABLE_MANIFEST_URL" => c.stable_manifest_url,
        "ECLIPSE_BETA_MANIFEST_URL" => c.beta_manifest_url,
        "ECLIPSE_STAFF_MANIFEST_URL" => c.staff_manifest_url,
        "ECLIPSE_SITE_URL" => c.site_url,
        "ECLIPSE_DISCORD_URL" => c.discord_url,
        "ECLIPSE_RULES_URL" => c.rules_url,
        "ECLIPSE_WIKI_URL" => c.wiki_url,
        "ECLIPSE_SUPPORT_URL" => c.support_url,
        "ECLIPSE_UPDATE_PUBLIC_KEY_B64" => c.update_public_key_b64,
        "ECLIPSE_MICROSOFT_CLIENT_ID" => c.microsoft_client_id,
        "ECLIPSE_SEED_URL" => c.seed_url,
        "ECLIPSE_SEED_SHA256" => c.seed_sha256,
        _ => String::new(),
    };
    if runtime.trim().is_empty() { env_value(name) } else { runtime.trim().to_string() }
}

fn valid_https(v: &str) -> bool {
    url::Url::parse(v).map(|u| u.scheme() == "https").unwrap_or(false)
}

pub fn public_config() -> PublicConfig {
    PublicConfig {
        site_url: value("ECLIPSE_SITE_URL"),
        discord_url: value("ECLIPSE_DISCORD_URL"),
        rules_url: value("ECLIPSE_RULES_URL"),
        wiki_url: value("ECLIPSE_WIKI_URL"),
        support_url: value("ECLIPSE_SUPPORT_URL"),
        bootstrap_url: value("ECLIPSE_BOOTSTRAP_URL"),
        seed_url: value("ECLIPSE_SEED_URL"),
        seed_sha256: value("ECLIPSE_SEED_SHA256"),
    }
}

pub fn readiness() -> ReleaseReadiness {
    let cfg = public_config();
    let mut blockers = Vec::new();
    let mut warnings = Vec::new();
    let has_local_seed = crate::seed::detect().available;

    let has_remote_seed = valid_https(&cfg.seed_url) && cfg.seed_sha256.len() == 64 && cfg.seed_sha256.chars().all(|c| c.is_ascii_hexdigit());
    if !valid_https(&cfg.bootstrap_url) && !has_local_seed && !has_remote_seed {
        blockers.push("Bootstrap HTTPS, Seed local ou Seed remoto HTTPS + SHA-256".into());
    }
    if value("ECLIPSE_UPDATE_PUBLIC_KEY_B64").is_empty() {
        warnings.push("Auto-update assinado do launcher ainda não configurado".into());
    }
    if value("ECLIPSE_MICROSOFT_CLIENT_ID").is_empty() {
        warnings.push("Microsoft Direct desativado (Launcher Oficial e Offline continuam disponíveis)".into());
    }
    if cfg.site_url.is_empty() { warnings.push("Site público não configurado".into()); }
    if cfg.discord_url.is_empty() { warnings.push("Discord público não configurado".into()); }

    ReleaseReadiness {
        distribution_ready: valid_https(&cfg.bootstrap_url) || has_local_seed || has_remote_seed,
        signed_updates_ready: !value("ECLIPSE_UPDATE_PUBLIC_KEY_B64").is_empty(),
        microsoft_direct_ready: !value("ECLIPSE_MICROSOFT_CLIENT_ID").is_empty(),
        public_links_ready: !cfg.site_url.is_empty() && !cfg.discord_url.is_empty(),
        send_ready: blockers.is_empty(),
        blockers,
        warnings,
    }
}
