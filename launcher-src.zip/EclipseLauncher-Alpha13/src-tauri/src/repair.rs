use futures_util::StreamExt;
use reqwest::header::RANGE;
use sha2::{Digest, Sha256};
use std::{collections::HashSet, path::{Path,PathBuf}, sync::{atomic::{AtomicBool,Ordering},Mutex,OnceLock}};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use crate::{backup, error::{LauncherError, Result}, manifest, models::{DownloadProgress, LauncherSettings, ManagedFile, RepairReport}, paths};

static PAUSED:AtomicBool=AtomicBool::new(false);
static CANCELLED:AtomicBool=AtomicBool::new(false);
static PROGRESS:OnceLock<Mutex<DownloadProgress>>=OnceLock::new();
fn progress_cell()->&'static Mutex<DownloadProgress>{PROGRESS.get_or_init(||Mutex::new(DownloadProgress::default()))}
fn set_progress<F:FnOnce(&mut DownloadProgress)>(f:F){if let Ok(mut p)=progress_cell().lock(){f(&mut p)}}
pub fn progress()->DownloadProgress{progress_cell().lock().map(|x|x.clone()).unwrap_or_default()}
pub fn pause(){PAUSED.store(true,Ordering::SeqCst);set_progress(|p|{p.paused=true;p.message="Downloads pausados".into()});}
pub fn resume(){PAUSED.store(false,Ordering::SeqCst);set_progress(|p|{p.paused=false;p.message="Retomando downloads".into()});}
pub fn cancel(){CANCELLED.store(true,Ordering::SeqCst);set_progress(|p|{p.cancelled=true;p.message="Cancelamento solicitado".into()});}

async fn wait_control()->Result<()> {
    if CANCELLED.load(Ordering::SeqCst){return Err(LauncherError::Config("Download cancelado pelo usuário".into()))}
    while PAUSED.load(Ordering::SeqCst){tokio::time::sleep(std::time::Duration::from_millis(140)).await;if CANCELLED.load(Ordering::SeqCst){return Err(LauncherError::Config("Download cancelado pelo usuário".into()))}}
    Ok(())
}

async fn hash_existing(path:&Path)->Result<(Sha256,u64)>{
    let mut h=Sha256::new(); let mut total=0u64;
    if path.exists(){let mut f=tokio::fs::File::open(path).await?;let mut b=vec![0u8;1024*1024];loop{let n=f.read(&mut b).await?;if n==0{break;}h.update(&b[..n]);total+=n as u64;}}
    Ok((h,total))
}

async fn sha256_async(path:&Path)->Result<String>{Ok(hex::encode(hash_existing(path).await?.0.finalize()))}
fn disabled_path(target:&Path)->PathBuf{PathBuf::from(format!("{}.disabled",target.display()))}
fn optional_enabled(file:&ManagedFile,settings:&LauncherSettings)->bool{file.mode!="optional"||settings.optional_enabled.iter().any(|x|x==&file.id)}

fn resolve_urls(file:&ManagedFile,file_bases:&[String])->Result<Vec<url::Url>>{
    let mut raw=vec![]; if let Some(u)=&file.url{raw.push(u.clone());} raw.extend(file.mirrors.clone());
    for base in file_bases{let b=if base.ends_with('/') {base.clone()}else{format!("{base}/")};let bu=url::Url::parse(&b).map_err(|_|LauncherError::Manifest("file_base inválido".into()))?;raw.push(bu.join(&file.path).map_err(|_|LauncherError::Manifest(format!("Não foi possível montar URL para {}",file.path)))?.to_string());}
    let mut out=vec![];let mut seen=HashSet::new();for u in raw{if seen.insert(u.clone()){out.push(url::Url::parse(&u).map_err(|_|LauncherError::Manifest(format!("URL inválida para {}",file.path)))?);}}
    if out.is_empty(){return Err(LauncherError::Manifest(format!("Sem URL ou espelho para {}",file.path)))} Ok(out)
}

pub(crate) async fn needs_repair(base:&Path,file:&ManagedFile)->Result<bool>{let target=base.join(&file.path);if !target.exists(){return Ok(true)}let meta=tokio::fs::metadata(&target).await?;if !meta.is_file()||meta.len()!=file.size{return Ok(true)}Ok(!sha256_async(&target).await?.eq_ignore_ascii_case(&file.sha256))}

async fn try_download(client:&reqwest::Client,url:&url::Url,target:&Path,file:&ManagedFile)->Result<(u64,u64)>{
    if let Some(parent)=target.parent(){tokio::fs::create_dir_all(parent).await?;}
    let part=PathBuf::from(format!("{}.eclipse-part",target.display()));
    let old=PathBuf::from(format!("{}.eclipse-old",target.display()));
    let (mut hasher,mut existing)=hash_existing(&part).await?; if existing>file.size{let _=tokio::fs::remove_file(&part).await;existing=0;hasher=Sha256::new();}
    let mut req=client.get(url.clone()); if existing>0{req=req.header(RANGE,format!("bytes={existing}-"));}
    let res=req.send().await?.error_for_status()?; let partial=res.status()==reqwest::StatusCode::PARTIAL_CONTENT;
    if existing>0&&!partial{let _=tokio::fs::remove_file(&part).await;existing=0;hasher=Sha256::new();}
    let mut out=if existing>0{tokio::fs::OpenOptions::new().append(true).open(&part).await?}else{tokio::fs::File::create(&part).await?};
    let resumed=existing; let mut written=existing; let mut stream=res.bytes_stream();
    while let Some(chunk)=stream.next().await{wait_control().await?;let chunk=chunk?;out.write_all(&chunk).await?;hasher.update(&chunk);written+=chunk.len() as u64;set_progress(|p|{p.bytes_done=p.bytes_done.saturating_add(chunk.len() as u64);p.current_file=file.path.clone();p.message=if resumed>0{"Retomando download".into()}else{"Baixando".into()};});if written>file.size{let _=tokio::fs::remove_file(&part).await;return Err(LauncherError::Integrity(format!("Download maior que o esperado: {}",file.path)))}}
    out.flush().await?;drop(out);let got=hex::encode(hasher.finalize());if written!=file.size||!got.eq_ignore_ascii_case(&file.sha256){return Err(LauncherError::Integrity(format!("Hash/tamanho inválido após baixar {}",file.path)))}
    let _=tokio::fs::remove_file(&old).await;if target.exists(){tokio::fs::rename(target,&old).await?;}if let Err(e)=tokio::fs::rename(&part,target).await{if old.exists(){let _=tokio::fs::rename(&old,target).await;}return Err(e.into())}if old.exists(){let _=tokio::fs::remove_file(&old).await;}
    Ok((written-resumed,resumed))
}

async fn repair_one(client:&reqwest::Client,base:&Path,file_bases:&[String],file:&ManagedFile,settings:&LauncherSettings)->Result<Option<(u64,u64)>>{
    let target=base.join(&file.path); let disabled=disabled_path(&target);
    if file.mode=="optional"&&!optional_enabled(file,settings){if target.exists(){if disabled.exists(){let _=tokio::fs::remove_file(&disabled).await;}tokio::fs::rename(&target,&disabled).await?;}return Ok(None)}
    if !target.exists()&&disabled.exists(){let meta=tokio::fs::metadata(&disabled).await?;if meta.len()==file.size&&sha256_async(&disabled).await?.eq_ignore_ascii_case(&file.sha256){tokio::fs::rename(&disabled,&target).await?;return Ok(None)}}
    if !needs_repair(base,file).await?{return Ok(None)}
    let urls=resolve_urls(file,file_bases)?;let mut last=None;
    for round in 0..3{for u in &urls{wait_control().await?;match try_download(client,u,&target,file).await{Ok(v)=>return Ok(Some(v)),Err(e)=>{last=Some(e);tokio::time::sleep(std::time::Duration::from_millis(250*(round+1))).await;}}}}
    Err(last.unwrap_or_else(||LauncherError::Config(format!("Todos os espelhos falharam para {}",file.path))))
}

fn cleanup_stale(current:&crate::models::PackManifest)->Result<usize>{
    let Some(previous)=manifest::load_previous() else{return Ok(0)};let current_paths:HashSet<String>=current.files.iter().map(|f|f.path.to_ascii_lowercase()).collect();let base=paths::instance_dir()?;let mut removed=0;
    for old in previous.files.into_iter().filter(|f|f.mode=="managed"||f.mode=="optional") {if current_paths.contains(&old.path.to_ascii_lowercase()){continue;}let p=base.join(&old.path);let d=disabled_path(&p);if p.is_file(){fs_remove(&p)?;removed+=1;}if d.is_file(){fs_remove(&d)?;removed+=1;}}
    Ok(removed)
}
fn fs_remove(p:&Path)->Result<()>{std::fs::remove_file(p)?;Ok(())}

pub async fn estimate(settings:&LauncherSettings)->Result<crate::models::UpdateEstimate>{
    let m=manifest::load_local()?; let base=paths::instance_dir()?; let first_install=!base.join("mods").exists() || std::fs::read_dir(base.join("mods")).map(|mut i|i.next().is_none()).unwrap_or(true);
    let mut files=0usize; let mut bytes=0u64; let mut resumed_bytes=0u64;
    for f in m.files.iter().filter(|x|x.mode=="managed"||x.mode=="optional").filter(|f|optional_enabled(f,settings)) {
        if needs_repair(&base,f).await? {
            files+=1;
            let part=PathBuf::from(format!("{}.eclipse-part",base.join(&f.path).display()));
            let resumed=tokio::fs::metadata(&part).await.ok().map(|m|m.len().min(f.size)).unwrap_or(0);
            resumed_bytes=resumed_bytes.saturating_add(resumed);
            bytes=bytes.saturating_add(f.size.saturating_sub(resumed));
        }
    }
    let stale_files=stale_count(&m);
    Ok(crate::models::UpdateEstimate{files,bytes,resumed_bytes,stale_files,first_install})
}

fn stale_count(current:&crate::models::PackManifest)->usize{
    let Some(previous)=manifest::load_previous() else{return 0};
    let current_paths:HashSet<String>=current.files.iter().map(|f|f.path.to_ascii_lowercase()).collect();
    previous.files.into_iter().filter(|f|(f.mode=="managed"||f.mode=="optional")&&!current_paths.contains(&f.path.to_ascii_lowercase())).count()
}

pub async fn repair(settings:&LauncherSettings)->Result<RepairReport>{
    let m=manifest::load_local()?;let base=paths::instance_dir()?;let parallel=usize::from(settings.max_parallel_downloads.clamp(1,12));
    let mut files:Vec<ManagedFile>=m.files.iter().filter(|x|x.mode=="managed"||x.mode=="optional").cloned().collect();
    let estimate=estimate(settings).await?;let total_bytes=estimate.bytes;
    let free=fs2::available_space(&base).unwrap_or(u64::MAX);
    if total_bytes>0&&free<total_bytes.saturating_add(256*1024*1024){return Err(LauncherError::Config(format!("Espaço em disco insuficiente para a atualização. Necessário: ~{} MB; livre: {} MB",total_bytes/1024/1024,free/1024/1024)))}
    let has_changes=estimate.files>0||estimate.stale_files>0;
    let backup_info=if has_changes&&!estimate.first_install&&settings.auto_backup_before_update{Some(backup::create(settings)?)}else{None};
    let removed=cleanup_stale(&m)?;
    let mut bases=m.endpoints.file_bases.clone();if let Some(b)=m.endpoints.file_base.clone(){if !bases.contains(&b){bases.insert(0,b);}}
    let client=reqwest::Client::builder().user_agent("EclipseLauncher/1.0").connect_timeout(std::time::Duration::from_secs(15)).timeout(std::time::Duration::from_secs(240)).build()?;
    CANCELLED.store(false,Ordering::SeqCst);PAUSED.store(false,Ordering::SeqCst);set_progress(|p|*p=DownloadProgress{running:has_changes,files_total:estimate.files,bytes_total:total_bytes,message:if has_changes{"Preparando atualização".into()}else{"Modpack já está atualizado".into()},..Default::default()});
    if !has_changes{return Ok(RepairReport::default())}
    use futures_util::stream::{self,StreamExt as _};
    let results=stream::iter(files.drain(..).map(|file|{let client=client.clone();let base=base.clone();let bases=bases.clone();let settings=settings.clone();async move{let r=repair_one(&client,&base,&bases,&file,&settings).await;if r.as_ref().ok().and_then(|x|*x).is_some(){set_progress(|p|p.files_done+=1);}r}})).buffer_unordered(parallel).collect::<Vec<_>>().await;
    let mut report=RepairReport{removed_stale:removed,backup_id:backup_info.map(|b|b.id),..Default::default()};let mut error=None;
    for result in results{match result{Ok(Some((new,resumed)))=>{report.repaired+=1;report.bytes_downloaded+=new;report.resumed_bytes+=resumed;},Ok(None)=>{},Err(e)=>{if error.is_none(){error=Some(e)}}}}
    set_progress(|p|{p.running=false;p.paused=false;p.message=if error.is_some(){"Atualização terminou com erro".into()}else{"Atualização concluída".into()};});
    if let Some(e)=error{return Err(e)} Ok(report)
}
