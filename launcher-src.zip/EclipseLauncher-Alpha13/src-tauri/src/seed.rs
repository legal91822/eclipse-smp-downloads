use std::{fs, io::{Read, Write}, path::{Path, PathBuf}};
use sha2::{Digest, Sha256};
use futures_util::StreamExt;
use crate::{
    error::{LauncherError, Result},
    manifest,
    models::{PackManifest, SeedInstallReport, SeedPackStatus},
    paths, release,
};

const SEED_NAME: &str = "EclipseSMP-Seed.zip";

fn candidate_paths() -> Vec<PathBuf> {
    let mut out = Vec::new();
    if let Ok(exe) = std::env::current_exe() {
        if let Some(parent) = exe.parent() { out.push(parent.join(SEED_NAME)); }
    }
    if let Ok(cwd) = std::env::current_dir() { out.push(cwd.join(SEED_NAME)); }
    if let Some(downloads) = dirs::download_dir() { out.push(downloads.join(SEED_NAME)); }
    if let Some(desktop) = dirs::desktop_dir() { out.push(desktop.join(SEED_NAME)); }
    if let Ok(root) = paths::root_dir() { out.push(root.join(SEED_NAME)); }
    out
}

pub fn detect() -> SeedPackStatus {
    for path in candidate_paths() {
        if path.is_file() {
            let size = fs::metadata(&path).map(|m| m.len()).unwrap_or(0);
            let version = read_manifest(&path).ok().map(|m| m.pack.version);
            return SeedPackStatus { available: true, path: Some(path.display().to_string()), size, pack_version: version };
        }
    }
    SeedPackStatus { available: false, path: None, size: 0, pack_version: None }
}

fn zip_err<E: std::fmt::Display>(e: E) -> LauncherError {
    LauncherError::Config(format!("Seed ZIP inválido: {e}"))
}

pub(crate) fn read_manifest(seed: &Path) -> Result<PackManifest> {
    let file = fs::File::open(seed)?;
    let mut zip = zip::ZipArchive::new(file).map_err(zip_err)?;
    let mut item = zip.by_name("manifest.json").map_err(|_| LauncherError::Config("EclipseSMP-Seed.zip não contém manifest.json".into()))?;
    let mut text = String::new();
    item.read_to_string(&mut text)?;
    let manifest: PackManifest = serde_json::from_str(&text)?;
    manifest::validate(&manifest)?;
    Ok(manifest)
}


fn existing_matches(path: &Path, size: u64, expected_sha256: &str) -> bool {
    let Ok(meta) = fs::metadata(path) else { return false; };
    if !meta.is_file() || meta.len() != size { return false; }
    let Ok(mut f) = fs::File::open(path) else { return false; };
    let mut hasher = Sha256::new();
    let mut buf = [0u8; 1024 * 128];
    loop {
        match f.read(&mut buf) {
            Ok(0) => break,
            Ok(n) => hasher.update(&buf[..n]),
            Err(_) => return false,
        }
    }
    hex::encode(hasher.finalize()).eq_ignore_ascii_case(expected_sha256)
}

fn safe_target(base: &Path, relative: &str) -> Result<PathBuf> {
    let rel = Path::new(relative);
    if rel.is_absolute() || relative.contains('\\') || relative.contains(':') {
        return Err(LauncherError::Integrity(format!("Caminho inseguro no seed: {relative}")));
    }
    for c in rel.components() {
        if matches!(c, std::path::Component::ParentDir | std::path::Component::RootDir | std::path::Component::Prefix(_)) {
            return Err(LauncherError::Integrity(format!("Caminho inseguro no seed: {relative}")));
        }
    }
    Ok(base.join(rel))
}


pub async fn download_configured() -> Result<SeedPackStatus> {
    paths::ensure_layout()?;
    let url = release::value("ECLIPSE_SEED_URL");
    let expected = release::value("ECLIPSE_SEED_SHA256").to_ascii_lowercase();
    if url.trim().is_empty() { return Err(LauncherError::Config("Seed remoto não configurado".into())); }
    let parsed = url::Url::parse(&url).map_err(|_| LauncherError::Config("ECLIPSE_SEED_URL inválida".into()))?;
    if parsed.scheme() != "https" && !(cfg!(debug_assertions) && parsed.scheme() == "http") {
        return Err(LauncherError::Config("Seed remoto precisa usar HTTPS".into()));
    }
    if expected.len() != 64 || !expected.chars().all(|c| c.is_ascii_hexdigit()) {
        return Err(LauncherError::Config("ECLIPSE_SEED_SHA256 precisa conter 64 caracteres hexadecimais".into()));
    }
    let target = paths::root_dir()?.join(SEED_NAME);
    let part = target.with_extension("zip.part");
    if let Some(parent) = target.parent() { fs::create_dir_all(parent)?; }

    // Reuse a previously downloaded seed only after checking the exact hash.
    if target.is_file() && existing_matches(&target, fs::metadata(&target)?.len(), &expected) {
        return Ok(detect());
    }

    let client = reqwest::Client::builder()
        .user_agent("EclipseLauncher/1.0")
        .connect_timeout(std::time::Duration::from_secs(12))
        .timeout(std::time::Duration::from_secs(60 * 30))
        .build()?;
    let response = client.get(&url).send().await?.error_for_status()?;
    let expected_len = response.content_length();
    let mut stream = response.bytes_stream();
    let mut out = fs::File::create(&part)?;
    let mut hasher = Sha256::new();
    let mut written = 0u64;
    while let Some(chunk) = stream.next().await {
        let chunk = chunk?;
        out.write_all(&chunk)?;
        hasher.update(&chunk);
        written += chunk.len() as u64;
    }
    out.flush()?;
    if let Some(len) = expected_len {
        if len != written { let _ = fs::remove_file(&part); return Err(LauncherError::Integrity("Seed remoto terminou com tamanho inesperado".into())); }
    }
    let got = hex::encode(hasher.finalize());
    if !got.eq_ignore_ascii_case(&expected) {
        let _ = fs::remove_file(&part);
        return Err(LauncherError::Integrity(format!("SHA-256 do Seed remoto inválido: esperado {expected}, recebido {got}")));
    }
    if target.exists() { fs::remove_file(&target)?; }
    fs::rename(&part, &target)?;
    // Parsing the manifest is the final structural validation before exposing it to install().
    let _ = read_manifest(&target)?;
    Ok(detect())
}

pub fn install(path: Option<String>) -> Result<SeedInstallReport> {
    paths::ensure_layout()?;
    let seed = if let Some(p) = path.filter(|p| !p.trim().is_empty()) {
        PathBuf::from(p)
    } else {
        detect().path.map(PathBuf::from).ok_or_else(|| LauncherError::Config(format!("{SEED_NAME} não foi encontrado. Coloque-o ao lado do instalador/launcher ou na pasta Downloads.")))?
    };
    if !seed.is_file() { return Err(LauncherError::Config("Seed pack não encontrado".into())); }

    let manifest_data = read_manifest(&seed)?;
    let file = fs::File::open(&seed)?;
    let mut zip = zip::ZipArchive::new(file).map_err(zip_err)?;
    let instance = paths::instance_dir()?;
    fs::create_dir_all(&instance)?;

    let mut installed = 0usize;
    let mut bytes = 0u64;
    for managed in &manifest_data.files {
        if managed.mode == "optional" { continue; }
        let entry_name = format!("pack/{}", managed.path);
        let mut item = zip.by_name(&entry_name).map_err(|_| LauncherError::Integrity(format!("Seed incompleto: {entry_name} não existe")))?;
        let target = safe_target(&instance, &managed.path)?;
        if existing_matches(&target, managed.size, &managed.sha256) {
            // Player may be reopening a portable bundle after a partial/finished install.
            // Reuse files that are already byte-identical instead of extracting them again.
            installed += 1;
            bytes += managed.size;
            continue;
        }
        if let Some(parent) = target.parent() { fs::create_dir_all(parent)?; }
        let part = target.with_extension(format!("{}seed-part", target.extension().and_then(|x|x.to_str()).map(|x|format!("{x}.")).unwrap_or_default()));
        let mut out = fs::File::create(&part)?;
        let mut hasher = Sha256::new();
        let mut copied = 0u64;
        let mut buffer = [0u8; 1024 * 128];
        loop {
            let n = item.read(&mut buffer)?;
            if n == 0 { break; }
            out.write_all(&buffer[..n])?;
            hasher.update(&buffer[..n]);
            copied += n as u64;
        }
        out.flush()?;
        let got = hex::encode(hasher.finalize());
        if copied != managed.size || !got.eq_ignore_ascii_case(&managed.sha256) {
            let _ = fs::remove_file(&part);
            return Err(LauncherError::Integrity(format!("Seed corrompido em {}", managed.path)));
        }
        if target.exists() { fs::remove_file(&target)?; }
        fs::rename(&part, &target)?;
        installed += 1;
        bytes += copied;
    }

    let manifest_path = paths::manifest_path()?;
    let previous = paths::previous_manifest_path()?;
    if manifest_path.exists() {
        let _ = fs::remove_file(&previous);
        let _ = fs::copy(&manifest_path, &previous);
    }
    let temp = manifest_path.with_extension("json.seed-tmp");
    fs::write(&temp, serde_json::to_vec_pretty(&manifest_data)?)?;
    fs::rename(&temp, &manifest_path)?;

    Ok(SeedInstallReport {
        installed_files: installed,
        bytes_installed: bytes,
        pack_version: manifest_data.pack.version,
        seed_path: seed.display().to_string(),
    })
}
