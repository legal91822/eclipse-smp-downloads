use std::fs;
use crate::{error::{LauncherError, Result}, models::{LauncherSettings, LaunchMode}, paths};

pub fn load() -> Result<LauncherSettings> {
    paths::ensure_layout()?;
    let p = paths::config_path()?;
    if !p.exists() { let s=LauncherSettings::default(); save(&s)?; return Ok(s); }
    let s:LauncherSettings=serde_json::from_str(&fs::read_to_string(&p)?)?;
    validate(&s)?;
    Ok(s)
}

pub fn save(settings:&LauncherSettings)->Result<()> {
    validate(settings)?;
    paths::ensure_layout()?;
    let p=paths::config_path()?;
    let temp=p.with_extension("json.tmp");
    fs::write(&temp,serde_json::to_vec_pretty(settings)?)?;
    if p.exists(){ let bak=p.with_extension("json.bak"); let _=fs::remove_file(&bak); fs::rename(&p,&bak)?; if let Err(e)=fs::rename(&temp,&p){let _=fs::rename(&bak,&p);return Err(e.into())} let _=fs::remove_file(bak); } else {fs::rename(temp,p)?;}
    Ok(())
}

pub fn reset()->Result<LauncherSettings>{ let s=LauncherSettings::default(); save(&s)?; Ok(s) }

pub fn active_manifest_url(settings:&LauncherSettings)->String{
    let chosen=match settings.channel.as_str(){
        "beta"=>settings.beta_manifest_url.trim(),
        "staff"=>settings.staff_manifest_url.trim(),
        _=>settings.stable_manifest_url.trim(),
    };
    if chosen.is_empty(){settings.manifest_url.trim().to_string()}else{chosen.to_string()}
}

fn validate_https_optional(label:&str,value:&str)->Result<()> {
    if value.trim().is_empty(){return Ok(())}
    let parsed=url::Url::parse(value).map_err(|_|LauncherError::Config(format!("{label} inválida")))?;
    if parsed.scheme()!="https" && !(cfg!(debug_assertions)&&parsed.scheme()=="http") { return Err(LauncherError::Config(format!("{label} deve usar HTTPS"))); }
    Ok(())
}

pub fn validate(settings:&LauncherSettings)->Result<()> {
    if !(2048..=32768).contains(&settings.ram_mb){return Err(LauncherError::Config("RAM deve ficar entre 2 e 32 GB".into()))}
    if settings.offline_name.len()>16 || !settings.offline_name.chars().all(|c|c.is_ascii_alphanumeric()||c=='_'){return Err(LauncherError::Config("Nome offline deve ter até 16 caracteres e usar somente letras, números ou _".into()))}
    if matches!(&settings.launch_mode,LaunchMode::Offline)&&settings.offline_name.trim().is_empty(){return Err(LauncherError::Config("Perfil Offline precisa de um nome".into()))}
    if !matches!(settings.channel.as_str(),"stable"|"beta"|"staff"){return Err(LauncherError::Config("Canal deve ser stable, beta ou staff".into()))}
    if !(1..=12).contains(&settings.max_parallel_downloads){return Err(LauncherError::Config("Downloads paralelos devem ficar entre 1 e 12".into()))}
    if !(1..=12).contains(&settings.backup_limit){return Err(LauncherError::Config("Limite de backups deve ficar entre 1 e 12".into()))}
    if let Some(path)=settings.official_launcher_path.as_deref(){if path.trim().is_empty(){return Err(LauncherError::Config("Caminho do launcher oficial não pode ser vazio".into()))}}
    for (label,value) in [
        ("URL do manifesto",settings.manifest_url.as_str()),
        ("Manifesto Stable",settings.stable_manifest_url.as_str()),
        ("Manifesto Beta",settings.beta_manifest_url.as_str()),
        ("Manifesto Staff",settings.staff_manifest_url.as_str()),
        ("Bootstrap Eclipse",settings.bootstrap_url.as_str()),
    ] { validate_https_optional(label,value)?; }
    Ok(())
}
