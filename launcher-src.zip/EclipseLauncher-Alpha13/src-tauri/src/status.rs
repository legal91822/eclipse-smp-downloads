use std::fs;
use crate::{error::{LauncherError,Result},manifest,models::ServerStatus,paths};
fn cache_path()->Result<std::path::PathBuf>{Ok(paths::cache_dir()?.join("api/status.json"))}
pub async fn fetch()->Result<ServerStatus>{
    let m=manifest::load_local()?;let endpoint=m.endpoints.status.ok_or_else(||LauncherError::Config("Endpoint de status do servidor não configurado".into()))?;let client=reqwest::Client::builder().user_agent("EclipseLauncher/1.0").timeout(std::time::Duration::from_secs(8)).build()?;
    match client.get(endpoint).send().await.and_then(|r|r.error_for_status()){
        Ok(r)=>{let data=r.json::<ServerStatus>().await?;let p=cache_path()?;if let Some(parent)=p.parent(){fs::create_dir_all(parent)?;}let _=fs::write(p,serde_json::to_vec(&data)?);Ok(data)}
        Err(e)=>{let p=cache_path()?;if let Ok(s)=fs::read_to_string(p){if let Ok(mut cached)=serde_json::from_str::<ServerStatus>(&s){cached.message.get_or_insert("Status em cache: API indisponível".into());return Ok(cached)}}Err(e.into())}
    }
}
