use std::process::Command;
use crate::{error::Result, models::SystemProfile, paths};

fn total_ram_mb()->u64{
    #[cfg(target_os="windows")]
    {
        if let Ok(out)=Command::new("powershell.exe").args(["-NoProfile","-Command","[math]::Floor((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1MB)"]).output(){
            if out.status.success(){if let Ok(v)=String::from_utf8_lossy(&out.stdout).trim().parse(){return v;}}
        }
    }
    #[cfg(target_os="linux")]
    {
        if let Ok(s)=std::fs::read_to_string("/proc/meminfo"){for l in s.lines(){if let Some(v)=l.strip_prefix("MemTotal:"){if let Some(kb)=v.split_whitespace().next().and_then(|x|x.parse::<u64>().ok()){return kb/1024}}}}
    }
    0
}

pub fn profile()->Result<SystemProfile>{
    let total=total_ram_mb();let threads=std::thread::available_parallelism().map(|x|x.get()).unwrap_or(1);
    let recommended=match total{0=>8192,1..=8192=>4096,8193..=12288=>5120,12289..=16384=>6144,16385..=24576=>8192,24577..=32768=>10240,_=>12288};
    let instance=paths::instance_dir()?;let free=fs2::available_space(&instance).unwrap_or(0);
    Ok(SystemProfile{total_ram_mb:total,cpu_threads:threads,recommended_ram_mb:recommended,free_instance_disk_bytes:free})
}
