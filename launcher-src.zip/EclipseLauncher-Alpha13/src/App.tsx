import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  Activity, Archive, Box, CalendarDays, CheckCircle2, ChevronDown, ChevronRight, CircleUserRound,
  CloudDownload, Cpu, Download, FolderOpen, Gauge, HardDrive, Headphones, Home, Info, Keyboard,
  LogIn, LogOut, Music2, Newspaper, Pause, Play, RefreshCw, RotateCcw, Settings, ShieldAlert,
  ShieldCheck, Sparkles, Square, TerminalSquare, Trash2, Volume2, Wrench, XCircle, Zap
} from "lucide-react";
import {
  analyzeCrash, applyPostLaunchBehavior, bootstrapMinecraft, cancelDownloads, checkLauncherUpdate, clearCache,
  createBackup, createSupportBundle, deleteBackup, getDiagnostics, getEvents, getNews, getOptionalMods,
  getPackStats, getPublicConfig, getReleaseReadiness, getRepairProgress, getSeedPackStatus, getServerStatus, getState, getSystemProfile, installForge, downloadSeedPack,
  installLauncherUpdate, installManagedJava, installSeedPack, launchGame, listBackups, microsoftLogin, microsoftLogout,
  microsoftState, openBackupsFolder, openCacheFolder, openExternalUrl, openInstanceFolder, openLogsFolder, openSupportFolder,
  pauseDownloads, provisionInstallation, repairOfficialProfile, repairPack, resetSettings, resumeDownloads, rollbackBackup,
  saveSettings, scanConflicts, setOptionalMod, startupCheck, syncManifest, verifyPack,
  type BackupInfo, type ConflictReport, type CrashAnalysis, type DiagnosticReport, type DownloadProgress,
  type EventItem, type LauncherSettings, type LauncherState, type LauncherUpdateInfo, type MicrosoftProfile, type PublicConfig, type ReleaseReadiness, type SeedPackStatus,
  type NewsItem, type OptionalModInfo, type PackStats, type ServerStatus, type StartupReport, type SystemProfile, type VerifyReport
} from "./lib/tauri";

type Page="home"|"pack"|"news"|"diagnostics"|"settings";
type SettingTab="game"|"launcher"|"audio"|"updates"|"advanced";
type Busy="play"|"provision"|"seed"|"verify"|"repair"|"sync"|"bootstrap"|"java"|"forge"|"profile"|"backup"|"rollback"|"support"|"auth"|"update"|null;
type Toast={text:string;kind:"info"|"success"|"warning"|"error"}|null;
type Ambient={music:boolean;uiSounds:boolean;animations:boolean;musicVolume:number;uiVolume:number;motion:"reduced"|"normal"|"cinematic"};

const nav=[["home",Home,"Início"],["pack",Box,"Modpack"],["news",Newspaper,"Notícias"],["diagnostics",Activity,"Diagnóstico"],["settings",Settings,"Configurações"]] as const;
const defaultSettings:LauncherSettings={launch_mode:"official",offline_name:"Player",ram_mb:8192,channel:"stable",manifest_url:"",stable_manifest_url:"",beta_manifest_url:"",staff_manifest_url:"",official_launcher_path:null,auto_verify_on_start:true,auto_repair_before_launch:false,auto_update_launcher:true,auto_backup_before_update:true,backup_limit:5,minimize_on_launch:true,close_after_launch:false,max_parallel_downloads:4,optional_enabled:[],reduce_data_usage:false,auto_update_pack:true,verify_after_update:true,bootstrap_url:""};
const emptyConflict:ConflictReport={extra_mods:[],duplicate_mods:[],missing_managed:[],corrupted_managed:[]};
function loadAmbient():Ambient{const f:Ambient={music:false,uiSounds:true,animations:true,musicVolume:16,uiVolume:28,motion:"reduced"};try{return{...f,...JSON.parse(localStorage.getItem("eclipse.ambient.v3")||"{}")}}catch{return f}}
function fmtBytes(n:number){if(!n)return"0 B";const u=["B","KB","MB","GB","TB"],i=Math.min(Math.floor(Math.log(n)/Math.log(1024)),u.length-1);return `${(n/1024**i).toFixed(i>1?1:0)} ${u[i]}`}
function fmtPlayers(s:ServerStatus|null){if(!s?.online)return"Offline";return s.players_online!=null&&s.players_max!=null?`${s.players_online}/${s.players_max}`:"Online"}
function countdown(at:string,now:number){let ms=Math.max(0,new Date(at).getTime()-now);const d=Math.floor(ms/86400000);ms%=86400000;const h=Math.floor(ms/3600000);ms%=3600000;const m=Math.floor(ms/60000);ms%=60000;const sec=Math.floor(ms/1000);return[d,h,m,sec].map(v=>String(v).padStart(2,"0"))}
function formatBackupDate(v:string){const sec=Number(v);return Number.isFinite(sec)?new Date(sec*1000).toLocaleString("pt-BR"):v}

export default function App(){
  const [page,setPage]=useState<Page>("home"),[settingsTab,setSettingsTab]=useState<SettingTab>("game");
  const [state,setState]=useState<LauncherState|null>(null),[settings,setSettings]=useState<LauncherSettings>(defaultSettings),[savedSettings,setSavedSettings]=useState<LauncherSettings>(defaultSettings);
  const [server,setServer]=useState<ServerStatus|null>(null),[news,setNews]=useState<NewsItem[]>([]),[events,setEvents]=useState<EventItem[]>([]),[verify,setVerify]=useState<VerifyReport|null>(null);
  const [optionalMods,setOptionalMods]=useState<OptionalModInfo[]>([]),[backups,setBackups]=useState<BackupInfo[]>([]),[stats,setStats]=useState<PackStats|null>(null),[system,setSystem]=useState<SystemProfile|null>(null);
  const [conflicts,setConflicts]=useState<ConflictReport>(emptyConflict),[crash,setCrash]=useState<CrashAnalysis|null>(null),[diagnostic,setDiagnostic]=useState<DiagnosticReport|null>(null),[profile,setProfile]=useState<MicrosoftProfile>({connected:false,minecraft_name:"",minecraft_uuid:""});
  const [publicConfig,setPublicConfig]=useState<PublicConfig>({site_url:"",discord_url:"",rules_url:"",wiki_url:"",support_url:"",bootstrap_url:"",seed_url:"",seed_sha256:""}),[release,setRelease]=useState<ReleaseReadiness|null>(null);
  const [seed,setSeed]=useState<SeedPackStatus>({available:false,path:null,size:0,pack_version:null});
  const [download,setDownload]=useState<DownloadProgress|null>(null),[update,setUpdate]=useState<LauncherUpdateInfo|null>(null),[startup,setStartup]=useState<StartupReport|null>(null),[ambient,setAmbient]=useState<Ambient>(loadAmbient),[busy,setBusy]=useState<Busy>(null),[toast,setToast]=useState<Toast>(null),[now,setNow]=useState(Date.now()),[booting,setBooting]=useState(true);
  const audioRef=useRef<AudioContext|null>(null),musicRef=useRef<HTMLAudioElement|null>(null),hoverAt=useRef(0);
  const dirty=useMemo(()=>JSON.stringify(settings)!==JSON.stringify(savedSettings),[settings,savedSettings]);
  const modeLabel=settings.launch_mode==="official"?"Minecraft Launcher":settings.launch_mode==="direct"?"Eclipse Direct":"Perfil Offline";
  const event=events.slice().sort((a,b)=>new Date(a.starts_at).getTime()-new Date(b.starts_at).getTime())[0],eventTime=event?countdown(event.starts_at,now):["05","14","27","32"];
  const maintenance=Boolean(server?.maintenance),integrityProblem=Boolean(verify&&(verify.missing.length+verify.corrupted.length));
  const readyForMode=state?settings.launch_mode==="official"?state.readiness.official_profile:settings.launch_mode==="direct"?state.readiness.direct_files&&state.readiness.microsoft_auth:state.readiness.direct_files:false;
  const packUpdatePending=Boolean(startup&&(startup.estimate.files>0||startup.estimate.stale_files>0));
  const noManifest=Boolean(state&&!state.readiness.manifest);
  const firstInstall=Boolean(startup?.first_install||noManifest);
  const canSeed=Boolean(seed.available&&noManifest);
  const canRemoteSeed=Boolean(noManifest&&!seed.available&&publicConfig.seed_url&&publicConfig.seed_sha256);
  const distributionBlocked=Boolean(firstInstall&&release&&!release.distribution_ready&&!canSeed&&!canRemoteSeed);

  useEffect(()=>{const id=setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(id)},[]);
  useEffect(()=>{void boot()},[]);
  useEffect(()=>{const id=setInterval(()=>{if(document.visibilityState==="visible")void refreshLive()},60000);return()=>clearInterval(id)},[]);
  useEffect(()=>{try{localStorage.setItem("eclipse.ambient.v3",JSON.stringify(ambient))}catch{}document.documentElement.dataset.motion=ambient.animations?ambient.motion:"reduced"},[ambient]);
  useEffect(()=>{if(!musicRef.current){const a=new Audio("/audio/eclipse-ambient.wav");a.loop=true;a.preload="auto";musicRef.current=a;}const a=musicRef.current;a.volume=Math.min(.35,ambient.musicVolume/100*.35);if(ambient.music){void a.play().catch(()=>{})}else{a.pause()}return()=>{}},[ambient.music,ambient.musicVolume]);
  useEffect(()=>{if(!toast)return;const id=setTimeout(()=>setToast(null),toast.kind==="error"?7000:4300);return()=>clearTimeout(id)},[toast]);
  useEffect(()=>{if(!download?.running)return;const id=setInterval(()=>void getRepairProgress().then(setDownload),250);return()=>clearInterval(id)},[download?.running]);
  useEffect(()=>{const fn=(e:KeyboardEvent)=>{if(e.ctrlKey&&e.key==="Enter"){e.preventDefault();void play()}else if(e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()==="v"){e.preventDefault();void verifyNow()}else if(e.ctrlKey&&e.key===","){e.preventDefault();go("settings")}else if(e.altKey&&["1","2","3","4","5"].includes(e.key)){e.preventDefault();go(nav[Number(e.key)-1][0])}else if(e.key==="Escape")setToast(null)};window.addEventListener("keydown",fn);return()=>window.removeEventListener("keydown",fn)});

  async function boot(){
    try{
      const s=await getState();setState(s);setSettings(s.settings);setSavedSettings(s.settings);
      let start:StartupReport|null=null;
      try{start=await startupCheck();setStartup(start);if(start.launcher_update)setUpdate(start.launcher_update);const synced=await getState();setState(synced);setSettings(synced.settings);setSavedSettings(synced.settings)}catch(e){if(!s.readiness.manifest)notify(`Não foi possível localizar o modpack: ${e}`,"warning")}
      setBooting(false);
      await Promise.allSettled([refreshLive(),loadPackTools(),microsoftState().then(setProfile),getSystemProfile().then(setSystem),getPublicConfig().then(setPublicConfig),getReleaseReadiness().then(setRelease),getSeedPackStatus().then(setSeed),start?.launcher_update?Promise.resolve():checkLauncherUpdate().then(setUpdate)]);
      if(start&&!start.first_install&&s.settings.auto_update_pack&&(start.estimate.files>0||start.estimate.stale_files>0))void provisionNow(true);
      else if(s.settings.auto_verify_on_start&&s.readiness.manifest)void verifyPack().then(setVerify);
    }catch(e){setBooting(false);notify(`Falha ao iniciar: ${e}`,"error")}
  }
  async function refreshState(){const s=await getState();setState(s);setSettings(s.settings);setSavedSettings(s.settings);return s}
  async function refreshLive(){await Promise.allSettled([getServerStatus().then(setServer),getNews().then(setNews),getEvents().then(setEvents)])}
  async function loadPackTools(){await Promise.allSettled([getOptionalMods().then(setOptionalMods),listBackups().then(setBackups),getPackStats().then(setStats),scanConflicts().then(setConflicts),analyzeCrash().then(setCrash)])}
  function notify(text:string,kind:"info"|"success"|"warning"|"error"="info"){setToast({text,kind})}
  function patch(p:Partial<LauncherSettings>){setSettings(v=>({...v,...p}))}
  function go(p:Page){setPage(p)}
  function tone(kind:"hover"|"tap"|"success"|"error"|"download"|"play"){if(!ambient.uiSounds)return;const t=performance.now();if(kind==="hover"&&t-hoverAt.current<100)return;if(kind==="hover")hoverAt.current=t;try{const ctx=audioRef.current??(audioRef.current=new AudioContext());if(ctx.state==="suspended")void ctx.resume();const o=ctx.createOscillator(),g=ctx.createGain();const cfg={hover:[430,.025,.004],tap:[570,.045,.008],success:[760,.09,.012],error:[220,.11,.012],download:[330,.08,.007],play:[620,.11,.012]}[kind] as number[];o.type="sine";o.frequency.value=cfg[0];g.gain.setValueAtTime(.0001,ctx.currentTime);g.gain.exponentialRampToValueAtTime(Math.max(.0001,cfg[2]*(ambient.uiVolume/100)),ctx.currentTime+.006);g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+cfg[1]);o.connect(g).connect(ctx.destination);o.start();o.stop(ctx.currentTime+cfg[1]+.02)}catch{}}
  async function saveAll(){try{await saveSettings(settings);setSavedSettings(settings);await refreshState();notify("Configurações salvas.","success")}catch(e){notify(String(e),"error")}}
  async function provisionNow(silent=false){
    tone("download");setBusy("provision");setDownload({running:true,paused:false,cancelled:false,current_file:"",files_total:startup?.estimate.files||0,files_done:0,bytes_total:startup?.estimate.bytes||0,bytes_done:0,message:firstInstall?"Instalando Eclipse SMP":"Atualizando Eclipse SMP"});
    try{
      const r=await provisionInstallation();
      if(!silent)notify(`${r.first_install?"Instalação":"Atualização"} concluída: ${r.pack_version}.`,"success");
      const next=await refreshState();setVerify(r.final_verify);await loadPackTools();
      const fresh=await startupCheck().catch(()=>null);if(fresh)setStartup(fresh);
      return next;
    }catch(e){tone("error");notify(String(e),"error");throw e}
    finally{setBusy(null);setDownload(await getRepairProgress().catch(()=>null))}
  }
  async function installLocalSeed(){
    setBusy("seed");tone("download");
    try{
      const r=await installSeedPack();
      notify(`Pack local ${r.pack_version} instalado: ${r.installed_files} arquivos (${fmtBytes(r.bytes_installed)}).`,"success");
      await refreshState();
      await bootstrapMinecraft();
      await refreshState();
      await loadPackTools();
      const fresh=await startupCheck().catch(()=>null);if(fresh)setStartup(fresh);
      setSeed(await getSeedPackStatus().catch(()=>seed));
    }catch(e){tone("error");notify(String(e),"error");throw e}
    finally{setBusy(null)}
  }
  async function installRemoteSeed(){
    setBusy("seed");tone("download");
    try{
      const downloaded=await downloadSeedPack();setSeed(downloaded);
      const r=await installSeedPack(downloaded.path||null);
      notify(`Pack ${r.pack_version} baixado e instalado: ${r.installed_files} arquivos.`,"success");
      await refreshState();await bootstrapMinecraft();await refreshState();await loadPackTools();
      const fresh=await startupCheck().catch(()=>null);if(fresh)setStartup(fresh);
    }catch(e){tone("error");notify(String(e),"error");throw e}
    finally{setBusy(null)}
  }
  async function play(){tone("play");if(maintenance&&settings.channel!=="staff"){notify(server?.maintenance_message||"Servidor em manutenção.","warning");return}if(dirty)await saveAll();try{if(!state?.readiness.manifest&&seed.available)await installLocalSeed();else if(!state?.readiness.manifest&&canRemoteSeed)await installRemoteSeed();else if(firstInstall||packUpdatePending||!readyForMode)await provisionNow();setBusy("play");const msg=await launchGame();tone("success");notify(msg,"success");await applyPostLaunchBehavior(settings)}catch(e){tone("error");notify(String(e),"error")}finally{setBusy(null)}}
  async function verifyNow(){setBusy("verify");try{const r=await verifyPack();setVerify(r);notify(r.missing.length+r.corrupted.length?"A verificação encontrou arquivos para reparar.":"Instalação íntegra.",r.missing.length+r.corrupted.length?"warning":"success")}catch(e){notify(String(e),"error")}finally{setBusy(null)}}
  async function repairNow(){tone("download");setBusy("repair");setDownload({running:true,paused:false,cancelled:false,current_file:"",files_total:0,files_done:0,bytes_total:0,bytes_done:0,message:"Preparando"});try{const r=await repairPack();notify(`Reparo concluído: ${r.repaired} arquivo(s), ${fmtBytes(r.bytes_downloaded)} baixados${r.resumed_bytes?` • ${fmtBytes(r.resumed_bytes)} retomados`:""}.`,"success");await verifyNow();await loadPackTools()}catch(e){notify(String(e),"error")}finally{setBusy(null);setDownload(await getRepairProgress().catch(()=>null))}}
  async function syncNow(){setBusy("sync");try{await syncManifest();notify(`Manifesto ${settings.channel} sincronizado.`,"success");await refreshState();setStartup(await startupCheck().catch(()=>startup));await loadPackTools()}catch(e){notify(String(e),"error")}finally{setBusy(null)}}
  async function bootstrap(){setBusy("bootstrap");try{await bootstrapMinecraft();notify("Java, Forge e arquivos Direct/Offline preparados.","success");await refreshState()}catch(e){notify(String(e),"error")}finally{setBusy(null)}}
  async function step(kind:"java"|"forge"|"profile"){setBusy(kind);try{if(kind==="java")await installManagedJava();else if(kind==="forge")await installForge();else await repairOfficialProfile();await refreshState();notify("Etapa concluída.","success")}catch(e){notify(String(e),"error")}finally{setBusy(null)}}
  async function connectMicrosoft(){setBusy("auth");try{const p=await microsoftLogin();setProfile(p);await refreshState();notify(`Microsoft conectada como ${p.minecraft_name}.`,"success")}catch(e){notify(String(e),"error")}finally{setBusy(null)}}
  async function disconnectMicrosoft(){try{await microsoftLogout();setProfile({connected:false,minecraft_name:"",minecraft_uuid:""});await refreshState();notify("Conta desconectada.","success")}catch(e){notify(String(e),"error")}}
  async function toggleOptional(m:OptionalModInfo){try{const next=await setOptionalMod(m.id,!m.enabled);setSettings(next);setSavedSettings(next);await getOptionalMods().then(setOptionalMods);notify(`${m.name}: ${!m.enabled?"ativado":"desativado"}. Rode Sincronizar/Reparar para aplicar.`,"success")}catch(e){notify(String(e),"error")}}
  async function backupNow(){setBusy("backup");try{const b=await createBackup();notify(`Backup criado (${b.files} arquivos).`,"success");setBackups(await listBackups())}catch(e){notify(String(e),"error")}finally{setBusy(null)}}
  async function rollback(id:string){setBusy("rollback");try{const n=await rollbackBackup(id);notify(`Rollback restaurou ${n} arquivos.`,"success");await refreshState();await loadPackTools()}catch(e){notify(String(e),"error")}finally{setBusy(null)}}
  async function support(){setBusy("support");try{const r=await createSupportBundle();notify(`Pacote de suporte criado: ${r.path}`,"success");await openSupportFolder()}catch(e){notify(String(e),"error")}finally{setBusy(null)}}
  async function refreshDiagnostics(){try{const [d,c,x]=await Promise.all([getDiagnostics(),scanConflicts(),analyzeCrash()]);setDiagnostic(d);setConflicts(c);setCrash(x)}catch(e){notify(String(e),"error")}}
  async function installUpdate(){setBusy("update");try{await installLauncherUpdate()}catch(e){notify(String(e),"error");setBusy(null)}}
  async function restoreDefaults(){try{const v=await resetSettings();setSettings(v);setSavedSettings(v);notify("Configurações restauradas.","success")}catch(e){notify(String(e),"error")}}
  async function applyRecommendedRam(){if(!system)return;patch({ram_mb:system.recommended_ram_mb});notify(`RAM recomendada: ${Math.round(system.recommended_ram_mb/1024)} GB.`,"info")}
  function toggleMusic(){const next=!ambient.music;if(!musicRef.current){const a=new Audio("/audio/eclipse-ambient.wav");a.loop=true;a.preload="auto";musicRef.current=a;}const a=musicRef.current;a.volume=Math.min(.35,ambient.musicVolume/100*.35);setAmbient(v=>({...v,music:next}));if(next){void a.play().catch(()=>notify("O WebView bloqueou o áudio até a próxima interação.","warning"))}else{a.pause()}}

  if(booting)return <div className="boot-screen"><img src="/eclipse-logo.png" className="boot-logo"/><span>Preparando o launcher…</span></div>;

  return <div className="app-shell" onPointerOver={e=>{const b=(e.target as HTMLElement).closest("button"),prev=(e.relatedTarget as HTMLElement|null)?.closest?.("button");if(b&&b!==prev)tone("hover")}} onPointerDown={e=>{const b=(e.target as HTMLElement).closest("button");if(b&&!b.matches(".play,.repair-button"))tone("tap")}}>
    <aside className="sidebar">
      <button className="brand" onClick={()=>go("home")}><img src="/eclipse-logo.png" className="brand-logo" alt="Eclipse Launcher"/></button>
      <nav>{nav.map(([id,Icon,label])=><button key={id} className={page===id?"active":""} onClick={()=>go(id)}><Icon size={19}/><span>{label}</span></button>)}</nav>
      <div className="sidebar-foot"><small>ECLIPSE LAUNCHER</small><b>{state?.app_version}</b></div>
    </aside>

    <main className="content">
      <header className="topbar"><div className="page-heading"><span>{page==="home"?"Bem-vindo de volta,":"Eclipse Launcher"}</span><h1>{page==="home"?(settings.launch_mode==="offline"?settings.offline_name||"Jogador":profile.connected?profile.minecraft_name:"Jogador"):nav.find(n=>n[0]===page)?.[2]}</h1></div><button className="account" onClick={()=>{go("settings");setSettingsTab("game")}}><span className="avatar"><CircleUserRound/><i/></span><span><b>{profile.connected?profile.minecraft_name:settings.launch_mode==="offline"?settings.offline_name:"Jogador"}</b><small>{modeLabel}</small></span><ChevronDown size={16}/></button></header>

      {update&&<div className={`update-banner ${update.mandatory?"mandatory":""}`}><CloudDownload/><div><b>{update.mandatory?"Atualização obrigatória":"Atualização disponível"}: {update.version}</b><small>Assinatura criptográfica + SHA-256 serão verificados antes da instalação.</small></div><button onClick={()=>void installUpdate()} disabled={busy==="update"}>{busy==="update"?"INSTALANDO…":"ATUALIZAR"}</button></div>}
      {maintenance&&<div className="maintenance-banner"><ShieldAlert/><div><b>Eclipse SMP em manutenção</b><small>{server?.maintenance_message||"O botão Jogar fica bloqueado até o servidor voltar."}</small></div></div>}

      <div className="page-body" key={page}>
        {page==="home"&&<>
          <section className="home-focus">
            <div className="home-focus-art"/>
            <div className="home-focus-copy">
              <div className="hero-kicker">ECLIPSE SMP <i/></div>
              <h2>Seu mundo.<br/><em>Um clique.</em></h2>
              <p>O launcher instala, atualiza e repara o Eclipse sem você precisar mexer em pasta nenhuma.</p>
              <div className="home-play-row">
                <button className={`play ${busy==="play"||busy==="provision"?"loading":""}`} onClick={()=>void play()} disabled={Boolean(busy)||maintenance||distributionBlocked}>
                  <Play fill="currentColor"/>
                  {busy==="provision"?(firstInstall?"INSTALANDO…":"ATUALIZANDO…"):busy==="play"?"ABRINDO…":busy==="seed"?"INSTALANDO PACK…":maintenance?"MANUTENÇÃO":distributionBlocked?"CONFIGURAÇÃO NECESSÁRIA":canSeed?"INSTALAR PACK LOCAL":canRemoteSeed?"BAIXAR E JOGAR":firstInstall?"INSTALAR E JOGAR":packUpdatePending?"ATUALIZAR E JOGAR":readyForMode?"JOGAR":"PREPARAR E JOGAR"}
                </button>
                <button className="launch-options" aria-label="Opções de inicialização" onClick={()=>{go("settings");setSettingsTab("game")}}><ChevronDown/></button>
              </div>
              <div className="home-ready-line">
                <span className={state?.readiness.minecraft_runtime?"ok":"pending"}><i/>{state?.readiness.minecraft_runtime?"Java pronto":"Java pendente"}</span>
                <span className={state?.readiness.forge?"ok":"pending"}><i/>Forge {state?.pack?.forge||"47.4.10"}</span>
                <span className={readyForMode?"ok":"pending"}><i/>{readyForMode?"Perfil pronto":"Perfil pendente"}</span>
                <button onClick={()=>{go("settings");setSettingsTab("launcher")}}>{settings.channel.toUpperCase()}</button>
              </div>
            </div>
          </section>

          {(firstInstall||packUpdatePending||!readyForMode)&&<div className={`home-task ${firstInstall?"first-install":""}`}>
            <span className="home-task-icon">{canSeed?<Archive/>:canRemoteSeed?<CloudDownload/>:firstInstall?<CloudDownload/>:packUpdatePending?<RefreshCw/>:<Wrench/>}</span>
            <div><b>{canSeed?`Pack local ${seed.pack_version||"Eclipse SMP"} encontrado`:canRemoteSeed?"Eclipse SMP pronto para baixar":distributionBlocked?"Distribuição ainda não configurada":firstInstall?"Primeira instalação do Eclipse SMP":packUpdatePending?`Atualização ${startup?.remote_pack_version||"nova"} disponível`:"Minecraft precisa ser preparado"}</b><small>{canSeed?`${fmtBytes(seed.size)} • instalação local validada por SHA-256`:canRemoteSeed?"O launcher baixa o pack oficial, valida SHA-256 e instala sozinho.":distributionBlocked?"Adicione EclipseSMP-Seed.zip ou configure o Bootstrap HTTPS antes da build pública.":firstInstall?`${startup?.estimate.files||0} arquivos • ${fmtBytes(startup?.estimate.bytes||0)} para baixar`:packUpdatePending?`${startup?.estimate.files||0} arquivo(s) alterados • ${fmtBytes(startup?.estimate.bytes||0)}`:"Java, Forge e perfil são preparados automaticamente."}</small></div>
            <button onClick={()=>void (canSeed?installLocalSeed():canRemoteSeed?installRemoteSeed():provisionNow())} disabled={Boolean(busy)||distributionBlocked}>{canSeed?"INSTALAR":canRemoteSeed?"BAIXAR E INSTALAR":firstInstall?"COMEÇAR":packUpdatePending?"ATUALIZAR":"PREPARAR"}</button>
          </div>}
          {download?.running&&<DownloadBar progress={download} onPause={()=>download.paused?void resumeDownloads():void pauseDownloads()} onCancel={()=>void cancelDownloads()}/>}          

          <section className="server-rail">
            <button onClick={()=>void refreshLive()}><span className={`server-dot ${server?.online?"online":"offline"}`}/><div><small>Servidor</small><b>{server?.online?"Online":"Offline"}</b></div></button>
            <div><small>Jogadores</small><b>{fmtPlayers(server)}</b></div>
            <div><small>Ping</small><b>{server?.ping_ms!=null?`${server.ping_ms} ms`:"—"}</b></div>
            <div><small>TPS</small><b>{server?.tps!=null?server.tps.toFixed(2):"—"}</b></div>
            <div><small>Modpack</small><b>{state?.pack?.version||startup?.remote_pack_version||"—"}</b></div>
            <button className="rail-detail" onClick={()=>go("pack")}>GERENCIAR <ChevronRight/></button>
          </section>

          <section className="home-simple-grid">
            <div className="panel simple-news">
              <div className="panel-head"><span><Newspaper/>Notícias</span><button onClick={()=>go("news")}>Ver todas <ChevronRight/></button></div>
              <div className="simple-news-list">
                {news.slice(0,3).map(n=><button className="simple-news-row" key={n.id} onClick={()=>n.url?void openExternalUrl(n.url):go("news")}>
                  <span>{new Date(n.published_at).toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit"})}</span>
                  <div><b>{n.title}</b><small>{n.summary}</small></div><ChevronRight/>
                </button>)}
                {!news.length&&<Empty text="As notícias aparecerão aqui quando a API estiver configurada."/>}
              </div>
            </div>

            <div className="panel simple-pack-panel">
              <div className="panel-head"><span><Box/>Eclipse SMP</span><button onClick={()=>go("pack")}>Detalhes <ChevronRight/></button></div>
              <div className="simple-pack-summary">
                <div className="pack-orb"><Box/></div>
                <div><h3>{state?.pack?.name||"Eclipse SMP"}</h3><p>Minecraft {state?.pack?.minecraft||"1.20.1"} • Forge {state?.pack?.forge||"47.4.10"}</p><small>{stats?.mods_count??"—"} mods • {fmtBytes(stats?.installed_bytes||0)} instalados</small></div>
              </div>
              <div className="simple-pack-actions">
                <button className="primary" onClick={()=>void repairNow()} disabled={Boolean(busy)}><RefreshCw/>{busy==="repair"?"REPARANDO…":"SINCRONIZAR / REPARAR"}</button>
                <button onClick={()=>void openInstanceFolder()} aria-label="Abrir pasta"><FolderOpen/></button>
              </div>
              {(publicConfig.discord_url||publicConfig.site_url)&&<div className="micro-links">
                {publicConfig.discord_url&&<button onClick={()=>void openExternalUrl(publicConfig.discord_url)}>Discord</button>}
                {publicConfig.site_url&&<button onClick={()=>void openExternalUrl(publicConfig.site_url)}>Site</button>}
                {publicConfig.rules_url&&<button onClick={()=>void openExternalUrl(publicConfig.rules_url)}>Regras</button>}
              </div>}
            </div>
          </section>
        </>}
        {page==="pack"&&<section className="pack-page">
          <div className="pack-overview panel"><div><span className="eyebrow">ECLIPSE MODPACK</span><h2>{state?.pack?.name||"Eclipse SMP"}</h2><p>{state?.pack?.minecraft} • Forge {state?.pack?.forge} • {state?.pack?.version}</p></div><div className="pack-numbers"><MiniMetric label="Tamanho" value={fmtBytes(stats?.installed_bytes||0)}/><MiniMetric label="Mods" value={String(stats?.mods_count??"—")}/><MiniMetric label="Backups" value={String(backups.length)}/></div></div>
          <div className="pack-columns"><div className="stack"><div className="panel"><div className="panel-head"><span><ShieldCheck/>Integridade e atualização</span><div className="inline-actions"><button onClick={()=>void syncNow()} disabled={Boolean(busy)}>SINCRONIZAR</button><button onClick={()=>void verifyNow()} disabled={Boolean(busy)}>VERIFICAR</button></div></div><div className="integrity-line"><b>{verify?`${Math.round((verify.ok/Math.max(1,verify.checked))*100)}%`:"—"}</b><span>{integrityProblem?`${verify!.missing.length} ausentes • ${verify!.corrupted.length} corrompidos`:verify?"Tudo íntegro":"Ainda não verificado"}</span></div><button className="repair-button" onClick={()=>void repairNow()} disabled={Boolean(busy)}><Wrench/>{busy==="repair"?"REPARANDO…":"REPARAR / ATUALIZAR"}</button>{download?.running&&<DownloadBar progress={download} onPause={()=>download.paused?void resumeDownloads():void pauseDownloads()} onCancel={()=>void cancelDownloads()}/>}</div>
          <div className="panel"><div className="panel-head"><span><Box/>Mods opcionais</span><small>{optionalMods.filter(x=>x.enabled).length}/{optionalMods.length} ativos</small></div>{optionalMods.length?optionalMods.map(m=><button className="optional-row" key={m.id} onClick={()=>void toggleOptional(m)}><span className={m.enabled?"option-check on":"option-check"}>{m.enabled?<CheckCircle2/>:<Square/>}</span><div><b>{m.name}</b><small>{m.description||m.group||fmtBytes(m.size)}</small></div><em>{fmtBytes(m.size)}</em></button>):<Empty text="O manifesto ainda não publicou mods opcionais."/>}</div></div>
          <div className="stack"><div className="panel"><div className="panel-head"><span><Archive/>Backups e rollback</span><button className="small-button" onClick={()=>void backupNow()} disabled={Boolean(busy)}>CRIAR BACKUP</button></div>{backups.slice(0,5).map(b=><div className="backup-row" key={b.id}><div><b>{b.pack_version}</b><small>{formatBackupDate(b.created_at)} • {b.files} arquivos • {fmtBytes(b.bytes)}</small></div><button onClick={()=>void rollback(b.id)}>RESTAURAR</button><button className="icon-danger" onClick={async()=>{await deleteBackup(b.id);setBackups(await listBackups())}}><Trash2/></button></div>)}{!backups.length&&<Empty text="Nenhum backup criado ainda."/>}<button className="text-button" onClick={()=>void openBackupsFolder()}><FolderOpen/>Abrir pasta de backups</button></div>
          <div className="panel"><div className="panel-head"><span><ShieldAlert/>Conflitos</span><button className="small-button" onClick={()=>void scanConflicts().then(setConflicts)}>REESCANEAR</button></div><ConflictList c={conflicts}/></div></div></div>
        </section>}

        {page==="news"&&<section className="news-page"><div className="news-list">{news.map(n=><article className="panel news-card" key={n.id}><span className="news-category">{n.category}</span><h2>{n.title}</h2><p>{n.summary}</p><small>{new Date(n.published_at).toLocaleString("pt-BR")}</small>{n.pinned&&<b className="pinned">FIXADO</b>}</article>)}{!news.length&&<div className="panel"><Empty text="Sem notícias no cache/API."/></div>}</div><div className="panel event-list"><div className="panel-head"><span><CalendarDays/>Eventos</span></div>{events.map(e=><div className="event-row" key={e.id}><b>{e.title}</b><p>{e.summary}</p><small>{new Date(e.starts_at).toLocaleString("pt-BR")}</small></div>)}</div></section>}

        {page==="diagnostics"&&<section className="diagnostics-page"><div className="panel"><div className="panel-head"><span><Activity/>Diagnóstico do launcher</span><button className="small-button" onClick={()=>void refreshDiagnostics()}>ATUALIZAR</button></div><Ready label="Manifesto" ok={state?.readiness.manifest}/><Ready label="Java gerenciado" ok={state?.readiness.minecraft_runtime}/><Ready label="Forge" ok={state?.readiness.forge}/><Ready label="Perfil oficial" ok={state?.readiness.official_profile}/><Ready label="Direct / Offline runtime" ok={state?.readiness.direct_files}/><Ready label="Microsoft Direct" ok={state?.readiness.microsoft_auth}/><div className="diagnostic-buttons"><button onClick={()=>void openLogsFolder()}><TerminalSquare/>Logs</button><button onClick={()=>void openInstanceFolder()}><FolderOpen/>Instância</button><button onClick={()=>void support()}><Download/>Pacote de suporte</button></div></div><div className="diagnostic-stack"><div className="panel"><span className="eyebrow">CRASH ANALYZER</span><h3>{crash?.found?"Crash recente encontrado":"Nenhum crash recente"}</h3><p className="muted">{crash?.summary||"Use Atualizar para analisar latest.log e crash-reports."}</p>{crash?.probable_mods?.slice(0,5).map(x=><code className="chip" key={x}>{x}</code>)}<button className="wide-button" onClick={()=>void analyzeCrash().then(setCrash)}>ANALISAR NOVAMENTE</button></div><div className="panel"><span className="eyebrow">CHECKLIST DE RELEASE</span><h3>{release?.send_ready?"Pronto para enviar":"Ainda faltam itens críticos"}</h3><Ready label="Bootstrap / canais HTTPS" ok={release?.distribution_ready}/><Ready label="Updater assinado" ok={release?.signed_updates_ready}/><Ready label="Links públicos principais" ok={release?.public_links_ready}/><Ready label="Microsoft Direct" ok={release?.microsoft_direct_ready}/>{release?.blockers?.length?<div className="release-blockers">{release.blockers.map(x=><code key={x}>{x}</code>)}</div>:null}{release?.warnings?.length?<p className="muted">Avisos: {release.warnings.join(" • ")}</p>:null}</div><div className="panel"><span className="eyebrow">SISTEMA</span><InfoRow k="Launcher" v={state?.app_version||"—"}/><InfoRow k="Sistema" v={diagnostic?`${diagnostic.os}/${diagnostic.arch}`:"Windows"}/><InfoRow k="RAM total" v={system?`${Math.round(system.total_ram_mb/1024)} GB`:"—"}/><InfoRow k="RAM recomendada" v={system?`${Math.round(system.recommended_ram_mb/1024)} GB`:"—"}/><InfoRow k="Disco livre" v={fmtBytes(system?.free_instance_disk_bytes||0)}/></div></div></section>}

        {page==="settings"&&<section className="settings-page"><div className="settings-tabs">{([['game','Jogo'],['launcher','Launcher'],['audio','Áudio'],['updates','Atualizações'],['advanced','Avançado']] as const).map(([id,label])=><button className={settingsTab===id?"active":""} onClick={()=>setSettingsTab(id)} key={id}>{label}</button>)}</div>
          <div className="panel settings-panel">
            {settingsTab==="game"&&<><SectionTitle icon={<Play/>} title="Inicialização" sub="Escolha como o Minecraft será aberto."/><ModeCard active={settings.launch_mode==="official"} title="Minecraft Launcher" sub="O Eclipse prepara tudo; a Microsoft continua somente no launcher oficial." onClick={()=>patch({launch_mode:"official"})}/><ModeCard active={settings.launch_mode==="direct"} title="Eclipse Direct" sub={profile.connected?`Microsoft conectada: ${profile.minecraft_name}`:"OAuth Microsoft com PKCE + refresh token protegido pelo Windows."} onClick={()=>patch({launch_mode:"direct"})}/>{settings.launch_mode==="direct"&&<div className="auth-actions">{profile.connected?<button onClick={()=>void disconnectMicrosoft()}><LogOut/>DESCONECTAR MICROSOFT</button>:<button onClick={()=>void connectMicrosoft()} disabled={busy==="auth"}><LogIn/>{busy==="auth"?"AGUARDANDO LOGIN…":"CONECTAR MICROSOFT"}</button>}</div>}<ModeCard active={settings.launch_mode==="offline"} title="Perfil Offline" sub="Sem Microsoft e sem Minecraft Launcher depois que os arquivos forem preparados." onClick={()=>patch({launch_mode:"offline"})}/>{settings.launch_mode==="offline"&&<Field label="NOME OFFLINE"><input maxLength={16} value={settings.offline_name} onChange={e=>patch({offline_name:e.target.value.replace(/[^A-Za-z0-9_]/g,"")})}/></Field>}<SectionTitle icon={<Cpu/>} title="Performance" sub="Recomendação baseada no PC, com ajuste manual."/><div className="ram-row"><input type="range" min="2048" max="32768" step="1024" value={settings.ram_mb} onChange={e=>patch({ram_mb:Number(e.target.value)})}/><b>{Math.round(settings.ram_mb/1024)} GB</b><button onClick={applyRecommendedRam}>AUTO {system?`${Math.round(system.recommended_ram_mb/1024)} GB`:""}</button></div></>}
            {settingsTab==="launcher"&&<><SectionTitle icon={<Settings/>} title="Comportamento" sub="O que o Eclipse faz antes e depois de abrir o jogo."/><Toggle title="Verificar pack ao abrir" sub="Checa silenciosamente a integridade no início." value={settings.auto_verify_on_start} onClick={()=>patch({auto_verify_on_start:!settings.auto_verify_on_start})}/><Toggle title="Reparar antes de jogar" sub="Impede o launch se ainda houver arquivos quebrados." value={settings.auto_repair_before_launch} onClick={()=>patch({auto_repair_before_launch:!settings.auto_repair_before_launch})}/><Toggle title="Minimizar após abrir" sub="Mantém o launcher aberto em segundo plano." value={settings.minimize_on_launch} onClick={()=>patch({minimize_on_launch:!settings.minimize_on_launch,close_after_launch:false})}/><Toggle title="Fechar após abrir" sub="Fecha o Eclipse quando o Minecraft iniciar." value={settings.close_after_launch} onClick={()=>patch({close_after_launch:!settings.close_after_launch,minimize_on_launch:false})}/><Field label="CANAL"><select value={settings.channel} onChange={e=>patch({channel:e.target.value})}><option value="stable">Stable</option><option value="beta">Beta</option><option value="staff">Staff</option></select></Field></>}
            {settingsTab==="audio"&&<><SectionTitle icon={<Headphones/>} title="Áudio e movimento" sub="Tudo opcional e discreto."/><Toggle title="Sons da interface" sub="Hover, clique, sucesso e erro em volumes baixos." value={ambient.uiSounds} onClick={()=>setAmbient(a=>({...a,uiSounds:!a.uiSounds}))}/><Toggle title="Música ambiente" sub="Desativada por padrão." value={ambient.music} onClick={toggleMusic}/><Toggle title="Animações" sub="Microinterações, nuvens e transições." value={ambient.animations} onClick={()=>setAmbient(a=>({...a,animations:!a.animations}))}/><Field label={`VOLUME DA MÚSICA • ${ambient.musicVolume}%`}><input type="range" min="0" max="100" value={ambient.musicVolume} onChange={e=>setAmbient(a=>({...a,musicVolume:Number(e.target.value)}))}/></Field><Field label={`VOLUME DA UI • ${ambient.uiVolume}%`}><input type="range" min="0" max="100" value={ambient.uiVolume} onChange={e=>setAmbient(a=>({...a,uiVolume:Number(e.target.value)}))}/></Field><Field label="MOVIMENTO"><select value={ambient.motion} onChange={e=>setAmbient(a=>({...a,motion:e.target.value as Ambient["motion"]}))}><option value="reduced">Reduzido</option><option value="normal">Normal</option><option value="cinematic">Cinemático</option></select></Field></>}
            {settingsTab==="updates"&&<><SectionTitle icon={<CloudDownload/>} title="Atualizações" sub="Downloads retomáveis, espelhos e rollback."/><Toggle title="Atualizar modpack automaticamente" sub="Ao abrir o launcher, baixa somente os arquivos que mudaram no canal selecionado." value={settings.auto_update_pack} onClick={()=>patch({auto_update_pack:!settings.auto_update_pack})}/><Toggle title="Verificar depois de atualizar" sub="Confirma SHA-256 antes de liberar o botão Jogar." value={settings.verify_after_update} onClick={()=>patch({verify_after_update:!settings.verify_after_update})}/><Toggle title="Auto-update do launcher" sub="Só instala builds com assinatura Ed25519 + SHA-256 válidos." value={settings.auto_update_launcher} onClick={()=>patch({auto_update_launcher:!settings.auto_update_launcher})}/><Toggle title="Backup antes de atualizar pack" sub="Cria snapshot para rollback antes de substituir arquivos." value={settings.auto_backup_before_update} onClick={()=>patch({auto_backup_before_update:!settings.auto_backup_before_update})}/><Toggle title="Economizar dados" sub="Prioriza retomar .part e evita tarefas de rede não essenciais." value={settings.reduce_data_usage} onClick={()=>patch({reduce_data_usage:!settings.reduce_data_usage})}/><Field label={`DOWNLOADS PARALELOS • ${settings.max_parallel_downloads}`}><input type="range" min="1" max="12" value={settings.max_parallel_downloads} onChange={e=>patch({max_parallel_downloads:Number(e.target.value)})}/></Field><Field label={`BACKUPS MANTIDOS • ${settings.backup_limit}`}><input type="range" min="1" max="12" value={settings.backup_limit} onChange={e=>patch({backup_limit:Number(e.target.value)})}/></Field></>}
            {settingsTab==="advanced"&&<><SectionTitle icon={<Zap/>} title="Avançado" sub="Configuração local e diagnóstico. URLs públicas vêm da build de release."/><div className="release-config-box"><InfoRow k="Bootstrap da build" v={publicConfig.bootstrap_url||"NÃO CONFIGURADO"}/><InfoRow k="Canal atual" v={settings.channel.toUpperCase()}/><InfoRow k="Stable" v={settings.stable_manifest_url||"Descoberto pelo bootstrap"}/></div><Field label="MANIFESTO CUSTOMIZADO (DEV)"><input value={settings.manifest_url} onChange={e=>patch({manifest_url:e.target.value})} placeholder="Deixe vazio em builds públicas"/></Field><Field label="MINECRAFT LAUNCHER"><input value={settings.official_launcher_path||""} onChange={e=>patch({official_launcher_path:e.target.value||null})} placeholder="Detectado automaticamente"/></Field><div className="advanced-actions"><button onClick={()=>void bootstrap()}><Wrench/>Preparar tudo</button><button onClick={()=>void clearCache().then(r=>notify(`${fmtBytes(r.bytes_removed)} removidos do cache.`,"success"))}><Trash2/>Limpar cache</button><button onClick={()=>void openCacheFolder()}><FolderOpen/>Abrir cache</button></div></>}
          </div>
          <div className="settings-save"><div><span className={dirty?"unsaved":"saved"}/><b>{dirty?"Alterações não salvas":"Tudo salvo"}</b></div><div><button onClick={()=>void restoreDefaults()}><RotateCcw/>Restaurar</button><button className="primary" onClick={()=>void saveAll()} disabled={!dirty}><ShieldCheck/>Salvar</button></div></div>
        </section>}
      </div>
    </main>
    {toast&&<button className={`toast ${toast.kind}`} onClick={()=>setToast(null)}><span/>{toast.text}</button>}
  </div>
}

function ReadyChip({icon,label,value,ok,onClick}:{icon:ReactNode,label:string,value:string,ok?:boolean,onClick:()=>void}){return <button className={`ready-chip ${ok?"ok":"bad"}`} onClick={onClick}><span>{icon}</span><span><small>{label}</small><b>{value}</b></span></button>}

function Stat({icon,label,value,sub,accent,onClick}:{icon:ReactNode,label:string,value:string,sub:string,accent:"green"|"blue"|"amber",onClick:()=>void}){return <button className={`stat accent-${accent}`} onClick={onClick}><span className="stat-icon">{icon}</span><span><small>{label}</small><b>{value}</b><em>{sub}</em></span><ChevronRight/></button>}
function Time({v,l}:{v:string,l:string}){return <div className="time"><b>{v}</b><small>{l}</small></div>}
function MiniMetric({label,value}:{label:string,value:string}){return <div className="mini-metric"><small>{label}</small><b>{value}</b></div>}
function Empty({text}:{text:string}){return <div className="empty"><Info/><span>{text}</span></div>}
function ConflictList({c}:{c:ConflictReport}){const total=c.extra_mods.length+c.duplicate_mods.length+c.missing_managed.length+c.corrupted_managed.length;if(!total)return <div className="safe-box"><CheckCircle2/>Nenhum conflito detectado.</div>;return <div className="conflict-list">{c.extra_mods.slice(0,4).map(x=><code key={x}>Extra: {x}</code>)}{c.duplicate_mods.slice(0,3).map(x=><code key={x}>Duplicado: {x}</code>)}{c.missing_managed.slice(0,3).map(x=><code key={x}>Ausente: {x}</code>)}{c.corrupted_managed.slice(0,3).map(x=><code key={x}>Corrompido: {x}</code>)}</div>}
function Ready({label,ok}:{label:string,ok?:boolean}){return <div className="ready-row"><span className={ok?"ok":"bad"}>{ok?<CheckCircle2/>:<XCircle/>}</span><b>{label}</b><small>{ok?"Pronto":"Pendente"}</small></div>}
function InfoRow({k,v}:{k:string,v:string}){return <div className="info-row"><span>{k}</span><b>{v}</b></div>}
function SectionTitle({icon,title,sub}:{icon:ReactNode,title:string,sub:string}){return <div className="section-title"><span>{icon}</span><div><h3>{title}</h3><p>{sub}</p></div></div>}
function ModeCard({active,title,sub,onClick}:{active:boolean,title:string,sub:string,onClick:()=>void}){return <button className={`mode-card ${active?"active":""}`} onClick={onClick}><i/><div><b>{title}</b><small>{sub}</small></div></button>}
function Toggle({title,sub,value,onClick}:{title:string,sub:string,value:boolean,onClick:()=>void}){return <button className="toggle-row" onClick={onClick}><span><b>{title}</b><small>{sub}</small></span><i className={value?"switch on":"switch"}><b/></i></button>}
function Field({label,children}:{label:string,children:ReactNode}){return <label className="field"><span>{label}</span>{children}</label>}
function DownloadBar({progress,onPause,onCancel}:{progress:DownloadProgress,onPause:()=>void,onCancel:()=>void}){const pct=progress.bytes_total?Math.min(100,Math.round(progress.bytes_done/progress.bytes_total*100)):0;return <div className="download-box"><div><b>{progress.message}</b><small>{progress.current_file||`${progress.files_done}/${progress.files_total} arquivos`}</small></div><div className="download-track"><span style={{width:`${pct}%`}}/></div><em>{pct}%</em><button onClick={onPause}>{progress.paused?<Play/>:<Pause/>}</button><button onClick={onCancel}><XCircle/></button></div>}
