import { invoke } from "@tauri-apps/api/core";
import { getCurrentWindow } from "@tauri-apps/api/window";

export type LaunchMode="official"|"direct"|"offline";
export interface LauncherSettings{launch_mode:LaunchMode;offline_name:string;ram_mb:number;channel:string;manifest_url:string;stable_manifest_url:string;beta_manifest_url:string;staff_manifest_url:string;official_launcher_path?:string|null;auto_verify_on_start:boolean;auto_repair_before_launch:boolean;auto_update_launcher:boolean;auto_backup_before_update:boolean;backup_limit:number;minimize_on_launch:boolean;close_after_launch:boolean;max_parallel_downloads:number;optional_enabled:string[];reduce_data_usage:boolean;auto_update_pack:boolean;verify_after_update:boolean;bootstrap_url:string;}
export interface PackInfo{name:string;version:string;minecraft:string;forge:string;}
export interface Readiness{manifest:boolean;minecraft_runtime:boolean;forge:boolean;official_launcher:boolean;official_profile:boolean;direct_files:boolean;microsoft_auth:boolean;}
export interface LauncherState{app_version:string;instance_dir:string;cache_dir:string;logs_dir:string;backups_dir:string;settings:LauncherSettings;offline_uuid?:string|null;readiness:Readiness;pack?:PackInfo|null;}
export interface VerifyReport{checked:number;ok:number;missing:string[];corrupted:string[];ignored:string[];}
export interface RepairReport{repaired:number;removed_stale:number;bytes_downloaded:number;resumed_bytes:number;backup_id?:string|null;}
export interface CacheReport{files_removed:number;bytes_removed:number;}
export interface ServerStatus{online:boolean;players_online?:number|null;players_max?:number|null;ping_ms?:number|null;tps?:number|null;message?:string|null;maintenance:boolean;maintenance_message?:string|null;min_launcher_version?:string|null;required_pack_version?:string|null;}
export interface ConflictReport{extra_mods:string[];duplicate_mods:string[];missing_managed:string[];corrupted_managed:string[];}
export interface CrashAnalysis{found:boolean;source:string;summary:string;probable_mods:string[];probable_causes:string[];suggested_action:string;}
export interface DiagnosticReport{app_version:string;os:string;arch:string;instance_dir:string;cache_dir:string;logs_dir:string;launch_mode:string;channel:string;ram_mb:number;readiness:Readiness;pack?:PackInfo|null;conflicts:ConflictReport;crash?:CrashAnalysis|null;}
export interface NewsItem{id:string;title:string;summary:string;category:string;published_at:string;url?:string|null;image_url?:string|null;pinned:boolean;}
export interface EventItem{id:string;title:string;summary:string;starts_at:string;ends_at?:string|null;image_url?:string|null;enabled:boolean;}
export interface RuntimeInstallReport{installed:boolean;java_major:number;path:string;bytes_downloaded:number;}
export interface ForgeInstallReport{installed:boolean;forge_version:string;version_id:string;profile_files_updated:number;installer_bytes:number;direct_files_prepared:boolean;}
export interface BootstrapReport{runtime:RuntimeInstallReport;forge:ForgeInstallReport;}
export interface LauncherUpdateInfo{version:string;notes:string;url:string;sha256:string;signature:string;mandatory:boolean;installer_type:string;}
export interface OptionalModInfo{id:string;name:string;description:string;group:string;enabled:boolean;size:number;conflicts:string[];}
export interface BackupInfo{id:string;created_at:string;pack_version:string;files:number;bytes:number;}
export interface PackStats{installed_bytes:number;managed_files:number;optional_files:number;mods_count:number;backups:number;}
export interface SystemProfile{total_ram_mb:number;cpu_threads:number;recommended_ram_mb:number;free_instance_disk_bytes:number;}
export interface DownloadProgress{running:boolean;paused:boolean;cancelled:boolean;current_file:string;files_total:number;files_done:number;bytes_total:number;bytes_done:number;message:string;}
export interface UpdateEstimate{files:number;bytes:number;resumed_bytes:number;stale_files:number;first_install:boolean;}
export interface StartupReport{first_install:boolean;channel:string;previous_pack_version?:string|null;remote_pack_version:string;estimate:UpdateEstimate;manifest_synced:boolean;maintenance:boolean;maintenance_message?:string|null;launcher_update?:LauncherUpdateInfo|null;}
export interface ProvisionReport{first_install:boolean;pack_version:string;repair:RepairReport;bootstrap:BootstrapReport;final_verify:VerifyReport;}
export interface SupportBundleReport{path:string;files:number;bytes:number;}
export interface MicrosoftProfile{connected:boolean;minecraft_name:string;minecraft_uuid:string;}
export interface PublicConfig{site_url:string;discord_url:string;rules_url:string;wiki_url:string;support_url:string;bootstrap_url:string;seed_url:string;seed_sha256:string;}
export interface ReleaseReadiness{distribution_ready:boolean;signed_updates_ready:boolean;microsoft_direct_ready:boolean;public_links_ready:boolean;send_ready:boolean;blockers:string[];warnings:string[];}
export interface SeedPackStatus{available:boolean;path?:string|null;size:number;pack_version?:string|null;}
export interface SeedInstallReport{installed_files:number;bytes_installed:number;pack_version:string;seed_path:string;}

const previewSettings:LauncherSettings={launch_mode:"official",offline_name:"Player",ram_mb:8192,channel:"stable",manifest_url:"",stable_manifest_url:"",beta_manifest_url:"",staff_manifest_url:"",official_launcher_path:null,auto_verify_on_start:true,auto_repair_before_launch:false,auto_update_launcher:true,auto_backup_before_update:true,backup_limit:5,minimize_on_launch:true,close_after_launch:false,max_parallel_downloads:4,optional_enabled:[],reduce_data_usage:false,auto_update_pack:true,verify_after_update:true,bootstrap_url:""};
const isTauri=()=>Boolean((window as any).__TAURI_INTERNALS__);
const readiness:Readiness={manifest:true,minecraft_runtime:true,forge:true,official_launcher:true,official_profile:true,direct_files:true,microsoft_auth:false};
export async function getState():Promise<LauncherState>{if(!isTauri())return{app_version:"1.0.0-alpha.13 (preview)",instance_dir:"C:\\Users\\Player\\.eclipse-launcher\\instances\\eclipse-smp",cache_dir:"C:\\Users\\Player\\.eclipse-launcher\\cache",logs_dir:"C:\\Users\\Player\\.eclipse-launcher\\logs",backups_dir:"C:\\Users\\Player\\.eclipse-launcher\\backups",settings:previewSettings,offline_uuid:null,readiness,pack:{name:"Eclipse SMP",version:"1.0.0",minecraft:"1.20.1",forge:"47.4.10"}};return invoke("get_launcher_state");}
export async function saveSettings(settings:LauncherSettings){if(!isTauri())return;return invoke("save_settings",{settings});}
export async function resetSettings():Promise<LauncherSettings>{if(!isTauri())return{...previewSettings};return invoke("reset_settings");}
export async function verifyPack():Promise<VerifyReport>{if(!isTauri())return{checked:292,ok:292,missing:[],corrupted:[],ignored:[]};return invoke("verify_pack");}
export async function repairPack():Promise<RepairReport>{if(!isTauri())return{repaired:3,removed_stale:1,bytes_downloaded:58_000_000,resumed_bytes:12_000_000,backup_id:"1726430000"};return invoke("repair_pack");}
export async function getRepairProgress():Promise<DownloadProgress>{if(!isTauri())return{running:false,paused:false,cancelled:false,current_file:"",files_total:0,files_done:0,bytes_total:0,bytes_done:0,message:"Pronto"};return invoke("repair_progress");}
export async function pauseDownloads(){if(isTauri())return invoke("pause_downloads");}
export async function resumeDownloads(){if(isTauri())return invoke("resume_downloads");}
export async function cancelDownloads(){if(isTauri())return invoke("cancel_downloads");}
export async function refreshDistribution():Promise<LauncherSettings>{if(!isTauri())return{...previewSettings};return invoke("refresh_distribution");}
export async function startupCheck():Promise<StartupReport>{if(!isTauri())return{first_install:false,channel:"stable",previous_pack_version:"1.0.0",remote_pack_version:"1.0.1",estimate:{files:3,bytes:131_000_000,resumed_bytes:12_000_000,stale_files:1,first_install:false},manifest_synced:true,maintenance:false,launcher_update:null};return invoke("startup_check");}
export async function estimatePackUpdate():Promise<UpdateEstimate>{if(!isTauri())return{files:3,bytes:131_000_000,resumed_bytes:12_000_000,stale_files:1,first_install:false};return invoke("estimate_pack_update");}
export async function provisionInstallation():Promise<ProvisionReport>{if(!isTauri())return{first_install:false,pack_version:"1.0.1",repair:{repaired:3,removed_stale:1,bytes_downloaded:119_000_000,resumed_bytes:12_000_000,backup_id:"preview"},bootstrap:await bootstrapMinecraft(),final_verify:{checked:292,ok:292,missing:[],corrupted:[],ignored:[]}};return invoke("provision_installation");}
export async function syncManifest(url?:string|null){if(!isTauri())return{pack:{name:"Eclipse SMP",version:"1.0.0",minecraft:"1.20.1",forge:"47.4.10"}};return invoke("sync_manifest",{url:url??null});}
export async function getServerStatus():Promise<ServerStatus>{if(!isTauri())return{online:false,maintenance:false,message:"Preview sem API configurada"};return invoke("server_status");}
export async function getNews():Promise<NewsItem[]>{if(!isTauri())return[{id:"a7",title:"Alpha 7: Production Pass",summary:"Rollback, Direct OAuth, downloads retomáveis e diagnóstico de crash entram na mesma base.",category:"LAUNCHER",published_at:"2026-09-15T19:00:00-03:00",pinned:true},{id:"event",title:"O próximo ciclo se aproxima",summary:"Notícias e eventos continuam disponíveis mesmo se a API cair, usando cache local.",category:"EVENTO",published_at:"2026-09-15T17:00:00-03:00",pinned:false}];return invoke("fetch_news");}
export async function getEvents():Promise<EventItem[]>{if(!isTauri())return[{id:"winter",title:"Eclipse de Inverno",summary:"Um novo ciclo se aproxima.",starts_at:new Date(Date.now()+((5*24+14)*60*60+27*60+32)*1000).toISOString(),enabled:true}];return invoke("fetch_events");}
export async function bootstrapMinecraft():Promise<BootstrapReport>{if(!isTauri())return{runtime:{installed:true,java_major:17,path:"C:\\...\\java.exe",bytes_downloaded:45_000_000},forge:{installed:true,forge_version:"47.4.10",version_id:"1.20.1-forge-47.4.10",profile_files_updated:1,installer_bytes:8_000_000,direct_files_prepared:true}};return invoke("bootstrap_minecraft");}
export async function installManagedJava():Promise<RuntimeInstallReport>{if(!isTauri())return(await bootstrapMinecraft()).runtime;return invoke("install_managed_java");}
export async function installForge():Promise<ForgeInstallReport>{if(!isTauri())return(await bootstrapMinecraft()).forge;return invoke("install_forge");}
export async function repairOfficialProfile():Promise<ForgeInstallReport>{if(!isTauri())return{installed:false,forge_version:"47.4.10",version_id:"1.20.1-forge-47.4.10",profile_files_updated:1,installer_bytes:0,direct_files_prepared:true};return invoke("repair_official_profile");}
export async function microsoftLogin():Promise<MicrosoftProfile>{if(!isTauri())return{connected:true,minecraft_name:"Jogador",minecraft_uuid:"preview"};return invoke("microsoft_login");}
export async function microsoftLogout(){if(isTauri())return invoke("microsoft_logout");}
export async function microsoftState():Promise<MicrosoftProfile>{if(!isTauri())return{connected:false,minecraft_name:"",minecraft_uuid:""};return invoke("microsoft_state");}
export async function getOptionalMods():Promise<OptionalModInfo[]>{if(!isTauri())return[{id:"shaders",name:"Shaders opcionais",description:"Recursos visuais extras para PCs mais fortes.",group:"Visual",enabled:false,size:34_000_000,conflicts:[]}];return invoke("list_optional_mods");}
export async function setOptionalMod(id:string,enabled:boolean):Promise<LauncherSettings>{if(!isTauri())return{...previewSettings,optional_enabled:enabled?[id]:[]};return invoke("set_optional_mod",{id,enabled});}
export async function getPackStats():Promise<PackStats>{if(!isTauri())return{installed_bytes:8_700_000_000,managed_files:331,optional_files:4,mods_count:292,backups:3};return invoke("pack_stats");}
export async function scanConflicts():Promise<ConflictReport>{if(!isTauri())return{extra_mods:[],duplicate_mods:[],missing_managed:[],corrupted_managed:[]};return invoke("scan_conflicts");}
export async function getSystemProfile():Promise<SystemProfile>{if(!isTauri())return{total_ram_mb:16384,cpu_threads:12,recommended_ram_mb:6144,free_instance_disk_bytes:120_000_000_000};return invoke("system_profile");}
export async function createBackup():Promise<BackupInfo>{if(!isTauri())return{id:"1726430000",created_at:"1726430000",pack_version:"1.0.0",files:292,bytes:4_200_000_000};return invoke("create_backup");}
export async function listBackups():Promise<BackupInfo[]>{if(!isTauri())return[{id:"1726430000",created_at:"1726430000",pack_version:"1.0.0",files:292,bytes:4_200_000_000}];return invoke("list_backups");}
export async function rollbackBackup(id:string):Promise<number>{if(!isTauri())return 292;return invoke("rollback_backup",{id});}
export async function deleteBackup(id:string){if(isTauri())return invoke("delete_backup",{id});}
export async function analyzeCrash():Promise<CrashAnalysis>{if(!isTauri())return{found:false,source:"",summary:"Nenhum crash recente.",probable_mods:[],probable_causes:[],suggested_action:"Nada a fazer."};return invoke("analyze_crash");}
export async function createSupportBundle():Promise<SupportBundleReport>{if(!isTauri())return{path:"C:\\...\\Eclipse-Support.zip",files:4,bytes:140_000};return invoke("create_support_bundle");}
export async function checkLauncherUpdate():Promise<LauncherUpdateInfo|null>{if(!isTauri())return null;return invoke("check_launcher_update");}
export async function installLauncherUpdate(){if(isTauri())return invoke("install_launcher_update");}
export async function clearCache():Promise<CacheReport>{if(!isTauri())return{files_removed:31,bytes_removed:142_000_000};return invoke("clear_cache");}
export async function openInstanceFolder(){if(isTauri())return invoke("open_instance_folder");}
export async function openLogsFolder(){if(isTauri())return invoke("open_logs_folder");}
export async function openCacheFolder(){if(isTauri())return invoke("open_cache_folder");}
export async function openBackupsFolder(){if(isTauri())return invoke("open_backups_folder");}
export async function openSupportFolder(){if(isTauri())return invoke("open_support_folder");}
export async function openExternalUrl(url:string){if(isTauri())return invoke("open_external_url",{url});window.open(url,"_blank","noopener");}
export async function getSeedPackStatus():Promise<SeedPackStatus>{if(!isTauri())return{available:false,path:null,size:0,pack_version:null};return invoke("seed_pack_status");}
export async function downloadSeedPack():Promise<SeedPackStatus>{if(!isTauri())return{available:true,path:"C:\\...\\EclipseSMP-Seed.zip",size:8_700_000_000,pack_version:"1.0.0"};return invoke("download_seed_pack");}
export async function installSeedPack(path?:string|null):Promise<SeedInstallReport>{if(!isTauri())return{installed_files:292,bytes_installed:8_700_000_000,pack_version:"1.0.0",seed_path:"EclipseSMP-Seed.zip"};return invoke("install_seed_pack",{path:path??null});}
export async function getPublicConfig():Promise<PublicConfig>{if(!isTauri())return{site_url:"",discord_url:"",rules_url:"",wiki_url:"",support_url:"",bootstrap_url:"",seed_url:"",seed_sha256:""};return invoke("public_config");}
export async function getReleaseReadiness():Promise<ReleaseReadiness>{if(!isTauri())return{distribution_ready:false,signed_updates_ready:false,microsoft_direct_ready:false,public_links_ready:false,send_ready:false,blockers:["ECLIPSE_BOOTSTRAP_URL (HTTPS)","ECLIPSE_UPDATE_PUBLIC_KEY_B64"],warnings:["Configure os links públicos antes da build final"]};return invoke("release_readiness");}
export async function getDiagnostics():Promise<DiagnosticReport>{if(!isTauri()){const s=await getState();return{app_version:s.app_version,os:"windows",arch:"x86_64",instance_dir:s.instance_dir,cache_dir:s.cache_dir,logs_dir:s.logs_dir,launch_mode:s.settings.launch_mode,channel:s.settings.channel,ram_mb:s.settings.ram_mb,readiness:s.readiness,pack:s.pack,conflicts:{extra_mods:[],duplicate_mods:[],missing_managed:[],corrupted_managed:[]},crash:null};}return invoke("diagnostics");}
export async function launchGame(){if(!isTauri())return"Preview: Minecraft iniciado.";return invoke<string>("launch_game");}
export async function applyPostLaunchBehavior(settings:LauncherSettings){if(!isTauri())return;const win=getCurrentWindow();if(settings.close_after_launch)await win.close();else if(settings.minimize_on_launch)await win.minimize();}
