@echo off
setlocal
if "%~1"=="" (
  echo Arraste a pasta COMPLETA da instancia Eclipse SMP sobre este arquivo.
  pause
  exit /b 1
)
set /p BASE=URL publica HTTPS da CDN (ex: https://cdn.seudominio.com/eclipse): 
set /p VERSION=Versao do pack [1.0.0]: 
if "%VERSION%"=="" set VERSION=1.0.0
set /p SERVER=Endereco do servidor (IP:porta ou dominio): 
python "%~dp0prepare_distribution.py" "%~1" --output "%~dp0..\distribution" --public-base "%BASE%" --version "%VERSION%" --forge "47.4.10" --server "%SERVER%"
if errorlevel 1 (
  echo.
  echo ERRO ao preparar distribuicao.
) else (
  echo.
  echo PRONTO. Agora envie a pasta distribution para a hospedagem.
)
pause
