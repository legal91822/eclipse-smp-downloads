@echo off
if "%~1"=="" (
  echo Arraste a pasta completa do modpack em cima deste .bat
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PREPARAR_PACK_PARA_PLAYERS.ps1" -Source "%~1" -Output "%~dp0..\release\EclipseSMP-Seed.zip"
pause
