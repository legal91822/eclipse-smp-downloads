param(
  [Parameter(Mandatory=$true)][string]$Source,
  [string]$Output = ".\EclipseSMP-Seed.zip",
  [string]$PackVersion = "1.0.0",
  [string]$Minecraft = "1.20.1",
  [string]$Forge = "47.4.10",
  [string]$ServerAddress = ""
)
$ErrorActionPreference = "Stop"
$src = (Resolve-Path $Source).Path
$out = [IO.Path]::GetFullPath($Output)
$temp = Join-Path $env:TEMP ("eclipse-seed-" + [guid]::NewGuid().ToString("N"))
$pack = Join-Path $temp "pack"
New-Item -ItemType Directory -Force -Path $pack | Out-Null

$excludeDirs = @('logs','screenshots','saves','crash-reports','.git','.idea','.vscode','backups')
$files = Get-ChildItem -LiteralPath $src -Recurse -File | Where-Object {
  $relative = $_.FullName.Substring($src.Length).TrimStart('\\','/')
  -not ($excludeDirs | Where-Object { $relative -eq $_ -or $relative.StartsWith($_ + '\\') -or $relative.StartsWith($_ + '/') })
}
if(-not $files){ throw "Nenhum arquivo encontrado em $src" }

$manifestFiles = @()
$total = 0L
$i = 0
foreach($f in $files){
  $i++
  $rel = $f.FullName.Substring($src.Length).TrimStart('\\','/').Replace('\\','/')
  $dest = Join-Path $pack $rel
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
  $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $f.FullName).Hash.ToLowerInvariant()
  $mode = if($rel -match '^(options\.txt|servers\.dat|journeymap/|xaero|config/client|shaderpacks/)'){ 'preserve' } else { 'managed' }
  $manifestFiles += [ordered]@{
    id=''; path=$rel; sha256=$hash; size=[int64]$f.Length; mode=$mode; url=$null; mirrors=@();
    display_name=$f.BaseName; description=''; group='core'; conflicts=@(); enabled_by_default=$true
  }
  $total += $f.Length
  if(($i % 50) -eq 0){ Write-Host "Hash: $i / $($files.Count)" }
}

$manifest = [ordered]@{
  schema_version = 2
  pack = [ordered]@{ name='Eclipse SMP'; version=$PackVersion; minecraft=$Minecraft; forge=$Forge }
  endpoints = [ordered]@{ status=$null; news=$null; events=$null; launcher_update=$null; file_base=$null; file_bases=@() }
  launch = [ordered]@{ server_address= $(if($ServerAddress){$ServerAddress}else{$null}); java_major=17; min_ram_mb=4096; recommended_ram_mb=8192; min_launcher_version='1.0.0-alpha.13' }
  auth = [ordered]@{ client_id=''; authorize_url='https://login.live.com/oauth20_authorize.srf'; token_url='https://login.live.com/oauth20_token.srf'; scope='XboxLive.signin offline_access' }
  files = $manifestFiles
}
$manifestPath = Join-Path $temp 'manifest.json'
$manifest | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
if(Test-Path $out){ Remove-Item $out -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [IO.Compression.ZipFile]::Open($out,[IO.Compression.ZipArchiveMode]::Create)
try {
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$manifestPath,'manifest.json',[IO.Compression.CompressionLevel]::Fastest) | Out-Null
  foreach($f in Get-ChildItem -LiteralPath $pack -Recurse -File){
    $rel = $f.FullName.Substring($pack.Length).TrimStart('\\','/').Replace('\\','/')
    [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,('pack/'+$rel),[IO.Compression.CompressionLevel]::Fastest) | Out-Null
  }
} finally { $zip.Dispose(); Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue }
Write-Host ""
Write-Host "PRONTO: $out" -ForegroundColor Green
Write-Host "Arquivos: $($files.Count) | Tamanho original: $([math]::Round($total/1GB,2)) GB | Forge: $Forge"
Write-Host "Coloque EclipseSMP-Seed.zip ao lado do Eclipse Launcher ou na pasta Downloads do player."
