@echo off
if "%~1"=="" goto :usage
if "%~2"=="" goto :usage
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RELEASE_PLAYERS_TODAY.ps1" -ModpackFolder "%~1" -LauncherExe "%~2"
pause
exit /b %ERRORLEVEL%
:usage
echo Uso:
echo   RELEASE_PLAYERS_TODAY.bat "C:\Pasta\ModpackCompleto" "C:\Pasta\EclipseLauncher.exe"
echo.
echo Ele gera UM unico arquivo: release\EclipseSMP-PLAYER.zip
pause
exit /b 1
