param(
  [Parameter(Mandatory=$true)][string]$ModpackFolder,
  [Parameter(Mandatory=$true)][string]$LauncherExe,
  [string]$PackVersion = "1.0.0",
  [string]$Forge = "47.4.10",
  [string]$ServerAddress = "",
  [string]$Output = ".\release\EclipseSMP-PLAYER.zip"
)
$ErrorActionPreference='Stop'
$python = (Get-Command python -ErrorAction SilentlyContinue).Source
if(-not $python){ $python = (Get-Command py -ErrorAction SilentlyContinue).Source }
if(-not $python){ throw 'Python 3 não encontrado. Instale Python ou rode make_player_release.py em outra máquina.' }
& $python "$PSScriptRoot\make_player_release.py" --launcher-exe $LauncherExe --instance $ModpackFolder --output $Output --pack-version $PackVersion --forge $Forge --server $ServerAddress
if($LASTEXITCODE -ne 0){ throw 'Falha ao gerar pacote dos players.' }
Write-Host "\nPACOTE DOS PLAYERS PRONTO: $Output" -ForegroundColor Green
