#!/usr/bin/env python3
"""Gera manifest schema v2 SHA-256 para o Eclipse Launcher."""
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path

DEFAULT_PRESERVE = {"options.txt", "servers.dat"}
DEFAULT_SKIP_DIRS = {"logs", "screenshots", "crash-reports", "saves", ".git", "backups", ".eclipse"}

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()

def safe_id(path:str)->str:
    v=re.sub(r"[^a-z0-9]+","-",path.lower()).strip("-")
    return v[:96] or hashlib.sha1(path.encode()).hexdigest()[:16]

def load_optional(path:Path|None):
    if not path:return {}
    raw=json.loads(path.read_text("utf-8"))
    if not isinstance(raw,dict):raise SystemExit("--optional-json deve ser um objeto { caminho: metadata }")
    return {Path(k).as_posix():v for k,v in raw.items()}

def main()->None:
    ap=argparse.ArgumentParser()
    ap.add_argument("instance",type=Path)
    ap.add_argument("--output",type=Path,default=Path("manifest.generated.json"))
    ap.add_argument("--pack-name",default="Eclipse SMP");ap.add_argument("--pack-version",default="1.0.0")
    ap.add_argument("--minecraft",default="1.20.1");ap.add_argument("--forge",required=True,help="Versão exata, ex.: 47.4.23")
    ap.add_argument("--file-base",required=True);ap.add_argument("--mirror",action="append",default=[])
    ap.add_argument("--status-url");ap.add_argument("--news-url");ap.add_argument("--events-url");ap.add_argument("--launcher-update-url")
    ap.add_argument("--server");ap.add_argument("--min-ram",type=int,default=4096);ap.add_argument("--recommended-ram",type=int,default=8192)
    ap.add_argument("--min-launcher",default="1.0.0-alpha.8");ap.add_argument("--microsoft-client-id",default="")
    ap.add_argument("--preserve",action="append",default=[]);ap.add_argument("--optional-json",type=Path,help="JSON com metadata por caminho de mod opcional")
    a=ap.parse_args();root=a.instance.resolve()
    if not root.is_dir():raise SystemExit(f"Instância não encontrada: {root}")
    if a.min_ram<1024 or a.recommended_ram<a.min_ram:raise SystemExit("RAM inválida")
    preserve=DEFAULT_PRESERVE|{Path(x).as_posix() for x in a.preserve};optional=load_optional(a.optional_json);files=[]
    for p in sorted(root.rglob("*")):
        if not p.is_file():continue
        rel=p.relative_to(root)
        if any(part in DEFAULT_SKIP_DIRS for part in rel.parts):continue
        posix=rel.as_posix(); meta=optional.get(posix,{})
        mode="optional" if posix in optional else ("preserve" if posix in preserve else "managed")
        files.append({
          "id":str(meta.get("id") or safe_id(posix)),"path":posix,"sha256":sha256(p),"size":p.stat().st_size,"mode":mode,"url":None,
          "mirrors":list(meta.get("mirrors",[])),"display_name":str(meta.get("display_name",p.stem if mode=="optional" else "")),
          "description":str(meta.get("description","")),"group":str(meta.get("group","")),"conflicts":list(meta.get("conflicts",[])),
          "enabled_by_default":bool(meta.get("enabled_by_default",False))
        })
    doc={
      "schema_version":2,
      "pack":{"name":a.pack_name,"version":a.pack_version,"minecraft":a.minecraft,"forge":a.forge},
      "endpoints":{"status":a.status_url,"news":a.news_url,"events":a.events_url,"launcher_update":a.launcher_update_url,"file_base":a.file_base,"file_bases":a.mirror},
      "launch":{"server_address":a.server,"java_major":17,"min_ram_mb":a.min_ram,"recommended_ram_mb":a.recommended_ram,"min_launcher_version":a.min_launcher},
      "auth":{"client_id":a.microsoft_client_id,"authorize_url":"https://login.live.com/oauth20_authorize.srf","token_url":"https://login.live.com/oauth20_token.srf","scope":"XboxLive.signin offline_access"},
      "files":files
    }
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Manifesto v2 criado: {a.output} ({len(files)} arquivos; {sum(x['mode']=='optional' for x in files)} opcionais)")
if __name__=="__main__":main()
