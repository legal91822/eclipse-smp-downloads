param([string]$OutDir=".eclipse-signing")
$ErrorActionPreference="Stop"
New-Item -ItemType Directory -Force $OutDir | Out-Null
$private=Join-Path $OutDir "update-ed25519-private.pem";$publicDer=Join-Path $OutDir "update-ed25519-public.der"
openssl genpkey -algorithm ED25519 -out $private
openssl pkey -in $private -pubout -outform DER -out $publicDer
$der=[IO.File]::ReadAllBytes($publicDer)
# SubjectPublicKeyInfo Ed25519 DER is 44 bytes; raw public key is the final 32 bytes.
$raw=$der[($der.Length-32)..($der.Length-1)]
$pub=[Convert]::ToBase64String($raw)
Write-Host "ECLIPSE_UPDATE_PUBLIC_KEY_B64=$pub" -ForegroundColor Cyan
Write-Host "Guarde $private como GitHub Secret ECLIPSE_UPDATE_PRIVATE_KEY_PEM e NUNCA faça commit dele." -ForegroundColor Yellow
