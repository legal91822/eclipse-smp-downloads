#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil, tempfile, zipfile
from pathlib import Path

SKIP_DIRS={"logs","screenshots","saves","crash-reports","backups",".git",".idea",".vscode",".eclipse"}
PRESERVE_PREFIXES=("journeymap/","xaero","shaderpacks/","config/client")
PRESERVE_FILES={"options.txt","servers.dat"}

def sha256(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def should_skip(rel:Path)->bool:
    return any(part.lower() in SKIP_DIRS for part in rel.parts)

def build_seed(instance:Path, out:Path, version:str, forge:str, server:str='')->dict:
    files=[]; total=0
    for p in sorted(instance.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(instance)
        if should_skip(rel): continue
        posix=rel.as_posix(); lower=posix.lower()
        mode='preserve' if posix in PRESERVE_FILES or lower.startswith(PRESERVE_PREFIXES) else 'managed'
        size=p.stat().st_size
        files.append({
            'id':'','path':posix,'sha256':sha256(p),'size':size,'mode':mode,'url':None,'mirrors':[],
            'display_name':p.stem,'description':'','group':'core','conflicts':[],'enabled_by_default':True,
        }); total+=size
    if not files: raise SystemExit('Nenhum arquivo válido encontrado no modpack.')
    manifest={
        'schema_version':2,
        'pack':{'name':'Eclipse SMP','version':version,'minecraft':'1.20.1','forge':forge},
        'endpoints':{'status':None,'news':None,'events':None,'launcher_update':None,'file_base':None,'file_bases':[]},
        'launch':{'server_address':server or None,'java_major':17,'min_ram_mb':4096,'recommended_ram_mb':8192,'min_launcher_version':'1.0.0-alpha.13'},
        'auth':{'client_id':'','authorize_url':'https://login.live.com/oauth20_authorize.srf','token_url':'https://login.live.com/oauth20_token.srf','scope':'XboxLive.signin offline_access'},
        'files':files,
    }
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        mp=Path(td)/'manifest.json'; mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
        with zipfile.ZipFile(out,'w',allowZip64=True) as z:
            z.write(mp,'manifest.json',compress_type=zipfile.ZIP_DEFLATED)
            for i,(entry,p) in enumerate(((x,instance/x['path']) for x in files),1):
                z.write(p,'pack/'+entry['path'],compress_type=zipfile.ZIP_DEFLATED,compresslevel=1)
                if i%100==0: print(f'  seed: {i}/{len(files)}')
    return {'files':len(files),'bytes':total,'version':version,'forge':forge,'sha256':sha256(out)}

def main():
    ap=argparse.ArgumentParser(description='Gera um único ZIP para o player: launcher portátil + pack local validado.')
    ap.add_argument('--launcher-exe',type=Path,required=True,help='EXE portátil compilado do Eclipse Launcher')
    ap.add_argument('--instance',type=Path,required=True,help='Pasta COMPLETA do modpack')
    ap.add_argument('--output',type=Path,default=Path('release/EclipseSMP-PLAYER.zip'))
    ap.add_argument('--pack-version',default='1.0.0')
    ap.add_argument('--forge',default='47.4.10')
    ap.add_argument('--server',default='')
    ap.add_argument('--bootstrap-url',default='')
    ap.add_argument('--discord-url',default='')
    ap.add_argument('--site-url',default='')
    a=ap.parse_args()
    exe=a.launcher_exe.resolve(); inst=a.instance.resolve(); out=a.output.resolve()
    if not exe.is_file(): raise SystemExit(f'Launcher EXE não encontrado: {exe}')
    if not inst.is_dir(): raise SystemExit(f'Modpack não encontrado: {inst}')
    with tempfile.TemporaryDirectory(prefix='eclipse-player-release-') as td:
        root=Path(td)/'Eclipse SMP'; root.mkdir(parents=True)
        target_exe=root/'EclipseLauncher.exe'; shutil.copy2(exe,target_exe)
        seed=root/'EclipseSMP-Seed.zip'
        report=build_seed(inst,seed,a.pack_version,a.forge,a.server)
        release_cfg={
            'bootstrap_url':a.bootstrap_url,
            'stable_manifest_url':'','beta_manifest_url':'','staff_manifest_url':'',
            'site_url':a.site_url,'discord_url':a.discord_url,'rules_url':'','wiki_url':'','support_url':'',
            'update_public_key_b64':'','microsoft_client_id':'','seed_url':'','seed_sha256':''
        }
        (root/'eclipse-release.json').write_text(json.dumps(release_cfg,ensure_ascii=False,indent=2),encoding='utf-8')
        (root/'ABRIR_ECLIPSE.bat').write_text('@echo off\r\nstart "" "%~dp0EclipseLauncher.exe"\r\n',encoding='utf-8')
        (root/'LEIA-ME.txt').write_text(
            'ECLIPSE SMP — PLAYER PACK\n\n1. Extraia esta pasta.\n2. Abra EclipseLauncher.exe (ou ABRIR_ECLIPSE.bat).\n3. Clique INSTALAR E JOGAR.\n\nO launcher detecta EclipseSMP-Seed.zip automaticamente, valida SHA-256, instala a instância isolada, prepara Java/Forge e cria o perfil do Eclipse.\nDepois que o CDN estiver configurado, atualizações passam a ser diferenciais e automáticas.\n',encoding='utf-8')
        (root/'release-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        out.parent.mkdir(parents=True,exist_ok=True)
        if out.exists(): out.unlink()
        with zipfile.ZipFile(out,'w',allowZip64=True) as z:
            for p in sorted(root.rglob('*')):
                if not p.is_file(): continue
                arc=Path('Eclipse SMP')/p.relative_to(root)
                # The seed is already compressed; store it to avoid wasting hours and RAM.
                c=zipfile.ZIP_STORED if p.suffix.lower()=='.zip' else zipfile.ZIP_DEFLATED
                z.write(p,arc.as_posix(),compress_type=c)
    print(f'PRONTO: {out}')
    print(f"Pack {report['version']} | Forge {report['forge']} | {report['files']} arquivos | seed SHA256 {report['sha256']}")

if __name__=='__main__': main()
