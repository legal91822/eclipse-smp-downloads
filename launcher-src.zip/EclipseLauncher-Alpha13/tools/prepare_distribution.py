#!/usr/bin/env python3
"""Prepare a complete Eclipse SMP distribution directory.

Input: one working client instance (mods/config/defaultconfigs/kubejs/...)
Output:
  distribution/
    seed/EclipseSMP-Seed.zip
    objects/<sha...>
    releases/<version>/manifest.json
    channels/stable/manifest.json
    api/channels.json
    release-config.json
    release-vars.env

Upload the directory to R2/S3/static HTTPS hosting. Players only need the launcher.
"""
from __future__ import annotations
import argparse, hashlib, json, subprocess, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from make_player_release import build_seed

def sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(description='Prepara Seed + CDN diferencial + configuração do Eclipse Launcher.')
    ap.add_argument('instance', type=Path, help='Pasta completa de uma instância cliente funcional')
    ap.add_argument('--output', type=Path, default=Path('distribution'))
    ap.add_argument('--public-base', required=True, help='Base HTTPS onde a pasta output será publicada')
    ap.add_argument('--version', default='1.0.0')
    ap.add_argument('--forge', default='47.4.10')
    ap.add_argument('--server', default='')
    ap.add_argument('--channel', choices=['stable','beta','staff'], default='stable')
    ap.add_argument('--control-base', default='')
    ap.add_argument('--discord-url', default='')
    ap.add_argument('--site-url', default='')
    a=ap.parse_args()

    instance=a.instance.resolve(); out=a.output.resolve(); out.mkdir(parents=True, exist_ok=True)
    if not instance.is_dir(): raise SystemExit(f'Instância não encontrada: {instance}')
    base=a.public_base.rstrip('/')
    if not base.startswith('https://'): raise SystemExit('--public-base precisa usar HTTPS')

    seed=out/'seed'/'EclipseSMP-Seed.zip'; seed.parent.mkdir(parents=True, exist_ok=True)
    seed_report=build_seed(instance, seed, a.version, a.forge, a.server)

    publisher=Path(__file__).with_name('publish_pack.py')
    cmd=[sys.executable, str(publisher), str(instance), '--cdn-dir', str(out), '--public-base', base,
         '--channel', a.channel, '--version', a.version, '--forge', a.forge, '--minecraft','1.20.1',
         '--min-launcher','1.0.0-alpha.13']
    if a.server: cmd += ['--server', a.server]
    if a.control_base: cmd += ['--control-base', a.control_base]
    subprocess.run(cmd, check=True)

    seed_url=f'{base}/seed/EclipseSMP-Seed.zip'
    bootstrap_url=f'{base}/api/channels.json'
    release_cfg={
        'bootstrap_url':bootstrap_url,
        'stable_manifest_url':'','beta_manifest_url':'','staff_manifest_url':'',
        'site_url':a.site_url,'discord_url':a.discord_url,'rules_url':'','wiki_url':'','support_url':'',
        'update_public_key_b64':'','microsoft_client_id':'',
        'seed_url':seed_url,'seed_sha256':seed_report['sha256'],
    }
    (out/'release-config.json').write_text(json.dumps(release_cfg,ensure_ascii=False,indent=2),encoding='utf-8')
    env='\n'.join([
        f'ECLIPSE_BOOTSTRAP_URL={bootstrap_url}',
        f'ECLIPSE_SEED_URL={seed_url}',
        f'ECLIPSE_SEED_SHA256={seed_report["sha256"]}',
        f'ECLIPSE_SITE_URL={a.site_url}',
        f'ECLIPSE_DISCORD_URL={a.discord_url}',
        'ECLIPSE_UPDATE_PUBLIC_KEY_B64=',
        'ECLIPSE_MICROSOFT_CLIENT_ID=',
        ''
    ])
    (out/'release-vars.env').write_text(env,encoding='utf-8')
    report={
        'pack_version':a.version,'minecraft':'1.20.1','forge':a.forge,'channel':a.channel,
        'seed_url':seed_url,'seed_sha256':seed_report['sha256'],'bootstrap_url':bootstrap_url,
        'seed_files':seed_report['files'],'seed_bytes':seed_report['bytes'],
    }
    (out/'distribution-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('\nDISTRIBUIÇÃO PRONTA PARA UPLOAD')
    print(f'  Pasta: {out}')
    print(f'  Bootstrap: {bootstrap_url}')
    print(f'  Seed: {seed_url}')
    print(f'  SHA-256: {seed_report["sha256"]}')
    print('Depois do upload, use release-vars.env como GitHub Variables da build do launcher.')

if __name__=='__main__': main()
