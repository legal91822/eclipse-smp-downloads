#!/usr/bin/env python3
"""Eclipse Pack Publisher (Alpha 8)

Creates an immutable content-addressed CDN layout and publishes the channel manifest LAST.
The output directory can be uploaded/synced to Cloudflare R2/S3/static hosting with rclone/aws-cli.
No third-party Python packages are required.
"""
from __future__ import annotations
import argparse, hashlib, json, os, re, shutil, tempfile
from pathlib import Path
from urllib.parse import quote

SKIP_DIRS={"logs","screenshots","crash-reports","saves",".git","backups",".eclipse"}
DEFAULT_PRESERVE={"options.txt","servers.dat"}

def sha256(p:Path)->str:
    h=hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()

def safe_id(path:str)->str:
    x=re.sub(r"[^a-z0-9]+","-",path.lower()).strip("-")
    return x[:96] or hashlib.sha1(path.encode()).hexdigest()[:16]

def atomic_json(path:Path,obj)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=path.name+".",suffix=".tmp",dir=path.parent)
    try:
        with os.fdopen(fd,"w",encoding="utf-8") as f:
            json.dump(obj,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        try:os.unlink(tmp)
        except FileNotFoundError:pass

def load_json(path:Path,default):
    try:return json.loads(path.read_text("utf-8"))
    except Exception:return default

def load_optional(path:Path|None):
    if not path:return {}
    raw=load_json(path,{})
    if not isinstance(raw,dict):raise SystemExit("--optional-json precisa ser objeto { caminho: metadata }")
    return {Path(k).as_posix():v for k,v in raw.items()}

def urljoin(base:str,*parts:str)->str:
    return base.rstrip("/")+"/"+"/".join(quote(x.strip("/"),safe="/-._~") for x in parts)

def main():
    ap=argparse.ArgumentParser(description="Publica um release do Eclipse SMP para CDN")
    ap.add_argument("instance",type=Path)
    ap.add_argument("--cdn-dir",type=Path,required=True,help="Pasta staging que será sincronizada para R2/S3")
    ap.add_argument("--public-base",required=True,help="Ex.: https://cdn.seudominio.com/eclipse")
    ap.add_argument("--channel",choices=["stable","beta","staff"],default="stable")
    ap.add_argument("--version",required=True)
    ap.add_argument("--forge",required=True)
    ap.add_argument("--minecraft",default="1.20.1")
    ap.add_argument("--pack-name",default="Eclipse SMP")
    ap.add_argument("--control-base",default="",help="Ex.: https://launcher.seudominio.com/api")
    ap.add_argument("--server",default="")
    ap.add_argument("--min-launcher",default="1.0.0-alpha.13")
    ap.add_argument("--min-ram",type=int,default=4096)
    ap.add_argument("--recommended-ram",type=int,default=8192)
    ap.add_argument("--microsoft-client-id",default="")
    ap.add_argument("--optional-json",type=Path)
    ap.add_argument("--preserve",action="append",default=[])
    ap.add_argument("--mirror-base",action="append",default=[])
    a=ap.parse_args()
    root=a.instance.resolve();cdn=a.cdn_dir.resolve()
    if not root.is_dir():raise SystemExit(f"Instância não encontrada: {root}")
    if a.recommended_ram<a.min_ram:raise SystemExit("recommended RAM precisa ser >= min RAM")
    optional=load_optional(a.optional_json);preserve=DEFAULT_PRESERVE|{Path(x).as_posix() for x in a.preserve}
    old_path=cdn/"channels"/a.channel/"manifest.json";old=load_json(old_path,{"files":[]})
    old_by_path={x.get("path"):x for x in old.get("files",[]) if isinstance(x,dict)}
    files=[];changed=[];new=[];unchanged=[];total_download=0
    for p in sorted(root.rglob("*")):
        if not p.is_file():continue
        rel=p.relative_to(root)
        if any(part in SKIP_DIRS for part in rel.parts):continue
        posix=rel.as_posix();meta=optional.get(posix,{})
        digest=sha256(p);size=p.stat().st_size;obj_rel=f"objects/{digest[:2]}/{digest}"
        obj=cdn/obj_rel
        if not obj.exists():obj.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,obj)
        elif obj.stat().st_size!=size or sha256(obj)!=digest:raise SystemExit(f"Objeto CDN inconsistente: {obj}")
        mode="optional" if posix in optional else ("preserve" if posix in preserve else "managed")
        entry={
            "id":str(meta.get("id") or safe_id(posix)),"path":posix,"sha256":digest,"size":size,"mode":mode,
            "url":urljoin(a.public_base,obj_rel),"mirrors":[urljoin(m,obj_rel) for m in a.mirror_base],
            "display_name":str(meta.get("display_name",p.stem if mode=="optional" else "")),"description":str(meta.get("description","")),
            "group":str(meta.get("group","")),"conflicts":list(meta.get("conflicts",[])),"enabled_by_default":bool(meta.get("enabled_by_default",False)),
        }
        files.append(entry)
        prev=old_by_path.get(posix)
        if not prev:new.append(posix);total_download+=size
        elif prev.get("sha256")!=digest:changed.append(posix);total_download+=size
        else:unchanged.append(posix)
    current_paths={x["path"] for x in files};removed=sorted(set(old_by_path)-current_paths)
    api=a.control_base.rstrip("/")
    endpoints={
        "status":f"{api}/status.json" if api else None,"news":f"{api}/news.json" if api else None,"events":f"{api}/events.json" if api else None,
        "launcher_update":f"{api}/launcher-update.json" if api else None,"file_base":None,"file_bases":[],
    }
    manifest={
        "schema_version":2,"pack":{"name":a.pack_name,"version":a.version,"minecraft":a.minecraft,"forge":a.forge},"endpoints":endpoints,
        "launch":{"server_address":a.server or None,"java_major":17,"min_ram_mb":a.min_ram,"recommended_ram_mb":a.recommended_ram,"min_launcher_version":a.min_launcher},
        "auth":{"client_id":a.microsoft_client_id,"authorize_url":"https://login.live.com/oauth20_authorize.srf","token_url":"https://login.live.com/oauth20_token.srf","scope":"XboxLive.signin offline_access"},"files":files,
    }
    # Version manifest is immutable. Channel manifest is deliberately published LAST.
    version_path=cdn/"releases"/a.version/"manifest.json";atomic_json(version_path,manifest)
    channel_manifest_url=urljoin(a.public_base,"channels",a.channel,"manifest.json")
    channels_path=cdn/"api"/"channels.json";channels=load_json(channels_path,{"stable":"","beta":"","staff":""});channels[a.channel]=channel_manifest_url
    atomic_json(channels_path,channels)
    atomic_json(old_path,manifest)  # LAST operation: clients can now see the release.
    report={"channel":a.channel,"version":a.version,"new":new,"changed":changed,"removed":removed,"unchanged":len(unchanged),"download_bytes":total_download,"manifest":channel_manifest_url}
    atomic_json(cdn/"releases"/a.version/"publish-report.json",report)
    print(f"Publicado staging {a.channel} {a.version}")
    print(f"  novos={len(new)} alterados={len(changed)} removidos={len(removed)} sem mudança={len(unchanged)}")
    print(f"  download estimado para cliente anterior: {total_download/1024/1024:.1f} MB")
    print(f"  manifesto: {old_path}")
    print("Sincronize --cdn-dir para sua CDN/R2 preservando a ordem: objects + releases + api, e channels por último.")

if __name__=="__main__":main()
