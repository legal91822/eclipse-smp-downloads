param(
  [Parameter(Mandatory=$true)][string]$StagingDir,
  [Parameter(Mandatory=$true)][string]$Remote = "r2:eclipse-launcher"
)
$ErrorActionPreference = "Stop"
Write-Host "1/2 Enviando objetos, releases e API..."
rclone sync "$StagingDir/objects" "$Remote/objects" --immutable --transfers 12
rclone sync "$StagingDir/releases" "$Remote/releases" --transfers 8
rclone sync "$StagingDir/api" "$Remote/api" --transfers 4
Write-Host "2/2 Publicando manifests de canal POR ULTIMO..."
rclone sync "$StagingDir/channels" "$Remote/channels" --transfers 2
Write-Host "Release publicada."
