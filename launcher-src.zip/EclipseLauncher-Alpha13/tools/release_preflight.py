#!/usr/bin/env python3
"""Falha a build pública se endpoints/chaves ainda estiverem em placeholder."""
from __future__ import annotations
import os, re, sys
from urllib.parse import urlparse

REQUIRED = ["ECLIPSE_BOOTSTRAP_URL", "ECLIPSE_UPDATE_PUBLIC_KEY_B64"]
URL_VARS = ["ECLIPSE_BOOTSTRAP_URL", "ECLIPSE_SITE_URL", "ECLIPSE_DISCORD_URL", "ECLIPSE_RULES_URL", "ECLIPSE_WIKI_URL", "ECLIPSE_SUPPORT_URL"]
BAD = re.compile(r"SEUDOMINIO|SEU_CONVITE|example\.com|eclipsesmp\.net", re.I)

def valid_https(v: str) -> bool:
    try:
        p = urlparse(v)
        return p.scheme == "https" and bool(p.netloc)
    except Exception:
        return False

def main() -> int:
    errors, warnings = [], []
    for k in REQUIRED:
        v = os.getenv(k, "").strip()
        if not v:
            errors.append(f"{k} ausente")
        elif BAD.search(v):
            errors.append(f"{k} ainda contém placeholder")
    for k in URL_VARS:
        v = os.getenv(k, "").strip()
        if not v:
            if k not in REQUIRED:
                warnings.append(f"{k} não configurado")
            continue
        if BAD.search(v):
            errors.append(f"{k} ainda contém placeholder")
        elif not valid_https(v):
            errors.append(f"{k} precisa ser HTTPS válido")
    if not os.getenv("ECLIPSE_MICROSOFT_CLIENT_ID", "").strip():
        warnings.append("ECLIPSE_MICROSOFT_CLIENT_ID ausente: Eclipse Direct ficará indisponível")
    print("Eclipse release preflight")
    for w in warnings: print(f"  AVISO: {w}")
    for e in errors: print(f"  ERRO: {e}")
    if errors:
        print("\nBuild pública bloqueada até corrigir os itens acima.")
        return 2
    print("\nConfiguração crítica de distribuição OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
