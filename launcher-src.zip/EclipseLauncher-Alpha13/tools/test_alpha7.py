#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def assert_eq(a,b,msg):
    if a!=b: raise AssertionError(f"{msg}: {a!r} != {b!r}")

def test_manifest_generator():
    with tempfile.TemporaryDirectory() as td:
        td=Path(td); inst=td/'instance'; (inst/'mods').mkdir(parents=True); (inst/'config').mkdir()
        (inst/'mods'/'required.jar').write_bytes(b'required-test')
        (inst/'mods'/'optional.jar').write_bytes(b'optional-test')
        (inst/'config'/'x.toml').write_text('x=1',encoding='utf-8')
        opt=td/'optional.json';opt.write_text(json.dumps({'mods/optional.jar':{'id':'optional-test','display_name':'Optional Test','conflicts':['other']}}),encoding='utf-8')
        out=td/'manifest.json'
        subprocess.check_call([sys.executable,str(ROOT/'tools/generate_manifest.py'),str(inst),'--output',str(out),'--forge','47.4.23','--file-base','https://cdn.example.test/eclipse/','--optional-json',str(opt)])
        doc=json.loads(out.read_text('utf-8'))
        assert_eq(doc['schema_version'],2,'schema')
        files={x['path']:x for x in doc['files']}
        assert_eq(files['mods/optional.jar']['mode'],'optional','optional mode')
        assert_eq(files['mods/optional.jar']['id'],'optional-test','optional id')
        expect=hashlib.sha256(b'required-test').hexdigest()
        assert_eq(files['mods/required.jar']['sha256'],expect,'sha256')

def test_api_validation():
    spec=importlib.util.spec_from_file_location('eclipse_api',ROOT/'server/eclipse_api.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    assert mod.valid_payload('status.json',{'maintenance':False})
    assert not mod.valid_payload('status.json',[])
    assert mod.valid_payload('news.json',[])
    assert not mod.valid_payload('news.json',{})

def test_examples():
    for p in list((ROOT/'api_examples').glob('*.json'))+list((ROOT/'server/data').glob('*.json'))+[ROOT/'manifests/manifest.example.json',ROOT/'manifests/optional.example.json']:
        json.loads(p.read_text('utf-8'))

if __name__=='__main__':
    test_manifest_generator();test_api_validation();test_examples();print('Alpha 7 Python checks: OK')
