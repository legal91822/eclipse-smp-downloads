#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def assert_eq(a,b,msg):
    if a!=b: raise AssertionError(f"{msg}: {a!r} != {b!r}")

def test_manifest_generator():
    with tempfile.TemporaryDirectory() as td:
        td=Path(td); inst=td/'instance'; (inst/'mods').mkdir(parents=True); (inst/'config').mkdir()
        (inst/'mods'/'required.jar').write_bytes(b'required-test');(inst/'mods'/'optional.jar').write_bytes(b'optional-test');(inst/'config'/'x.toml').write_text('x=1',encoding='utf-8')
        opt=td/'optional.json';opt.write_text(json.dumps({'mods/optional.jar':{'id':'optional-test','display_name':'Optional Test','conflicts':['other']}}),encoding='utf-8')
        out=td/'manifest.json'
        subprocess.check_call([sys.executable,str(ROOT/'tools/generate_manifest.py'),str(inst),'--output',str(out),'--forge','47.4.23','--file-base','https://cdn.example.test/eclipse/','--optional-json',str(opt)])
        doc=json.loads(out.read_text('utf-8'));assert_eq(doc['schema_version'],2,'schema');files={x['path']:x for x in doc['files']};assert_eq(files['mods/optional.jar']['mode'],'optional','optional mode');assert_eq(files['mods/required.jar']['sha256'],hashlib.sha256(b'required-test').hexdigest(),'sha256')

def test_atomic_publisher():
    with tempfile.TemporaryDirectory() as td:
        td=Path(td);inst=td/'instance';cdn=td/'cdn';(inst/'mods').mkdir(parents=True);(inst/'config').mkdir();(inst/'mods/a.jar').write_bytes(b'A1');(inst/'config/x.toml').write_bytes(b'X1')
        common=[sys.executable,str(ROOT/'tools/publish_pack.py'),str(inst),'--cdn-dir',str(cdn),'--public-base','https://cdn.example.test/eclipse','--forge','47.4.23','--control-base','https://launcher.example.test/api']
        subprocess.check_call(common+['--version','1.0.0']);m1=json.loads((cdn/'channels/stable/manifest.json').read_text('utf-8'));a1=next(x for x in m1['files'] if x['path']=='mods/a.jar');assert a1['url'].startswith('https://cdn.example.test/eclipse/objects/')
        (inst/'mods/a.jar').write_bytes(b'A2');subprocess.check_call(common+['--version','1.0.1']);r=json.loads((cdn/'releases/1.0.1/publish-report.json').read_text('utf-8'));assert_eq(r['changed'],['mods/a.jar'],'changed file');assert_eq(r['unchanged'],1,'unchanged count');channels=json.loads((cdn/'api/channels.json').read_text('utf-8'));assert channels['stable'].endswith('/channels/stable/manifest.json')

def test_api_validation():
    spec=importlib.util.spec_from_file_location('eclipse_api',ROOT/'server/eclipse_api.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    assert mod.valid_payload('status.json',{'maintenance':False});assert mod.valid_payload('news.json',[]);assert mod.valid_payload('channels.json',{'stable':'x'});assert mod.valid_payload('launcher-update.json',{'version':'1.0.0'})

def test_examples():
    for p in list((ROOT/'api_examples').glob('*.json'))+list((ROOT/'server/data').glob('*.json'))+[ROOT/'manifests/manifest.example.json',ROOT/'manifests/optional.example.json']:
        json.loads(p.read_text('utf-8'))

if __name__=='__main__':
    test_manifest_generator();test_atomic_publisher();test_api_validation();test_examples();print('Alpha 8 Python checks: OK')
