param(
  [string]$EclipseRoot = "$env:APPDATA\EclipseLauncher",
  [string]$ExpectedMinecraft = "1.20.1"
)
$ErrorActionPreference = "Stop"
function Ok($m){Write-Host "[OK] $m" -ForegroundColor Green}
function Fail($m){Write-Host "[FAIL] $m" -ForegroundColor Red; throw $m}
$instance=Join-Path $EclipseRoot "instances\eclipse"
if(!(Test-Path $instance)){Fail "Instância não existe: $instance"};Ok "Instância isolada"
$java=Get-ChildItem (Join-Path $EclipseRoot "runtime") -Filter java.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if(!$java){Fail "Java gerenciado não encontrado"}
& $java.FullName -version 2>&1 | Out-Host;if($LASTEXITCODE -ne 0){Fail "Java não executa"};Ok "Java gerenciado executa"
$launch=Join-Path $instance ".eclipse\launch.json";if(!(Test-Path $launch)){Fail "launch.json Direct/Offline ausente"};$spec=Get-Content $launch -Raw|ConvertFrom-Json;if(!$spec.main_class){Fail "main_class vazio"};Ok "Runtime Direct/Offline preparado"
$profiles=@("$env:APPDATA\.minecraft\launcher_profiles.json","$env:APPDATA\.minecraft\launcher_profiles_microsoft_store.json")|Where-Object{Test-Path $_}
$found=$false;foreach($p in $profiles){$j=Get-Content $p -Raw|ConvertFrom-Json;if($j.profiles.'eclipse-smp'){$found=$true;if($j.profiles.'eclipse-smp'.gameDir -ne $instance){Fail "gameDir oficial não aponta para instância Eclipse"}}}
if(!$found){Fail "Perfil eclipse-smp não encontrado no Minecraft Launcher"};Ok "Perfil oficial Eclipse SMP"
$mods=Join-Path $instance "mods";if(!(Test-Path $mods)){Fail "Pasta mods ausente"};Ok "Pasta de mods pronta"
Write-Host "`nSmoke test local concluído. Próximo passo: abrir pelo Eclipse Launcher e confirmar conexão real no SMP." -ForegroundColor Cyan
